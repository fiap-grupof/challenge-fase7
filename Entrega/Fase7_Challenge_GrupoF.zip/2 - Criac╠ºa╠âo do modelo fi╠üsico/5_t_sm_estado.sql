INSERT INTO T_SM_ESTADO 
 SELECT 1, 1, 'Acre', 'AC' FROM dual
 UNION ALL

 SELECT 2, 2, 'Alagoas', 'AL' FROM dual
 UNION ALL

 SELECT 3, 1, 'Amazonas', 'AM' FROM dual
 UNION ALL

 SELECT 4, 1, 'Amapá', 'AP' FROM dual
 UNION ALL

 SELECT 5, 2, 'Bahia', 'BA' FROM dual
 UNION ALL

 SELECT 6, 2, 'Ceará', 'CE' FROM dual
 UNION ALL

 SELECT 7, 3, 'Distrito Federal', 'DF' FROM dual
 UNION ALL

 SELECT 8, 4, 'Espírito Santo', 'ES' FROM dual
 UNION ALL

 SELECT 9, 3, 'Goiás', 'GO' FROM dual
 UNION ALL

 SELECT 10, 2, 'Maranhão', 'MA' FROM dual
 UNION ALL

 SELECT 11, 4, 'Minas Gerais', 'MG' FROM dual
 UNION ALL

 SELECT 12, 3, 'Mato Grosso do Sul', 'MS' FROM dual
 UNION ALL

 SELECT 13, 3, 'Mato Grosso', 'MT' FROM dual
 UNION ALL

 SELECT 14, 1, 'Pará', 'PA' FROM dual
 UNION ALL

 SELECT 15, 2, 'Paraíba', 'PB' FROM dual
 UNION ALL

 SELECT 16, 2, 'Pernambuco', 'PE' FROM dual
 UNION ALL

 SELECT 17, 2, 'Piauí', 'PI' FROM dual
 UNION ALL

 SELECT 18, 5, 'Paraná', 'PR' FROM dual
 UNION ALL

 SELECT 19, 4, 'Rio de Janeiro', 'RJ' FROM dual
 UNION ALL

 SELECT 20, 2, 'Rio Grande do Norte', 'RN' FROM dual
 UNION ALL

 SELECT 21, 1, 'Rondônia', 'RO' FROM dual
 UNION ALL

 SELECT 22, 1, 'Roraima', 'RR' FROM dual
 UNION ALL

 SELECT 23, 5, 'Rio Grande do Sul', 'RS' FROM dual
 UNION ALL

 SELECT 24, 5, 'Santa Catarina', 'SC' FROM dual
 UNION ALL

 SELECT 25, 2, 'Sergipe', 'SE' FROM dual
 UNION ALL

 SELECT 26, 4, 'São Paulo', 'SP' FROM dual
 UNION ALL

 SELECT 27, 1, 'Tocantins', 'TO' FROM dual;