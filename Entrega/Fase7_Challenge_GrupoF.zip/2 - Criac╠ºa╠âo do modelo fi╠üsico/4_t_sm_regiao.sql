INSERT INTO T_SM_REGIAO 
 SELECT 1, 31, 'Norte' FROM dual
 UNION ALL
 
 SELECT 2, 31, 'Nordeste' FROM dual
 UNION ALL
 
 SELECT 3, 31, 'Centro-Oeste' FROM dual
 UNION ALL
 
 SELECT 4, 31, 'Sudeste' FROM dual
 UNION ALL

 SELECT 5, 31, 'Sul' FROM dual;