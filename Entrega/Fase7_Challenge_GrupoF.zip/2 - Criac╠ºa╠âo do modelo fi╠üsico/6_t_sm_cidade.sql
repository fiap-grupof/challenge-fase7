INSERT INTO t_sm_cidade
 SELECT 1, 8, 'Afonso Cláudio' FROM dual
 UNION ALL

 SELECT 2, 8, 'Água Doce do Norte' FROM dual
 UNION ALL

 SELECT 3, 8, 'Águia Branca' FROM dual
 UNION ALL

 SELECT 4, 8, 'Alegre' FROM dual
 UNION ALL

 SELECT 5, 8, 'Alfredo Chaves' FROM dual
 UNION ALL

 SELECT 6, 8, 'Alto Rio Novo' FROM dual
 UNION ALL

 SELECT 7, 8, 'Anchieta' FROM dual
 UNION ALL

 SELECT 8, 8, 'Apiacá' FROM dual
 UNION ALL

 SELECT 9, 8, 'Aracruz' FROM dual
 UNION ALL

 SELECT 10, 8, 'Atilio Vivacqua' FROM dual
 UNION ALL

 SELECT 11, 8, 'Baixo Guandu' FROM dual
 UNION ALL

 SELECT 12, 8, 'Barra de São Francisco' FROM dual
 UNION ALL

 SELECT 13, 8, 'Boa Esperança' FROM dual
 UNION ALL

 SELECT 14, 8, 'Bom Jesus do Norte' FROM dual
 UNION ALL

 SELECT 15, 8, 'Brejetuba' FROM dual
 UNION ALL

 SELECT 16, 8, 'Cachoeiro de Itapemirim' FROM dual
 UNION ALL

 SELECT 17, 8, 'Cariacica' FROM dual
 UNION ALL

 SELECT 18, 8, 'Castelo' FROM dual
 UNION ALL

 SELECT 19, 8, 'Colatina' FROM dual
 UNION ALL

 SELECT 20, 8, 'Conceição da Barra' FROM dual
 UNION ALL

 SELECT 21, 8, 'Conceição do Castelo' FROM dual
 UNION ALL

 SELECT 22, 8, 'Divino de São Lourenço' FROM dual
 UNION ALL

 SELECT 23, 8, 'Domingos Martins' FROM dual
 UNION ALL

 SELECT 24, 8, 'Dores do Rio Preto' FROM dual
 UNION ALL

 SELECT 25, 8, 'Ecoporanga' FROM dual
 UNION ALL

 SELECT 26, 8, 'Fundão' FROM dual
 UNION ALL

 SELECT 27, 8, 'Governador Lindenberg' FROM dual
 UNION ALL

 SELECT 28, 8, 'Guaçuí' FROM dual
 UNION ALL

 SELECT 29, 8, 'Guarapari' FROM dual
 UNION ALL

 SELECT 30, 8, 'Ibatiba' FROM dual
 UNION ALL

 SELECT 31, 8, 'Ibiraçu' FROM dual
 UNION ALL

 SELECT 32, 8, 'Ibitirama' FROM dual
 UNION ALL

 SELECT 33, 8, 'Iconha' FROM dual
 UNION ALL

 SELECT 34, 8, 'Irupi' FROM dual
 UNION ALL

 SELECT 35, 8, 'Itaguaçu' FROM dual
 UNION ALL

 SELECT 36, 8, 'Itapemirim' FROM dual
 UNION ALL

 SELECT 37, 8, 'Itarana' FROM dual
 UNION ALL

 SELECT 38, 8, 'Iúna' FROM dual
 UNION ALL

 SELECT 39, 8, 'Jaguaré' FROM dual
 UNION ALL

 SELECT 40, 8, 'Jerônimo Monteiro' FROM dual
 UNION ALL

 SELECT 41, 8, 'João Neiva' FROM dual
 UNION ALL

 SELECT 42, 8, 'Laranja da Terra' FROM dual
 UNION ALL

 SELECT 43, 8, 'Linhares' FROM dual
 UNION ALL

 SELECT 44, 8, 'Mantenópolis' FROM dual
 UNION ALL

 SELECT 45, 8, 'Marataízes' FROM dual
 UNION ALL

 SELECT 46, 8, 'Marechal Floriano' FROM dual
 UNION ALL

 SELECT 47, 8, 'Marilândia' FROM dual
 UNION ALL

 SELECT 48, 8, 'Mimoso do Sul' FROM dual
 UNION ALL

 SELECT 49, 8, 'Montanha' FROM dual
 UNION ALL

 SELECT 50, 8, 'Mucurici' FROM dual
 UNION ALL

 SELECT 51, 8, 'Muniz Freire' FROM dual
 UNION ALL

 SELECT 52, 8, 'Muqui' FROM dual
 UNION ALL

 SELECT 53, 8, 'Nova Venécia' FROM dual
 UNION ALL

 SELECT 54, 8, 'Pancas' FROM dual
 UNION ALL

 SELECT 55, 8, 'Pedro Canário' FROM dual
 UNION ALL

 SELECT 56, 8, 'Pinheiros' FROM dual
 UNION ALL

 SELECT 57, 8, 'Piúma' FROM dual
 UNION ALL

 SELECT 58, 8, 'Ponto Belo' FROM dual
 UNION ALL

 SELECT 59, 8, 'Presidente Kennedy' FROM dual
 UNION ALL

 SELECT 60, 8, 'Rio Bananal' FROM dual
 UNION ALL

 SELECT 61, 8, 'Rio Novo do Sul' FROM dual
 UNION ALL

 SELECT 62, 8, 'Santa Leopoldina' FROM dual
 UNION ALL

 SELECT 63, 8, 'Santa Maria de Jetibá' FROM dual
 UNION ALL

 SELECT 64, 8, 'Santa Teresa' FROM dual
 UNION ALL

 SELECT 65, 8, 'São Domingos do Norte' FROM dual
 UNION ALL

 SELECT 66, 8, 'São Gabriel da Palha' FROM dual
 UNION ALL

 SELECT 67, 8, 'São José do Calçado' FROM dual
 UNION ALL

 SELECT 68, 8, 'São Mateus' FROM dual
 UNION ALL

 SELECT 69, 8, 'São Roque do Canaã' FROM dual
 UNION ALL

 SELECT 70, 8, 'Serra' FROM dual
 UNION ALL

 SELECT 71, 8, 'Sooretama' FROM dual
 UNION ALL

 SELECT 72, 8, 'Vargem Alta' FROM dual
 UNION ALL

 SELECT 73, 8, 'Venda Nova do Imigrante' FROM dual
 UNION ALL

 SELECT 74, 8, 'Viana' FROM dual
 UNION ALL

 SELECT 75, 8, 'Vila Pavão' FROM dual
 UNION ALL

 SELECT 76, 8, 'Vila Valério' FROM dual
 UNION ALL

 SELECT 77, 8, 'Vila Velha' FROM dual
 UNION ALL

 SELECT 78, 8, 'Vitória' FROM dual
 UNION ALL

 SELECT 79, 1, 'Acrelândia' FROM dual
 UNION ALL

 SELECT 80, 1, 'Assis Brasil' FROM dual
 UNION ALL

 SELECT 81, 1, 'Brasiléia' FROM dual
 UNION ALL

 SELECT 82, 1, 'Bujari' FROM dual
 UNION ALL

 SELECT 83, 1, 'Capixaba' FROM dual
 UNION ALL

 SELECT 84, 1, 'Cruzeiro do Sul' FROM dual
 UNION ALL

 SELECT 85, 1, 'Epitaciolândia' FROM dual
 UNION ALL

 SELECT 86, 1, 'Feijó' FROM dual
 UNION ALL

 SELECT 87, 1, 'Jordão' FROM dual
 UNION ALL

 SELECT 88, 1, 'Mâncio Lima' FROM dual
 UNION ALL

 SELECT 89, 1, 'Manoel Urbano' FROM dual
 UNION ALL

 SELECT 90, 1, 'Marechal Thaumaturgo' FROM dual
 UNION ALL

 SELECT 91, 1, 'Plácido de Castro' FROM dual
 UNION ALL

 SELECT 92, 1, 'Porto Acre' FROM dual
 UNION ALL

 SELECT 93, 1, 'Porto Walter' FROM dual
 UNION ALL

 SELECT 94, 1, 'Rio Branco' FROM dual
 UNION ALL

 SELECT 95, 1, 'Rodrigues Alves' FROM dual
 UNION ALL

 SELECT 96, 1, 'Santa Rosa do Purus' FROM dual
 UNION ALL

 SELECT 97, 1, 'Sena Madureira' FROM dual
 UNION ALL

 SELECT 98, 1, 'Senador Guiomard' FROM dual
 UNION ALL

 SELECT 99, 1, 'Tarauacá' FROM dual
 UNION ALL

 SELECT 100, 1, 'Xapuri' FROM dual
 UNION ALL

 SELECT 101, 2, 'Água Branca' FROM dual
 UNION ALL

 SELECT 102, 2, 'Anadia' FROM dual
 UNION ALL

 SELECT 103, 2, 'Arapiraca' FROM dual
 UNION ALL

 SELECT 104, 2, 'Atalaia' FROM dual
 UNION ALL

 SELECT 105, 2, 'Barra de Santo Antônio' FROM dual
 UNION ALL

 SELECT 106, 2, 'Barra de São Miguel' FROM dual
 UNION ALL

 SELECT 107, 2, 'Batalha' FROM dual
 UNION ALL

 SELECT 108, 2, 'Belém' FROM dual
 UNION ALL

 SELECT 109, 2, 'Belo Monte' FROM dual
 UNION ALL

 SELECT 110, 2, 'Boca da Mata' FROM dual
 UNION ALL

 SELECT 111, 2, 'Branquinha' FROM dual
 UNION ALL

 SELECT 112, 2, 'Cacimbinhas' FROM dual
 UNION ALL

 SELECT 113, 2, 'Cajueiro' FROM dual
 UNION ALL

 SELECT 114, 2, 'Campestre' FROM dual
 UNION ALL

 SELECT 115, 2, 'Campo Alegre' FROM dual
 UNION ALL

 SELECT 116, 2, 'Campo Grande' FROM dual
 UNION ALL

 SELECT 117, 2, 'Canapi' FROM dual
 UNION ALL

 SELECT 118, 2, 'Capela' FROM dual
 UNION ALL

 SELECT 119, 2, 'Carneiros' FROM dual
 UNION ALL

 SELECT 120, 2, 'Chã Preta' FROM dual
 UNION ALL

 SELECT 121, 2, 'Coité do Nóia' FROM dual
 UNION ALL

 SELECT 122, 2, 'Colônia Leopoldina' FROM dual
 UNION ALL

 SELECT 123, 2, 'Coqueiro Seco' FROM dual
 UNION ALL

 SELECT 124, 2, 'Coruripe' FROM dual
 UNION ALL

 SELECT 125, 2, 'Craíbas' FROM dual
 UNION ALL

 SELECT 126, 2, 'Delmiro Gouveia' FROM dual
 UNION ALL

 SELECT 127, 2, 'Dois Riachos' FROM dual
 UNION ALL

 SELECT 128, 2, 'Estrela de Alagoas' FROM dual
 UNION ALL

 SELECT 129, 2, 'Feira Grande' FROM dual
 UNION ALL

 SELECT 130, 2, 'Feliz Deserto' FROM dual
 UNION ALL

 SELECT 131, 2, 'Flexeiras' FROM dual
 UNION ALL

 SELECT 132, 2, 'Girau do Ponciano' FROM dual
 UNION ALL

 SELECT 133, 2, 'Ibateguara' FROM dual
 UNION ALL

 SELECT 134, 2, 'Igaci' FROM dual
 UNION ALL

 SELECT 135, 2, 'Igreja Nova' FROM dual
 UNION ALL

 SELECT 136, 2, 'Inhapi' FROM dual
 UNION ALL

 SELECT 137, 2, 'Jacaré dos Homens' FROM dual
 UNION ALL

 SELECT 138, 2, 'Jacuípe' FROM dual
 UNION ALL

 SELECT 139, 2, 'Japaratinga' FROM dual
 UNION ALL

 SELECT 140, 2, 'Jaramataia' FROM dual
 UNION ALL

 SELECT 141, 2, 'Jequiá da Praia' FROM dual
 UNION ALL

 SELECT 142, 2, 'Joaquim Gomes' FROM dual
 UNION ALL

 SELECT 143, 2, 'Jundiá' FROM dual
 UNION ALL

 SELECT 144, 2, 'Junqueiro' FROM dual
 UNION ALL

 SELECT 145, 2, 'Lagoa da Canoa' FROM dual
 UNION ALL

 SELECT 146, 2, 'Limoeiro de Anadia' FROM dual
 UNION ALL

 SELECT 147, 2, 'Maceió' FROM dual
 UNION ALL

 SELECT 148, 2, 'Major Isidoro' FROM dual
 UNION ALL

 SELECT 149, 2, 'Mar Vermelho' FROM dual
 UNION ALL

 SELECT 150, 2, 'Maragogi' FROM dual
 UNION ALL

 SELECT 151, 2, 'Maravilha' FROM dual
 UNION ALL

 SELECT 152, 2, 'Marechal Deodoro' FROM dual
 UNION ALL

 SELECT 153, 2, 'Maribondo' FROM dual
 UNION ALL

 SELECT 154, 2, 'Mata Grande' FROM dual
 UNION ALL

 SELECT 155, 2, 'Matriz de Camaragibe' FROM dual
 UNION ALL

 SELECT 156, 2, 'Messias' FROM dual
 UNION ALL

 SELECT 157, 2, 'Minador do Negrão' FROM dual
 UNION ALL

 SELECT 158, 2, 'Monteirópolis' FROM dual
 UNION ALL

 SELECT 159, 2, 'Murici' FROM dual
 UNION ALL

 SELECT 160, 2, 'Novo Lino' FROM dual
 UNION ALL

 SELECT 161, 2, 'Olho d`Água das Flores' FROM dual
 UNION ALL

 SELECT 162, 2, 'Olho d`Água do Casado' FROM dual
 UNION ALL

 SELECT 163, 2, 'Olho d`Água Grande' FROM dual
 UNION ALL

 SELECT 164, 2, 'Olivença' FROM dual
 UNION ALL

 SELECT 165, 2, 'Ouro Branco' FROM dual
 UNION ALL

 SELECT 166, 2, 'Palestina' FROM dual
 UNION ALL

 SELECT 167, 2, 'Palmeira dos Índios' FROM dual
 UNION ALL

 SELECT 168, 2, 'Pão de Açúcar' FROM dual
 UNION ALL

 SELECT 169, 2, 'Pariconha' FROM dual
 UNION ALL

 SELECT 170, 2, 'Paripueira' FROM dual
 UNION ALL

 SELECT 171, 2, 'Passo de Camaragibe' FROM dual
 UNION ALL

 SELECT 172, 2, 'Paulo Jacinto' FROM dual
 UNION ALL

 SELECT 173, 2, 'Penedo' FROM dual
 UNION ALL

 SELECT 174, 2, 'Piaçabuçu' FROM dual
 UNION ALL

 SELECT 175, 2, 'Pilar' FROM dual
 UNION ALL

 SELECT 176, 2, 'Pindoba' FROM dual
 UNION ALL

 SELECT 177, 2, 'Piranhas' FROM dual
 UNION ALL

 SELECT 178, 2, 'Poço das Trincheiras' FROM dual
 UNION ALL

 SELECT 179, 2, 'Porto Calvo' FROM dual
 UNION ALL

 SELECT 180, 2, 'Porto de Pedras' FROM dual
 UNION ALL

 SELECT 181, 2, 'Porto Real do Colégio' FROM dual
 UNION ALL

 SELECT 182, 2, 'Quebrangulo' FROM dual
 UNION ALL

 SELECT 183, 2, 'Rio Largo' FROM dual
 UNION ALL

 SELECT 184, 2, 'Roteiro' FROM dual
 UNION ALL

 SELECT 185, 2, 'Santa Luzia do Norte' FROM dual
 UNION ALL

 SELECT 186, 2, 'Santana do Ipanema' FROM dual
 UNION ALL

 SELECT 187, 2, 'Santana do Mundaú' FROM dual
 UNION ALL

 SELECT 188, 2, 'São Brás' FROM dual
 UNION ALL

 SELECT 189, 2, 'São José da Laje' FROM dual
 UNION ALL

 SELECT 190, 2, 'São José da Tapera' FROM dual
 UNION ALL

 SELECT 191, 2, 'São Luís do Quitunde' FROM dual
 UNION ALL

 SELECT 192, 2, 'São Miguel dos Campos' FROM dual
 UNION ALL

 SELECT 193, 2, 'São Miguel dos Milagres' FROM dual
 UNION ALL

 SELECT 194, 2, 'São Sebastião' FROM dual
 UNION ALL

 SELECT 195, 2, 'Satuba' FROM dual
 UNION ALL

 SELECT 196, 2, 'Senador Rui Palmeira' FROM dual
 UNION ALL

 SELECT 197, 2, 'Tanque d`Arca' FROM dual
 UNION ALL

 SELECT 198, 2, 'Taquarana' FROM dual
 UNION ALL

 SELECT 199, 2, 'Teotônio Vilela' FROM dual
 UNION ALL

 SELECT 200, 2, 'Traipu' FROM dual
 UNION ALL

 SELECT 201, 2, 'União dos Palmares' FROM dual
 UNION ALL

 SELECT 202, 2, 'Viçosa' FROM dual
 UNION ALL

 SELECT 203, 4, 'Amapá' FROM dual
 UNION ALL

 SELECT 204, 4, 'Calçoene' FROM dual
 UNION ALL

 SELECT 205, 4, 'Cutias' FROM dual
 UNION ALL

 SELECT 206, 4, 'Ferreira Gomes' FROM dual
 UNION ALL

 SELECT 207, 4, 'Itaubal' FROM dual
 UNION ALL

 SELECT 208, 4, 'Laranjal do Jari' FROM dual
 UNION ALL

 SELECT 209, 4, 'Macapá' FROM dual
 UNION ALL

 SELECT 210, 4, 'Mazagão' FROM dual
 UNION ALL

 SELECT 211, 4, 'Oiapoque' FROM dual
 UNION ALL

 SELECT 212, 4, 'Pedra Branca do Amaparí' FROM dual
 UNION ALL

 SELECT 213, 4, 'Porto Grande' FROM dual
 UNION ALL

 SELECT 214, 4, 'Pracuúba' FROM dual
 UNION ALL

 SELECT 215, 4, 'Santana' FROM dual
 UNION ALL

 SELECT 216, 4, 'Serra do Navio' FROM dual
 UNION ALL

 SELECT 217, 4, 'Tartarugalzinho' FROM dual
 UNION ALL

 SELECT 218, 4, 'Vitória do Jari' FROM dual
 UNION ALL

 SELECT 219, 3, 'Alvarães' FROM dual
 UNION ALL

 SELECT 220, 3, 'Amaturá' FROM dual
 UNION ALL

 SELECT 221, 3, 'Anamã' FROM dual
 UNION ALL

 SELECT 222, 3, 'Anori' FROM dual
 UNION ALL

 SELECT 223, 3, 'Apuí' FROM dual
 UNION ALL

 SELECT 224, 3, 'Atalaia do Norte' FROM dual
 UNION ALL

 SELECT 225, 3, 'Autazes' FROM dual
 UNION ALL

 SELECT 226, 3, 'Barcelos' FROM dual
 UNION ALL

 SELECT 227, 3, 'Barreirinha' FROM dual
 UNION ALL

 SELECT 228, 3, 'Benjamin Constant' FROM dual
 UNION ALL

 SELECT 229, 3, 'Beruri' FROM dual
 UNION ALL

 SELECT 230, 3, 'Boa Vista do Ramos' FROM dual
 UNION ALL

 SELECT 231, 3, 'Boca do Acre' FROM dual
 UNION ALL

 SELECT 232, 3, 'Borba' FROM dual
 UNION ALL

 SELECT 233, 3, 'Caapiranga' FROM dual
 UNION ALL

 SELECT 234, 3, 'Canutama' FROM dual
 UNION ALL

 SELECT 235, 3, 'Carauari' FROM dual
 UNION ALL

 SELECT 236, 3, 'Careiro' FROM dual
 UNION ALL

 SELECT 237, 3, 'Careiro da Várzea' FROM dual
 UNION ALL

 SELECT 238, 3, 'Coari' FROM dual
 UNION ALL

 SELECT 239, 3, 'Codajás' FROM dual
 UNION ALL

 SELECT 240, 3, 'Eirunepé' FROM dual
 UNION ALL

 SELECT 241, 3, 'Envira' FROM dual
 UNION ALL

 SELECT 242, 3, 'Fonte Boa' FROM dual
 UNION ALL

 SELECT 243, 3, 'Guajará' FROM dual
 UNION ALL

 SELECT 244, 3, 'Humaitá' FROM dual
 UNION ALL

 SELECT 245, 3, 'Ipixuna' FROM dual
 UNION ALL

 SELECT 246, 3, 'Iranduba' FROM dual
 UNION ALL

 SELECT 247, 3, 'Itacoatiara' FROM dual
 UNION ALL

 SELECT 248, 3, 'Itamarati' FROM dual
 UNION ALL

 SELECT 249, 3, 'Itapiranga' FROM dual
 UNION ALL

 SELECT 250, 3, 'Japurá' FROM dual
 UNION ALL

 SELECT 251, 3, 'Juruá' FROM dual
 UNION ALL

 SELECT 252, 3, 'Jutaí' FROM dual
 UNION ALL

 SELECT 253, 3, 'Lábrea' FROM dual
 UNION ALL

 SELECT 254, 3, 'Manacapuru' FROM dual
 UNION ALL

 SELECT 255, 3, 'Manaquiri' FROM dual
 UNION ALL

 SELECT 256, 3, 'Manaus' FROM dual
 UNION ALL

 SELECT 257, 3, 'Manicoré' FROM dual
 UNION ALL

 SELECT 258, 3, 'Maraã' FROM dual
 UNION ALL

 SELECT 259, 3, 'Maués' FROM dual
 UNION ALL

 SELECT 260, 3, 'Nhamundá' FROM dual
 UNION ALL

 SELECT 261, 3, 'Nova Olinda do Norte' FROM dual
 UNION ALL

 SELECT 262, 3, 'Novo Airão' FROM dual
 UNION ALL

 SELECT 263, 3, 'Novo Aripuanã' FROM dual
 UNION ALL

 SELECT 264, 3, 'Parintins' FROM dual
 UNION ALL

 SELECT 265, 3, 'Pauini' FROM dual
 UNION ALL

 SELECT 266, 3, 'Presidente Figueiredo' FROM dual
 UNION ALL

 SELECT 267, 3, 'Rio Preto da Eva' FROM dual
 UNION ALL

 SELECT 268, 3, 'Santa Isabel do Rio Negro' FROM dual
 UNION ALL

 SELECT 269, 3, 'Santo Antônio do Içá' FROM dual
 UNION ALL

 SELECT 270, 3, 'São Gabriel da Cachoeira' FROM dual
 UNION ALL

 SELECT 271, 3, 'São Paulo de Olivença' FROM dual
 UNION ALL

 SELECT 272, 3, 'São Sebastião do Uatumã' FROM dual
 UNION ALL

 SELECT 273, 3, 'Silves' FROM dual
 UNION ALL

 SELECT 274, 3, 'Tabatinga' FROM dual
 UNION ALL

 SELECT 275, 3, 'Tapauá' FROM dual
 UNION ALL

 SELECT 276, 3, 'Tefé' FROM dual
 UNION ALL

 SELECT 277, 3, 'Tonantins' FROM dual
 UNION ALL

 SELECT 278, 3, 'Uarini' FROM dual
 UNION ALL

 SELECT 279, 3, 'Urucará' FROM dual
 UNION ALL

 SELECT 280, 3, 'Urucurituba' FROM dual
 UNION ALL

 SELECT 281, 5, 'Abaíra' FROM dual
 UNION ALL

 SELECT 282, 5, 'Abaré' FROM dual
 UNION ALL

 SELECT 283, 5, 'Acajutiba' FROM dual
 UNION ALL

 SELECT 284, 5, 'Adustina' FROM dual
 UNION ALL

 SELECT 285, 5, 'Água Fria' FROM dual
 UNION ALL

 SELECT 286, 5, 'Aiquara' FROM dual
 UNION ALL

 SELECT 287, 5, 'Alagoinhas' FROM dual
 UNION ALL

 SELECT 288, 5, 'Alcobaça' FROM dual
 UNION ALL

 SELECT 289, 5, 'Almadina' FROM dual
 UNION ALL

 SELECT 290, 5, 'Amargosa' FROM dual
 UNION ALL

 SELECT 291, 5, 'Amélia Rodrigues' FROM dual
 UNION ALL

 SELECT 292, 5, 'América Dourada' FROM dual
 UNION ALL

 SELECT 293, 5, 'Anagé' FROM dual
 UNION ALL

 SELECT 294, 5, 'Andaraí' FROM dual
 UNION ALL

 SELECT 295, 5, 'Andorinha' FROM dual
 UNION ALL

 SELECT 296, 5, 'Angical' FROM dual
 UNION ALL

 SELECT 297, 5, 'Anguera' FROM dual
 UNION ALL

 SELECT 298, 5, 'Antas' FROM dual
 UNION ALL

 SELECT 299, 5, 'Antônio Cardoso' FROM dual
 UNION ALL

 SELECT 300, 5, 'Antônio Gonçalves' FROM dual
 UNION ALL

 SELECT 301, 5, 'Aporá' FROM dual
 UNION ALL

 SELECT 302, 5, 'Apuarema' FROM dual
 UNION ALL

 SELECT 303, 5, 'Araças' FROM dual
 UNION ALL

 SELECT 304, 5, 'Aracatu' FROM dual
 UNION ALL

 SELECT 305, 5, 'Araci' FROM dual
 UNION ALL

 SELECT 306, 5, 'Aramari' FROM dual
 UNION ALL

 SELECT 307, 5, 'Arataca' FROM dual
 UNION ALL

 SELECT 308, 5, 'Aratuípe' FROM dual
 UNION ALL

 SELECT 309, 5, 'Aurelino Leal' FROM dual
 UNION ALL

 SELECT 310, 5, 'Baianópolis' FROM dual
 UNION ALL

 SELECT 311, 5, 'Baixa Grande' FROM dual
 UNION ALL

 SELECT 312, 5, 'Banzaê' FROM dual
 UNION ALL

 SELECT 313, 5, 'Barra' FROM dual
 UNION ALL

 SELECT 314, 5, 'Barra da Estiva' FROM dual
 UNION ALL

 SELECT 315, 5, 'Barra do Choça' FROM dual
 UNION ALL

 SELECT 316, 5, 'Barra do Mendes' FROM dual
 UNION ALL

 SELECT 317, 5, 'Barra do Rocha' FROM dual
 UNION ALL

 SELECT 318, 5, 'Barreiras' FROM dual
 UNION ALL

 SELECT 319, 5, 'Barro Alto' FROM dual
 UNION ALL

 SELECT 320, 5, 'Barro Preto' FROM dual
 UNION ALL

 SELECT 321, 5, 'Barrocas' FROM dual
 UNION ALL

 SELECT 322, 5, 'Belmonte' FROM dual
 UNION ALL

 SELECT 323, 5, 'Belo Campo' FROM dual
 UNION ALL

 SELECT 324, 5, 'Biritinga' FROM dual
 UNION ALL

 SELECT 325, 5, 'Boa Nova' FROM dual
 UNION ALL

 SELECT 326, 5, 'Boa Vista do Tupim' FROM dual
 UNION ALL

 SELECT 327, 5, 'Bom Jesus da Lapa' FROM dual
 UNION ALL

 SELECT 328, 5, 'Bom Jesus da Serra' FROM dual
 UNION ALL

 SELECT 329, 5, 'Boninal' FROM dual
 UNION ALL

 SELECT 330, 5, 'Bonito' FROM dual
 UNION ALL

 SELECT 331, 5, 'Boquira' FROM dual
 UNION ALL

 SELECT 332, 5, 'Botuporã' FROM dual
 UNION ALL

 SELECT 333, 5, 'Brejões' FROM dual
 UNION ALL

 SELECT 334, 5, 'Brejolândia' FROM dual
 UNION ALL

 SELECT 335, 5, 'Brotas de Macaúbas' FROM dual
 UNION ALL

 SELECT 336, 5, 'Brumado' FROM dual
 UNION ALL

 SELECT 337, 5, 'Buerarema' FROM dual
 UNION ALL

 SELECT 338, 5, 'Buritirama' FROM dual
 UNION ALL

 SELECT 339, 5, 'Caatiba' FROM dual
 UNION ALL

 SELECT 340, 5, 'Cabaceiras do Paraguaçu' FROM dual
 UNION ALL

 SELECT 341, 5, 'Cachoeira' FROM dual
 UNION ALL

 SELECT 342, 5, 'Caculé' FROM dual
 UNION ALL

 SELECT 343, 5, 'Caém' FROM dual
 UNION ALL

 SELECT 344, 5, 'Caetanos' FROM dual
 UNION ALL

 SELECT 345, 5, 'Caetité' FROM dual
 UNION ALL

 SELECT 346, 5, 'Cafarnaum' FROM dual
 UNION ALL

 SELECT 347, 5, 'Cairu' FROM dual
 UNION ALL

 SELECT 348, 5, 'Caldeirão Grande' FROM dual
 UNION ALL

 SELECT 349, 5, 'Camacan' FROM dual
 UNION ALL

 SELECT 350, 5, 'Camaçari' FROM dual
 UNION ALL

 SELECT 351, 5, 'Camamu' FROM dual
 UNION ALL

 SELECT 352, 5, 'Campo Alegre de Lourdes' FROM dual
 UNION ALL

 SELECT 353, 5, 'Campo Formoso' FROM dual
 UNION ALL

 SELECT 354, 5, 'Canápolis' FROM dual
 UNION ALL

 SELECT 355, 5, 'Canarana' FROM dual
 UNION ALL

 SELECT 356, 5, 'Canavieiras' FROM dual
 UNION ALL

 SELECT 357, 5, 'Candeal' FROM dual
 UNION ALL

 SELECT 358, 5, 'Candeias' FROM dual
 UNION ALL

 SELECT 359, 5, 'Candiba' FROM dual
 UNION ALL

 SELECT 360, 5, 'Cândido Sales' FROM dual
 UNION ALL

 SELECT 361, 5, 'Cansanção' FROM dual
 UNION ALL

 SELECT 362, 5, 'Canudos' FROM dual
 UNION ALL

 SELECT 363, 5, 'Capela do Alto Alegre' FROM dual
 UNION ALL

 SELECT 364, 5, 'Capim Grosso' FROM dual
 UNION ALL

 SELECT 365, 5, 'Caraíbas' FROM dual
 UNION ALL

 SELECT 366, 5, 'Caravelas' FROM dual
 UNION ALL

 SELECT 367, 5, 'Cardeal da Silva' FROM dual
 UNION ALL

 SELECT 368, 5, 'Carinhanha' FROM dual
 UNION ALL

 SELECT 369, 5, 'Casa Nova' FROM dual
 UNION ALL

 SELECT 370, 5, 'Castro Alves' FROM dual
 UNION ALL

 SELECT 371, 5, 'Catolândia' FROM dual
 UNION ALL

 SELECT 372, 5, 'Catu' FROM dual
 UNION ALL

 SELECT 373, 5, 'Caturama' FROM dual
 UNION ALL

 SELECT 374, 5, 'Central' FROM dual
 UNION ALL

 SELECT 375, 5, 'Chorrochó' FROM dual
 UNION ALL

 SELECT 376, 5, 'Cícero Dantas' FROM dual
 UNION ALL

 SELECT 377, 5, 'Cipó' FROM dual
 UNION ALL

 SELECT 378, 5, 'Coaraci' FROM dual
 UNION ALL

 SELECT 379, 5, 'Cocos' FROM dual
 UNION ALL

 SELECT 380, 5, 'Conceição da Feira' FROM dual
 UNION ALL

 SELECT 381, 5, 'Conceição do Almeida' FROM dual
 UNION ALL

 SELECT 382, 5, 'Conceição do Coité' FROM dual
 UNION ALL

 SELECT 383, 5, 'Conceição do Jacuípe' FROM dual
 UNION ALL

 SELECT 384, 5, 'Conde' FROM dual
 UNION ALL

 SELECT 385, 5, 'Condeúba' FROM dual
 UNION ALL

 SELECT 386, 5, 'Contendas do Sincorá' FROM dual
 UNION ALL

 SELECT 387, 5, 'Coração de Maria' FROM dual
 UNION ALL

 SELECT 388, 5, 'Cordeiros' FROM dual
 UNION ALL

 SELECT 389, 5, 'Coribe' FROM dual
 UNION ALL

 SELECT 390, 5, 'Coronel João Sá' FROM dual
 UNION ALL

 SELECT 391, 5, 'Correntina' FROM dual
 UNION ALL

 SELECT 392, 5, 'Cotegipe' FROM dual
 UNION ALL

 SELECT 393, 5, 'Cravolândia' FROM dual
 UNION ALL

 SELECT 394, 5, 'Crisópolis' FROM dual
 UNION ALL

 SELECT 395, 5, 'Cristópolis' FROM dual
 UNION ALL

 SELECT 396, 5, 'Cruz das Almas' FROM dual
 UNION ALL

 SELECT 397, 5, 'Curaçá' FROM dual
 UNION ALL

 SELECT 398, 5, 'Dário Meira' FROM dual
 UNION ALL

 SELECT 399, 5, 'Dias d`Ávila' FROM dual
 UNION ALL

 SELECT 400, 5, 'Dom Basílio' FROM dual
 UNION ALL

 SELECT 401, 5, 'Dom Macedo Costa' FROM dual
 UNION ALL

 SELECT 402, 5, 'Elísio Medrado' FROM dual
 UNION ALL

 SELECT 403, 5, 'Encruzilhada' FROM dual
 UNION ALL

 SELECT 404, 5, 'Entre Rios' FROM dual
 UNION ALL

 SELECT 405, 5, 'Érico Cardoso' FROM dual
 UNION ALL

 SELECT 406, 5, 'Esplanada' FROM dual
 UNION ALL

 SELECT 407, 5, 'Euclides da Cunha' FROM dual
 UNION ALL

 SELECT 408, 5, 'Eunápolis' FROM dual
 UNION ALL

 SELECT 409, 5, 'Fátima' FROM dual
 UNION ALL

 SELECT 410, 5, 'Feira da Mata' FROM dual
 UNION ALL

 SELECT 411, 5, 'Feira de Santana' FROM dual
 UNION ALL

 SELECT 412, 5, 'Filadélfia' FROM dual
 UNION ALL

 SELECT 413, 5, 'Firmino Alves' FROM dual
 UNION ALL

 SELECT 414, 5, 'Floresta Azul' FROM dual
 UNION ALL

 SELECT 415, 5, 'Formosa do Rio Preto' FROM dual
 UNION ALL

 SELECT 416, 5, 'Gandu' FROM dual
 UNION ALL

 SELECT 417, 5, 'Gavião' FROM dual
 UNION ALL

 SELECT 418, 5, 'Gentio do Ouro' FROM dual
 UNION ALL

 SELECT 419, 5, 'Glória' FROM dual
 UNION ALL

 SELECT 420, 5, 'Gongogi' FROM dual
 UNION ALL

 SELECT 421, 5, 'Governador Mangabeira' FROM dual
 UNION ALL

 SELECT 422, 5, 'Guajeru' FROM dual
 UNION ALL

 SELECT 423, 5, 'Guanambi' FROM dual
 UNION ALL

 SELECT 424, 5, 'Guaratinga' FROM dual
 UNION ALL

 SELECT 425, 5, 'Heliópolis' FROM dual
 UNION ALL

 SELECT 426, 5, 'Iaçu' FROM dual
 UNION ALL

 SELECT 427, 5, 'Ibiassucê' FROM dual
 UNION ALL

 SELECT 428, 5, 'Ibicaraí' FROM dual
 UNION ALL

 SELECT 429, 5, 'Ibicoara' FROM dual
 UNION ALL

 SELECT 430, 5, 'Ibicuí' FROM dual
 UNION ALL

 SELECT 431, 5, 'Ibipeba' FROM dual
 UNION ALL

 SELECT 432, 5, 'Ibipitanga' FROM dual
 UNION ALL

 SELECT 433, 5, 'Ibiquera' FROM dual
 UNION ALL

 SELECT 434, 5, 'Ibirapitanga' FROM dual
 UNION ALL

 SELECT 435, 5, 'Ibirapuã' FROM dual
 UNION ALL

 SELECT 436, 5, 'Ibirataia' FROM dual
 UNION ALL

 SELECT 437, 5, 'Ibitiara' FROM dual
 UNION ALL

 SELECT 438, 5, 'Ibititá' FROM dual
 UNION ALL

 SELECT 439, 5, 'Ibotirama' FROM dual
 UNION ALL

 SELECT 440, 5, 'Ichu' FROM dual
 UNION ALL

 SELECT 441, 5, 'Igaporã' FROM dual
 UNION ALL

 SELECT 442, 5, 'Igrapiúna' FROM dual
 UNION ALL

 SELECT 443, 5, 'Iguaí' FROM dual
 UNION ALL

 SELECT 444, 5, 'Ilhéus' FROM dual
 UNION ALL

 SELECT 445, 5, 'Inhambupe' FROM dual
 UNION ALL

 SELECT 446, 5, 'Ipecaetá' FROM dual
 UNION ALL

 SELECT 447, 5, 'Ipiaú' FROM dual
 UNION ALL

 SELECT 448, 5, 'Ipirá' FROM dual
 UNION ALL

 SELECT 449, 5, 'Ipupiara' FROM dual
 UNION ALL

 SELECT 450, 5, 'Irajuba' FROM dual
 UNION ALL

 SELECT 451, 5, 'Iramaia' FROM dual
 UNION ALL

 SELECT 452, 5, 'Iraquara' FROM dual
 UNION ALL

 SELECT 453, 5, 'Irará' FROM dual
 UNION ALL

 SELECT 454, 5, 'Irecê' FROM dual
 UNION ALL

 SELECT 455, 5, 'Itabela' FROM dual
 UNION ALL

 SELECT 456, 5, 'Itaberaba' FROM dual
 UNION ALL

 SELECT 457, 5, 'Itabuna' FROM dual
 UNION ALL

 SELECT 458, 5, 'Itacaré' FROM dual
 UNION ALL

 SELECT 459, 5, 'Itaeté' FROM dual
 UNION ALL

 SELECT 460, 5, 'Itagi' FROM dual
 UNION ALL

 SELECT 461, 5, 'Itagibá' FROM dual
 UNION ALL

 SELECT 462, 5, 'Itagimirim' FROM dual
 UNION ALL

 SELECT 463, 5, 'Itaguaçu da Bahia' FROM dual
 UNION ALL

 SELECT 464, 5, 'Itaju do Colônia' FROM dual
 UNION ALL

 SELECT 465, 5, 'Itajuípe' FROM dual
 UNION ALL

 SELECT 466, 5, 'Itamaraju' FROM dual
 UNION ALL

 SELECT 467, 5, 'Itamari' FROM dual
 UNION ALL

 SELECT 468, 5, 'Itambé' FROM dual
 UNION ALL

 SELECT 469, 5, 'Itanagra' FROM dual
 UNION ALL

 SELECT 470, 5, 'Itanhém' FROM dual
 UNION ALL

 SELECT 471, 5, 'Itaparica' FROM dual
 UNION ALL

 SELECT 472, 5, 'Itapé' FROM dual
 UNION ALL

 SELECT 473, 5, 'Itapebi' FROM dual
 UNION ALL

 SELECT 474, 5, 'Itapetinga' FROM dual
 UNION ALL

 SELECT 475, 5, 'Itapicuru' FROM dual
 UNION ALL

 SELECT 476, 5, 'Itapitanga' FROM dual
 UNION ALL

 SELECT 477, 5, 'Itaquara' FROM dual
 UNION ALL

 SELECT 478, 5, 'Itarantim' FROM dual
 UNION ALL

 SELECT 479, 5, 'Itatim' FROM dual
 UNION ALL

 SELECT 480, 5, 'Itiruçu' FROM dual
 UNION ALL

 SELECT 481, 5, 'Itiúba' FROM dual
 UNION ALL

 SELECT 482, 5, 'Itororó' FROM dual
 UNION ALL

 SELECT 483, 5, 'Ituaçu' FROM dual
 UNION ALL

 SELECT 484, 5, 'Ituberá' FROM dual
 UNION ALL

 SELECT 485, 5, 'Iuiú' FROM dual
 UNION ALL

 SELECT 486, 5, 'Jaborandi' FROM dual
 UNION ALL

 SELECT 487, 5, 'Jacaraci' FROM dual
 UNION ALL

 SELECT 488, 5, 'Jacobina' FROM dual
 UNION ALL

 SELECT 489, 5, 'Jaguaquara' FROM dual
 UNION ALL

 SELECT 490, 5, 'Jaguarari' FROM dual
 UNION ALL

 SELECT 491, 5, 'Jaguaripe' FROM dual
 UNION ALL

 SELECT 492, 5, 'Jandaíra' FROM dual
 UNION ALL

 SELECT 493, 5, 'Jequié' FROM dual
 UNION ALL

 SELECT 494, 5, 'Jeremoabo' FROM dual
 UNION ALL

 SELECT 495, 5, 'Jiquiriçá' FROM dual
 UNION ALL

 SELECT 496, 5, 'Jitaúna' FROM dual
 UNION ALL

 SELECT 497, 5, 'João Dourado' FROM dual
 UNION ALL

 SELECT 498, 5, 'Juazeiro' FROM dual
 UNION ALL

 SELECT 499, 5, 'Jucuruçu' FROM dual
 UNION ALL

 SELECT 500, 5, 'Jussara' FROM dual
 UNION ALL

 SELECT 501, 5, 'Jussari' FROM dual
 UNION ALL

 SELECT 502, 5, 'Jussiape' FROM dual
 UNION ALL

 SELECT 503, 5, 'Lafaiete Coutinho' FROM dual
 UNION ALL

 SELECT 504, 5, 'Lagoa Real' FROM dual
 UNION ALL

 SELECT 505, 5, 'Laje' FROM dual
 UNION ALL

 SELECT 506, 5, 'Lajedão' FROM dual
 UNION ALL

 SELECT 507, 5, 'Lajedinho' FROM dual
 UNION ALL

 SELECT 508, 5, 'Lajedo do Tabocal' FROM dual
 UNION ALL

 SELECT 509, 5, 'Lamarão' FROM dual
 UNION ALL

 SELECT 510, 5, 'Lapão' FROM dual
 UNION ALL

 SELECT 511, 5, 'Lauro de Freitas' FROM dual
 UNION ALL

 SELECT 512, 5, 'Lençóis' FROM dual
 UNION ALL

 SELECT 513, 5, 'Licínio de Almeida' FROM dual
 UNION ALL

 SELECT 514, 5, 'Livramento de Nossa Senhora' FROM dual
 UNION ALL

 SELECT 515, 5, 'Luís Eduardo Magalhães' FROM dual
 UNION ALL

 SELECT 516, 5, 'Macajuba' FROM dual
 UNION ALL

 SELECT 517, 5, 'Macarani' FROM dual
 UNION ALL

 SELECT 518, 5, 'Macaúbas' FROM dual
 UNION ALL

 SELECT 519, 5, 'Macururé' FROM dual
 UNION ALL

 SELECT 520, 5, 'Madre de Deus' FROM dual
 UNION ALL

 SELECT 521, 5, 'Maetinga' FROM dual
 UNION ALL

 SELECT 522, 5, 'Maiquinique' FROM dual
 UNION ALL

 SELECT 523, 5, 'Mairi' FROM dual
 UNION ALL

 SELECT 524, 5, 'Malhada' FROM dual
 UNION ALL

 SELECT 525, 5, 'Malhada de Pedras' FROM dual
 UNION ALL

 SELECT 526, 5, 'Manoel Vitorino' FROM dual
 UNION ALL

 SELECT 527, 5, 'Mansidão' FROM dual
 UNION ALL

 SELECT 528, 5, 'Maracás' FROM dual
 UNION ALL

 SELECT 529, 5, 'Maragogipe' FROM dual
 UNION ALL

 SELECT 530, 5, 'Maraú' FROM dual
 UNION ALL

 SELECT 531, 5, 'Marcionílio Souza' FROM dual
 UNION ALL

 SELECT 532, 5, 'Mascote' FROM dual
 UNION ALL

 SELECT 533, 5, 'Mata de São João' FROM dual
 UNION ALL

 SELECT 534, 5, 'Matina' FROM dual
 UNION ALL

 SELECT 535, 5, 'Medeiros Neto' FROM dual
 UNION ALL

 SELECT 536, 5, 'Miguel Calmon' FROM dual
 UNION ALL

 SELECT 537, 5, 'Milagres' FROM dual
 UNION ALL

 SELECT 538, 5, 'Mirangaba' FROM dual
 UNION ALL

 SELECT 539, 5, 'Mirante' FROM dual
 UNION ALL

 SELECT 540, 5, 'Monte Santo' FROM dual
 UNION ALL

 SELECT 541, 5, 'Morpará' FROM dual
 UNION ALL

 SELECT 542, 5, 'Morro do Chapéu' FROM dual
 UNION ALL

 SELECT 543, 5, 'Mortugaba' FROM dual
 UNION ALL

 SELECT 544, 5, 'Mucugê' FROM dual
 UNION ALL

 SELECT 545, 5, 'Mucuri' FROM dual
 UNION ALL

 SELECT 546, 5, 'Mulungu do Morro' FROM dual
 UNION ALL

 SELECT 547, 5, 'Mundo Novo' FROM dual
 UNION ALL

 SELECT 548, 5, 'Muniz Ferreira' FROM dual
 UNION ALL

 SELECT 549, 5, 'Muquém de São Francisco' FROM dual
 UNION ALL

 SELECT 550, 5, 'Muritiba' FROM dual
 UNION ALL

 SELECT 551, 5, 'Mutuípe' FROM dual
 UNION ALL

 SELECT 552, 5, 'Nazaré' FROM dual
 UNION ALL

 SELECT 553, 5, 'Nilo Peçanha' FROM dual
 UNION ALL

 SELECT 554, 5, 'Nordestina' FROM dual
 UNION ALL

 SELECT 555, 5, 'Nova Canaã' FROM dual
 UNION ALL

 SELECT 556, 5, 'Nova Fátima' FROM dual
 UNION ALL

 SELECT 557, 5, 'Nova Ibiá' FROM dual
 UNION ALL

 SELECT 558, 5, 'Nova Itarana' FROM dual
 UNION ALL

 SELECT 559, 5, 'Nova Redenção' FROM dual
 UNION ALL

 SELECT 560, 5, 'Nova Soure' FROM dual
 UNION ALL

 SELECT 561, 5, 'Nova Viçosa' FROM dual
 UNION ALL

 SELECT 562, 5, 'Novo Horizonte' FROM dual
 UNION ALL

 SELECT 563, 5, 'Novo Triunfo' FROM dual
 UNION ALL

 SELECT 564, 5, 'Olindina' FROM dual
 UNION ALL

 SELECT 565, 5, 'Oliveira dos Brejinhos' FROM dual
 UNION ALL

 SELECT 566, 5, 'Ouriçangas' FROM dual
 UNION ALL

 SELECT 567, 5, 'Ourolândia' FROM dual
 UNION ALL

 SELECT 568, 5, 'Palmas de Monte Alto' FROM dual
 UNION ALL

 SELECT 569, 5, 'Palmeiras' FROM dual
 UNION ALL

 SELECT 570, 5, 'Paramirim' FROM dual
 UNION ALL

 SELECT 571, 5, 'Paratinga' FROM dual
 UNION ALL

 SELECT 572, 5, 'Paripiranga' FROM dual
 UNION ALL

 SELECT 573, 5, 'Pau Brasil' FROM dual
 UNION ALL

 SELECT 574, 5, 'Paulo Afonso' FROM dual
 UNION ALL

 SELECT 575, 5, 'Pé de Serra' FROM dual
 UNION ALL

 SELECT 576, 5, 'Pedrão' FROM dual
 UNION ALL

 SELECT 577, 5, 'Pedro Alexandre' FROM dual
 UNION ALL

 SELECT 578, 5, 'Piatã' FROM dual
 UNION ALL

 SELECT 579, 5, 'Pilão Arcado' FROM dual
 UNION ALL

 SELECT 580, 5, 'Pindaí' FROM dual
 UNION ALL

 SELECT 581, 5, 'Pindobaçu' FROM dual
 UNION ALL

 SELECT 582, 5, 'Pintadas' FROM dual
 UNION ALL

 SELECT 583, 5, 'Piraí do Norte' FROM dual
 UNION ALL

 SELECT 584, 5, 'Piripá' FROM dual
 UNION ALL

 SELECT 585, 5, 'Piritiba' FROM dual
 UNION ALL

 SELECT 586, 5, 'Planaltino' FROM dual
 UNION ALL

 SELECT 587, 5, 'Planalto' FROM dual
 UNION ALL

 SELECT 588, 5, 'Poções' FROM dual
 UNION ALL

 SELECT 589, 5, 'Pojuca' FROM dual
 UNION ALL

 SELECT 590, 5, 'Ponto Novo' FROM dual
 UNION ALL

 SELECT 591, 5, 'Porto Seguro' FROM dual
 UNION ALL

 SELECT 592, 5, 'Potiraguá' FROM dual
 UNION ALL

 SELECT 593, 5, 'Prado' FROM dual
 UNION ALL

 SELECT 594, 5, 'Presidente Dutra' FROM dual
 UNION ALL

 SELECT 595, 5, 'Presidente Jânio Quadros' FROM dual
 UNION ALL

 SELECT 596, 5, 'Presidente Tancredo Neves' FROM dual
 UNION ALL

 SELECT 597, 5, 'Queimadas' FROM dual
 UNION ALL

 SELECT 598, 5, 'Quijingue' FROM dual
 UNION ALL

 SELECT 599, 5, 'Quixabeira' FROM dual
 UNION ALL

 SELECT 600, 5, 'Rafael Jambeiro' FROM dual
 UNION ALL

 SELECT 601, 5, 'Remanso' FROM dual
 UNION ALL

 SELECT 602, 5, 'Retirolândia' FROM dual
 UNION ALL

 SELECT 603, 5, 'Riachão das Neves' FROM dual
 UNION ALL

 SELECT 604, 5, 'Riachão do Jacuípe' FROM dual
 UNION ALL

 SELECT 605, 5, 'Riacho de Santana' FROM dual
 UNION ALL

 SELECT 606, 5, 'Ribeira do Amparo' FROM dual
 UNION ALL

 SELECT 607, 5, 'Ribeira do Pombal' FROM dual
 UNION ALL

 SELECT 608, 5, 'Ribeirão do Largo' FROM dual
 UNION ALL

 SELECT 609, 5, 'Rio de Contas' FROM dual
 UNION ALL

 SELECT 610, 5, 'Rio do Antônio' FROM dual
 UNION ALL

 SELECT 611, 5, 'Rio do Pires' FROM dual
 UNION ALL

 SELECT 612, 5, 'Rio Real' FROM dual
 UNION ALL

 SELECT 613, 5, 'Rodelas' FROM dual
 UNION ALL

 SELECT 614, 5, 'Ruy Barbosa' FROM dual
 UNION ALL

 SELECT 615, 5, 'Salinas da Margarida' FROM dual
 UNION ALL

 SELECT 616, 5, 'Salvador' FROM dual
 UNION ALL

 SELECT 617, 5, 'Santa Bárbara' FROM dual
 UNION ALL

 SELECT 618, 5, 'Santa Brígida' FROM dual
 UNION ALL

 SELECT 619, 5, 'Santa Cruz Cabrália' FROM dual
 UNION ALL

 SELECT 620, 5, 'Santa Cruz da Vitória' FROM dual
 UNION ALL

 SELECT 621, 5, 'Santa Inês' FROM dual
 UNION ALL

 SELECT 622, 5, 'Santa Luzia' FROM dual
 UNION ALL

 SELECT 623, 5, 'Santa Maria da Vitória' FROM dual
 UNION ALL

 SELECT 624, 5, 'Santa Rita de Cássia' FROM dual
 UNION ALL

 SELECT 625, 5, 'Santa Teresinha' FROM dual
 UNION ALL

 SELECT 626, 5, 'Santaluz' FROM dual
 UNION ALL

 SELECT 627, 5, 'Santana' FROM dual
 UNION ALL

 SELECT 628, 5, 'Santanópolis' FROM dual
 UNION ALL

 SELECT 629, 5, 'Santo Amaro' FROM dual
 UNION ALL

 SELECT 630, 5, 'Santo Antônio de Jesus' FROM dual
 UNION ALL

 SELECT 631, 5, 'Santo Estêvão' FROM dual
 UNION ALL

 SELECT 632, 5, 'São Desidério' FROM dual
 UNION ALL

 SELECT 633, 5, 'São Domingos' FROM dual
 UNION ALL

 SELECT 634, 5, 'São Felipe' FROM dual
 UNION ALL

 SELECT 635, 5, 'São Félix' FROM dual
 UNION ALL

 SELECT 636, 5, 'São Félix do Coribe' FROM dual
 UNION ALL

 SELECT 637, 5, 'São Francisco do Conde' FROM dual
 UNION ALL

 SELECT 638, 5, 'São Gabriel' FROM dual
 UNION ALL

 SELECT 639, 5, 'São Gonçalo dos Campos' FROM dual
 UNION ALL

 SELECT 640, 5, 'São José da Vitória' FROM dual
 UNION ALL

 SELECT 641, 5, 'São José do Jacuípe' FROM dual
 UNION ALL

 SELECT 642, 5, 'São Miguel das Matas' FROM dual
 UNION ALL

 SELECT 643, 5, 'São Sebastião do Passé' FROM dual
 UNION ALL

 SELECT 644, 5, 'Sapeaçu' FROM dual
 UNION ALL

 SELECT 645, 5, 'Sátiro Dias' FROM dual
 UNION ALL

 SELECT 646, 5, 'Saubara' FROM dual
 UNION ALL

 SELECT 647, 5, 'Saúde' FROM dual
 UNION ALL

 SELECT 648, 5, 'Seabra' FROM dual
 UNION ALL

 SELECT 649, 5, 'Sebastião Laranjeiras' FROM dual
 UNION ALL

 SELECT 650, 5, 'Senhor do Bonfim' FROM dual
 UNION ALL

 SELECT 651, 5, 'Sento Sé' FROM dual
 UNION ALL

 SELECT 652, 5, 'Serra do Ramalho' FROM dual
 UNION ALL

 SELECT 653, 5, 'Serra Dourada' FROM dual
 UNION ALL

 SELECT 654, 5, 'Serra Preta' FROM dual
 UNION ALL

 SELECT 655, 5, 'Serrinha' FROM dual
 UNION ALL

 SELECT 656, 5, 'Serrolândia' FROM dual
 UNION ALL

 SELECT 657, 5, 'Simões Filho' FROM dual
 UNION ALL

 SELECT 658, 5, 'Sítio do Mato' FROM dual
 UNION ALL

 SELECT 659, 5, 'Sítio do Quinto' FROM dual
 UNION ALL

 SELECT 660, 5, 'Sobradinho' FROM dual
 UNION ALL

 SELECT 661, 5, 'Souto Soares' FROM dual
 UNION ALL

 SELECT 662, 5, 'Tabocas do Brejo Velho' FROM dual
 UNION ALL

 SELECT 663, 5, 'Tanhaçu' FROM dual
 UNION ALL

 SELECT 664, 5, 'Tanque Novo' FROM dual
 UNION ALL

 SELECT 665, 5, 'Tanquinho' FROM dual
 UNION ALL

 SELECT 666, 5, 'Taperoá' FROM dual
 UNION ALL

 SELECT 667, 5, 'Tapiramutá' FROM dual
 UNION ALL

 SELECT 668, 5, 'Teixeira de Freitas' FROM dual
 UNION ALL

 SELECT 669, 5, 'Teodoro Sampaio' FROM dual
 UNION ALL

 SELECT 670, 5, 'Teofilândia' FROM dual
 UNION ALL

 SELECT 671, 5, 'Teolândia' FROM dual
 UNION ALL

 SELECT 672, 5, 'Terra Nova' FROM dual
 UNION ALL

 SELECT 673, 5, 'Tremedal' FROM dual
 UNION ALL

 SELECT 674, 5, 'Tucano' FROM dual
 UNION ALL

 SELECT 675, 5, 'Uauá' FROM dual
 UNION ALL

 SELECT 676, 5, 'Ubaíra' FROM dual
 UNION ALL

 SELECT 677, 5, 'Ubaitaba' FROM dual
 UNION ALL

 SELECT 678, 5, 'Ubatã' FROM dual
 UNION ALL

 SELECT 679, 5, 'Uibaí' FROM dual
 UNION ALL

 SELECT 680, 5, 'Umburanas' FROM dual
 UNION ALL

 SELECT 681, 5, 'Una' FROM dual
 UNION ALL

 SELECT 682, 5, 'Urandi' FROM dual
 UNION ALL

 SELECT 683, 5, 'Uruçuca' FROM dual
 UNION ALL

 SELECT 684, 5, 'Utinga' FROM dual
 UNION ALL

 SELECT 685, 5, 'Valença' FROM dual
 UNION ALL

 SELECT 686, 5, 'Valente' FROM dual
 UNION ALL

 SELECT 687, 5, 'Várzea da Roça' FROM dual
 UNION ALL

 SELECT 688, 5, 'Várzea do Poço' FROM dual
 UNION ALL

 SELECT 689, 5, 'Várzea Nova' FROM dual
 UNION ALL

 SELECT 690, 5, 'Varzedo' FROM dual
 UNION ALL

 SELECT 691, 5, 'Vera Cruz' FROM dual
 UNION ALL

 SELECT 692, 5, 'Vereda' FROM dual
 UNION ALL

 SELECT 693, 5, 'Vitória da Conquista' FROM dual
 UNION ALL

 SELECT 694, 5, 'Wagner' FROM dual
 UNION ALL

 SELECT 695, 5, 'Wanderley' FROM dual
 UNION ALL

 SELECT 696, 5, 'Wenceslau Guimarães' FROM dual
 UNION ALL

 SELECT 697, 5, 'Xique-Xique' FROM dual
 UNION ALL

 SELECT 698, 6, 'Abaiara' FROM dual
 UNION ALL

 SELECT 699, 6, 'Acarape' FROM dual
 UNION ALL

 SELECT 700, 6, 'Acaraú' FROM dual
 UNION ALL

 SELECT 701, 6, 'Acopiara' FROM dual
 UNION ALL

 SELECT 702, 6, 'Aiuaba' FROM dual
 UNION ALL

 SELECT 703, 6, 'Alcântaras' FROM dual
 UNION ALL

 SELECT 704, 6, 'Altaneira' FROM dual
 UNION ALL

 SELECT 705, 6, 'Alto Santo' FROM dual
 UNION ALL

 SELECT 706, 6, 'Amontada' FROM dual
 UNION ALL

 SELECT 707, 6, 'Antonina do Norte' FROM dual
 UNION ALL

 SELECT 708, 6, 'Apuiarés' FROM dual
 UNION ALL

 SELECT 709, 6, 'Aquiraz' FROM dual
 UNION ALL

 SELECT 710, 6, 'Aracati' FROM dual
 UNION ALL

 SELECT 711, 6, 'Aracoiaba' FROM dual
 UNION ALL

 SELECT 712, 6, 'Ararendá' FROM dual
 UNION ALL

 SELECT 713, 6, 'Araripe' FROM dual
 UNION ALL

 SELECT 714, 6, 'Aratuba' FROM dual
 UNION ALL

 SELECT 715, 6, 'Arneiroz' FROM dual
 UNION ALL

 SELECT 716, 6, 'Assaré' FROM dual
 UNION ALL

 SELECT 717, 6, 'Aurora' FROM dual
 UNION ALL

 SELECT 718, 6, 'Baixio' FROM dual
 UNION ALL

 SELECT 719, 6, 'Banabuiú' FROM dual
 UNION ALL

 SELECT 720, 6, 'Barbalha' FROM dual
 UNION ALL

 SELECT 721, 6, 'Barreira' FROM dual
 UNION ALL

 SELECT 722, 6, 'Barro' FROM dual
 UNION ALL

 SELECT 723, 6, 'Barroquinha' FROM dual
 UNION ALL

 SELECT 724, 6, 'Baturité' FROM dual
 UNION ALL

 SELECT 725, 6, 'Beberibe' FROM dual
 UNION ALL

 SELECT 726, 6, 'Bela Cruz' FROM dual
 UNION ALL

 SELECT 727, 6, 'Boa Viagem' FROM dual
 UNION ALL

 SELECT 728, 6, 'Brejo Santo' FROM dual
 UNION ALL

 SELECT 729, 6, 'Camocim' FROM dual
 UNION ALL

 SELECT 730, 6, 'Campos Sales' FROM dual
 UNION ALL

 SELECT 731, 6, 'Canindé' FROM dual
 UNION ALL

 SELECT 732, 6, 'Capistrano' FROM dual
 UNION ALL

 SELECT 733, 6, 'Caridade' FROM dual
 UNION ALL

 SELECT 734, 6, 'Cariré' FROM dual
 UNION ALL

 SELECT 735, 6, 'Caririaçu' FROM dual
 UNION ALL

 SELECT 736, 6, 'Cariús' FROM dual
 UNION ALL

 SELECT 737, 6, 'Carnaubal' FROM dual
 UNION ALL

 SELECT 738, 6, 'Cascavel' FROM dual
 UNION ALL

 SELECT 739, 6, 'Catarina' FROM dual
 UNION ALL

 SELECT 740, 6, 'Catunda' FROM dual
 UNION ALL

 SELECT 741, 6, 'Caucaia' FROM dual
 UNION ALL

 SELECT 742, 6, 'Cedro' FROM dual
 UNION ALL

 SELECT 743, 6, 'Chaval' FROM dual
 UNION ALL

 SELECT 744, 6, 'Choró' FROM dual
 UNION ALL

 SELECT 745, 6, 'Chorozinho' FROM dual
 UNION ALL

 SELECT 746, 6, 'Coreaú' FROM dual
 UNION ALL

 SELECT 747, 6, 'Crateús' FROM dual
 UNION ALL

 SELECT 748, 6, 'Crato' FROM dual
 UNION ALL

 SELECT 749, 6, 'Croatá' FROM dual
 UNION ALL

 SELECT 750, 6, 'Cruz' FROM dual
 UNION ALL

 SELECT 751, 6, 'Deputado Irapuan Pinheiro' FROM dual
 UNION ALL

 SELECT 752, 6, 'Ererê' FROM dual
 UNION ALL

 SELECT 753, 6, 'Eusébio' FROM dual
 UNION ALL

 SELECT 754, 6, 'Farias Brito' FROM dual
 UNION ALL

 SELECT 755, 6, 'Forquilha' FROM dual
 UNION ALL

 SELECT 756, 6, 'Fortaleza' FROM dual
 UNION ALL

 SELECT 757, 6, 'Fortim' FROM dual
 UNION ALL

 SELECT 758, 6, 'Frecheirinha' FROM dual
 UNION ALL

 SELECT 759, 6, 'General Sampaio' FROM dual
 UNION ALL

 SELECT 760, 6, 'Graça' FROM dual
 UNION ALL

 SELECT 761, 6, 'Granja' FROM dual
 UNION ALL

 SELECT 762, 6, 'Granjeiro' FROM dual
 UNION ALL

 SELECT 763, 6, 'Groaíras' FROM dual
 UNION ALL

 SELECT 764, 6, 'Guaiúba' FROM dual
 UNION ALL

 SELECT 765, 6, 'Guaraciaba do Norte' FROM dual
 UNION ALL

 SELECT 766, 6, 'Guaramiranga' FROM dual
 UNION ALL

 SELECT 767, 6, 'Hidrolândia' FROM dual
 UNION ALL

 SELECT 768, 6, 'Horizonte' FROM dual
 UNION ALL

 SELECT 769, 6, 'Ibaretama' FROM dual
 UNION ALL

 SELECT 770, 6, 'Ibiapina' FROM dual
 UNION ALL

 SELECT 771, 6, 'Ibicuitinga' FROM dual
 UNION ALL

 SELECT 772, 6, 'Icapuí' FROM dual
 UNION ALL

 SELECT 773, 6, 'Icó' FROM dual
 UNION ALL

 SELECT 774, 6, 'Iguatu' FROM dual
 UNION ALL

 SELECT 775, 6, 'Independência' FROM dual
 UNION ALL

 SELECT 776, 6, 'Ipaporanga' FROM dual
 UNION ALL

 SELECT 777, 6, 'Ipaumirim' FROM dual
 UNION ALL

 SELECT 778, 6, 'Ipu' FROM dual
 UNION ALL

 SELECT 779, 6, 'Ipueiras' FROM dual
 UNION ALL

 SELECT 780, 6, 'Iracema' FROM dual
 UNION ALL

 SELECT 781, 6, 'Irauçuba' FROM dual
 UNION ALL

 SELECT 782, 6, 'Itaiçaba' FROM dual
 UNION ALL

 SELECT 783, 6, 'Itaitinga' FROM dual
 UNION ALL

 SELECT 784, 6, 'Itapagé' FROM dual
 UNION ALL

 SELECT 785, 6, 'Itapipoca' FROM dual
 UNION ALL

 SELECT 786, 6, 'Itapiúna' FROM dual
 UNION ALL

 SELECT 787, 6, 'Itarema' FROM dual
 UNION ALL

 SELECT 788, 6, 'Itatira' FROM dual
 UNION ALL

 SELECT 789, 6, 'Jaguaretama' FROM dual
 UNION ALL

 SELECT 790, 6, 'Jaguaribara' FROM dual
 UNION ALL

 SELECT 791, 6, 'Jaguaribe' FROM dual
 UNION ALL

 SELECT 792, 6, 'Jaguaruana' FROM dual
 UNION ALL

 SELECT 793, 6, 'Jardim' FROM dual
 UNION ALL

 SELECT 794, 6, 'Jati' FROM dual
 UNION ALL

 SELECT 795, 6, 'Jijoca de Jericoacoara' FROM dual
 UNION ALL

 SELECT 796, 6, 'Juazeiro do Norte' FROM dual
 UNION ALL

 SELECT 797, 6, 'Jucás' FROM dual
 UNION ALL

 SELECT 798, 6, 'Lavras da Mangabeira' FROM dual
 UNION ALL

 SELECT 799, 6, 'Limoeiro do Norte' FROM dual
 UNION ALL

 SELECT 800, 6, 'Madalena' FROM dual
 UNION ALL

 SELECT 801, 6, 'Maracanaú' FROM dual
 UNION ALL

 SELECT 802, 6, 'Maranguape' FROM dual
 UNION ALL

 SELECT 803, 6, 'Marco' FROM dual
 UNION ALL

 SELECT 804, 6, 'Martinópole' FROM dual
 UNION ALL

 SELECT 805, 6, 'Massapê' FROM dual
 UNION ALL

 SELECT 806, 6, 'Mauriti' FROM dual
 UNION ALL

 SELECT 807, 6, 'Meruoca' FROM dual
 UNION ALL

 SELECT 808, 6, 'Milagres' FROM dual
 UNION ALL

 SELECT 809, 6, 'Milhã' FROM dual
 UNION ALL

 SELECT 810, 6, 'Miraíma' FROM dual
 UNION ALL

 SELECT 811, 6, 'Missão Velha' FROM dual
 UNION ALL

 SELECT 812, 6, 'Mombaça' FROM dual
 UNION ALL

 SELECT 813, 6, 'Monsenhor Tabosa' FROM dual
 UNION ALL

 SELECT 814, 6, 'Morada Nova' FROM dual
 UNION ALL

 SELECT 815, 6, 'Moraújo' FROM dual
 UNION ALL

 SELECT 816, 6, 'Morrinhos' FROM dual
 UNION ALL

 SELECT 817, 6, 'Mucambo' FROM dual
 UNION ALL

 SELECT 818, 6, 'Mulungu' FROM dual
 UNION ALL

 SELECT 819, 6, 'Nova Olinda' FROM dual
 UNION ALL

 SELECT 820, 6, 'Nova Russas' FROM dual
 UNION ALL

 SELECT 821, 6, 'Novo Oriente' FROM dual
 UNION ALL

 SELECT 822, 6, 'Ocara' FROM dual
 UNION ALL

 SELECT 823, 6, 'Orós' FROM dual
 UNION ALL

 SELECT 824, 6, 'Pacajus' FROM dual
 UNION ALL

 SELECT 825, 6, 'Pacatuba' FROM dual
 UNION ALL

 SELECT 826, 6, 'Pacoti' FROM dual
 UNION ALL

 SELECT 827, 6, 'Pacujá' FROM dual
 UNION ALL

 SELECT 828, 6, 'Palhano' FROM dual
 UNION ALL

 SELECT 829, 6, 'Palmácia' FROM dual
 UNION ALL

 SELECT 830, 6, 'Paracuru' FROM dual
 UNION ALL

 SELECT 831, 6, 'Paraipaba' FROM dual
 UNION ALL

 SELECT 832, 6, 'Parambu' FROM dual
 UNION ALL

 SELECT 833, 6, 'Paramoti' FROM dual
 UNION ALL

 SELECT 834, 6, 'Pedra Branca' FROM dual
 UNION ALL

 SELECT 835, 6, 'Penaforte' FROM dual
 UNION ALL

 SELECT 836, 6, 'Pentecoste' FROM dual
 UNION ALL

 SELECT 837, 6, 'Pereiro' FROM dual
 UNION ALL

 SELECT 838, 6, 'Pindoretama' FROM dual
 UNION ALL

 SELECT 839, 6, 'Piquet Carneiro' FROM dual
 UNION ALL

 SELECT 840, 6, 'Pires Ferreira' FROM dual
 UNION ALL

 SELECT 841, 6, 'Poranga' FROM dual
 UNION ALL

 SELECT 842, 6, 'Porteiras' FROM dual
 UNION ALL

 SELECT 843, 6, 'Potengi' FROM dual
 UNION ALL

 SELECT 844, 6, 'Potiretama' FROM dual
 UNION ALL

 SELECT 845, 6, 'Quiterianópolis' FROM dual
 UNION ALL

 SELECT 846, 6, 'Quixadá' FROM dual
 UNION ALL

 SELECT 847, 6, 'Quixelô' FROM dual
 UNION ALL

 SELECT 848, 6, 'Quixeramobim' FROM dual
 UNION ALL

 SELECT 849, 6, 'Quixeré' FROM dual
 UNION ALL

 SELECT 850, 6, 'Redenção' FROM dual
 UNION ALL

 SELECT 851, 6, 'Reriutaba' FROM dual
 UNION ALL

 SELECT 852, 6, 'Russas' FROM dual
 UNION ALL

 SELECT 853, 6, 'Saboeiro' FROM dual
 UNION ALL

 SELECT 854, 6, 'Salitre' FROM dual
 UNION ALL

 SELECT 855, 6, 'Santa Quitéria' FROM dual
 UNION ALL

 SELECT 856, 6, 'Santana do Acaraú' FROM dual
 UNION ALL

 SELECT 857, 6, 'Santana do Cariri' FROM dual
 UNION ALL

 SELECT 858, 6, 'São Benedito' FROM dual
 UNION ALL

 SELECT 859, 6, 'São Gonçalo do Amarante' FROM dual
 UNION ALL

 SELECT 860, 6, 'São João do Jaguaribe' FROM dual
 UNION ALL

 SELECT 861, 6, 'São Luís do Curu' FROM dual
 UNION ALL

 SELECT 862, 6, 'Senador Pompeu' FROM dual
 UNION ALL

 SELECT 863, 6, 'Senador Sá' FROM dual
 UNION ALL

 SELECT 864, 6, 'Sobral' FROM dual
 UNION ALL

 SELECT 865, 6, 'Solonópole' FROM dual
 UNION ALL

 SELECT 866, 6, 'Tabuleiro do Norte' FROM dual
 UNION ALL

 SELECT 867, 6, 'Tamboril' FROM dual
 UNION ALL

 SELECT 868, 6, 'Tarrafas' FROM dual
 UNION ALL

 SELECT 869, 6, 'Tauá' FROM dual
 UNION ALL

 SELECT 870, 6, 'Tejuçuoca' FROM dual
 UNION ALL

 SELECT 871, 6, 'Tianguá' FROM dual
 UNION ALL

 SELECT 872, 6, 'Trairi' FROM dual
 UNION ALL

 SELECT 873, 6, 'Tururu' FROM dual
 UNION ALL

 SELECT 874, 6, 'Ubajara' FROM dual
 UNION ALL

 SELECT 875, 6, 'Umari' FROM dual
 UNION ALL

 SELECT 876, 6, 'Umirim' FROM dual
 UNION ALL

 SELECT 877, 6, 'Uruburetama' FROM dual
 UNION ALL

 SELECT 878, 6, 'Uruoca' FROM dual
 UNION ALL

 SELECT 879, 6, 'Varjota' FROM dual
 UNION ALL

 SELECT 880, 6, 'Várzea Alegre' FROM dual
 UNION ALL

 SELECT 881, 6, 'Viçosa do Ceará' FROM dual
 UNION ALL

 SELECT 882, 7, 'Brasília' FROM dual
 UNION ALL

 SELECT 883, 9, 'Abadia de Goiás' FROM dual
 UNION ALL

 SELECT 884, 9, 'Abadiânia' FROM dual
 UNION ALL

 SELECT 885, 9, 'Acreúna' FROM dual
 UNION ALL

 SELECT 886, 9, 'Adelândia' FROM dual
 UNION ALL

 SELECT 887, 9, 'Água Fria de Goiás' FROM dual
 UNION ALL

 SELECT 888, 9, 'Água Limpa' FROM dual
 UNION ALL

 SELECT 889, 9, 'Águas Lindas de Goiás' FROM dual
 UNION ALL

 SELECT 890, 9, 'Alexânia' FROM dual
 UNION ALL

 SELECT 891, 9, 'Aloândia' FROM dual
 UNION ALL

 SELECT 892, 9, 'Alto Horizonte' FROM dual
 UNION ALL

 SELECT 893, 9, 'Alto Paraíso de Goiás' FROM dual
 UNION ALL

 SELECT 894, 9, 'Alvorada do Norte' FROM dual
 UNION ALL

 SELECT 895, 9, 'Amaralina' FROM dual
 UNION ALL

 SELECT 896, 9, 'Americano do Brasil' FROM dual
 UNION ALL

 SELECT 897, 9, 'Amorinópolis' FROM dual
 UNION ALL

 SELECT 898, 9, 'Anápolis' FROM dual
 UNION ALL

 SELECT 899, 9, 'Anhanguera' FROM dual
 UNION ALL

 SELECT 900, 9, 'Anicuns' FROM dual
 UNION ALL

 SELECT 901, 9, 'Aparecida de Goiânia' FROM dual
 UNION ALL

 SELECT 902, 9, 'Aparecida do Rio Doce' FROM dual
 UNION ALL

 SELECT 903, 9, 'Aporé' FROM dual
 UNION ALL

 SELECT 904, 9, 'Araçu' FROM dual
 UNION ALL

 SELECT 905, 9, 'Aragarças' FROM dual
 UNION ALL

 SELECT 906, 9, 'Aragoiânia' FROM dual
 UNION ALL

 SELECT 907, 9, 'Araguapaz' FROM dual
 UNION ALL

 SELECT 908, 9, 'Arenópolis' FROM dual
 UNION ALL

 SELECT 909, 9, 'Aruanã' FROM dual
 UNION ALL

 SELECT 910, 9, 'Aurilândia' FROM dual
 UNION ALL

 SELECT 911, 9, 'Avelinópolis' FROM dual
 UNION ALL

 SELECT 912, 9, 'Baliza' FROM dual
 UNION ALL

 SELECT 913, 9, 'Barro Alto' FROM dual
 UNION ALL

 SELECT 914, 9, 'Bela Vista de Goiás' FROM dual
 UNION ALL

 SELECT 915, 9, 'Bom Jardim de Goiás' FROM dual
 UNION ALL

 SELECT 916, 9, 'Bom Jesus de Goiás' FROM dual
 UNION ALL

 SELECT 917, 9, 'Bonfinópolis' FROM dual
 UNION ALL

 SELECT 918, 9, 'Bonópolis' FROM dual
 UNION ALL

 SELECT 919, 9, 'Brazabrantes' FROM dual
 UNION ALL

 SELECT 920, 9, 'Britânia' FROM dual
 UNION ALL

 SELECT 921, 9, 'Buriti Alegre' FROM dual
 UNION ALL

 SELECT 922, 9, 'Buriti de Goiás' FROM dual
 UNION ALL

 SELECT 923, 9, 'Buritinópolis' FROM dual
 UNION ALL

 SELECT 924, 9, 'Cabeceiras' FROM dual
 UNION ALL

 SELECT 925, 9, 'Cachoeira Alta' FROM dual
 UNION ALL

 SELECT 926, 9, 'Cachoeira de Goiás' FROM dual
 UNION ALL

 SELECT 927, 9, 'Cachoeira Dourada' FROM dual
 UNION ALL

 SELECT 928, 9, 'Caçu' FROM dual
 UNION ALL

 SELECT 929, 9, 'Caiapônia' FROM dual
 UNION ALL

 SELECT 930, 9, 'Caldas Novas' FROM dual
 UNION ALL

 SELECT 931, 9, 'Caldazinha' FROM dual
 UNION ALL

 SELECT 932, 9, 'Campestre de Goiás' FROM dual
 UNION ALL

 SELECT 933, 9, 'Campinaçu' FROM dual
 UNION ALL

 SELECT 934, 9, 'Campinorte' FROM dual
 UNION ALL

 SELECT 935, 9, 'Campo Alegre de Goiás' FROM dual
 UNION ALL

 SELECT 936, 9, 'Campo Limpo de Goiás' FROM dual
 UNION ALL

 SELECT 937, 9, 'Campos Belos' FROM dual
 UNION ALL

 SELECT 938, 9, 'Campos Verdes' FROM dual
 UNION ALL

 SELECT 939, 9, 'Carmo do Rio Verde' FROM dual
 UNION ALL

 SELECT 940, 9, 'Castelândia' FROM dual
 UNION ALL

 SELECT 941, 9, 'Catalão' FROM dual
 UNION ALL

 SELECT 942, 9, 'Caturaí' FROM dual
 UNION ALL

 SELECT 943, 9, 'Cavalcante' FROM dual
 UNION ALL

 SELECT 944, 9, 'Ceres' FROM dual
 UNION ALL

 SELECT 945, 9, 'Cezarina' FROM dual
 UNION ALL

 SELECT 946, 9, 'Chapadão do Céu' FROM dual
 UNION ALL

 SELECT 947, 9, 'Cidade Ocidental' FROM dual
 UNION ALL

 SELECT 948, 9, 'Cocalzinho de Goiás' FROM dual
 UNION ALL

 SELECT 949, 9, 'Colinas do Sul' FROM dual
 UNION ALL

 SELECT 950, 9, 'Córrego do Ouro' FROM dual
 UNION ALL

 SELECT 951, 9, 'Corumbá de Goiás' FROM dual
 UNION ALL

 SELECT 952, 9, 'Corumbaíba' FROM dual
 UNION ALL

 SELECT 953, 9, 'Cristalina' FROM dual
 UNION ALL

 SELECT 954, 9, 'Cristianópolis' FROM dual
 UNION ALL

 SELECT 955, 9, 'Crixás' FROM dual
 UNION ALL

 SELECT 956, 9, 'Cromínia' FROM dual
 UNION ALL

 SELECT 957, 9, 'Cumari' FROM dual
 UNION ALL

 SELECT 958, 9, 'Damianópolis' FROM dual
 UNION ALL

 SELECT 959, 9, 'Damolândia' FROM dual
 UNION ALL

 SELECT 960, 9, 'Davinópolis' FROM dual
 UNION ALL

 SELECT 961, 9, 'Diorama' FROM dual
 UNION ALL

 SELECT 962, 9, 'Divinópolis de Goiás' FROM dual
 UNION ALL

 SELECT 963, 9, 'Doverlândia' FROM dual
 UNION ALL

 SELECT 964, 9, 'Edealina' FROM dual
 UNION ALL

 SELECT 965, 9, 'Edéia' FROM dual
 UNION ALL

 SELECT 966, 9, 'Estrela do Norte' FROM dual
 UNION ALL

 SELECT 967, 9, 'Faina' FROM dual
 UNION ALL

 SELECT 968, 9, 'Fazenda Nova' FROM dual
 UNION ALL

 SELECT 969, 9, 'Firminópolis' FROM dual
 UNION ALL

 SELECT 970, 9, 'Flores de Goiás' FROM dual
 UNION ALL

 SELECT 971, 9, 'Formosa' FROM dual
 UNION ALL

 SELECT 972, 9, 'Formoso' FROM dual
 UNION ALL

 SELECT 973, 9, 'Gameleira de Goiás' FROM dual
 UNION ALL

 SELECT 974, 9, 'Goianápolis' FROM dual
 UNION ALL

 SELECT 975, 9, 'Goiandira' FROM dual
 UNION ALL

 SELECT 976, 9, 'Goianésia' FROM dual
 UNION ALL

 SELECT 977, 9, 'Goiânia' FROM dual
 UNION ALL

 SELECT 978, 9, 'Goianira' FROM dual
 UNION ALL

 SELECT 979, 9, 'Goiás' FROM dual
 UNION ALL

 SELECT 980, 9, 'Goiatuba' FROM dual
 UNION ALL

 SELECT 981, 9, 'Gouvelândia' FROM dual
 UNION ALL

 SELECT 982, 9, 'Guapó' FROM dual
 UNION ALL

 SELECT 983, 9, 'Guaraíta' FROM dual
 UNION ALL

 SELECT 984, 9, 'Guarani de Goiás' FROM dual
 UNION ALL

 SELECT 985, 9, 'Guarinos' FROM dual
 UNION ALL

 SELECT 986, 9, 'Heitoraí' FROM dual
 UNION ALL

 SELECT 987, 9, 'Hidrolândia' FROM dual
 UNION ALL

 SELECT 988, 9, 'Hidrolina' FROM dual
 UNION ALL

 SELECT 989, 9, 'Iaciara' FROM dual
 UNION ALL

 SELECT 990, 9, 'Inaciolândia' FROM dual
 UNION ALL

 SELECT 991, 9, 'Indiara' FROM dual
 UNION ALL

 SELECT 992, 9, 'Inhumas' FROM dual
 UNION ALL

 SELECT 993, 9, 'Ipameri' FROM dual
 UNION ALL

 SELECT 994, 9, 'Ipiranga de Goiás' FROM dual
 UNION ALL

 SELECT 995, 9, 'Iporá' FROM dual
 UNION ALL

 SELECT 996, 9, 'Israelândia' FROM dual
 UNION ALL

 SELECT 997, 9, 'Itaberaí' FROM dual
 UNION ALL

 SELECT 998, 9, 'Itaguari' FROM dual
 UNION ALL

 SELECT 999, 9, 'Itaguaru' FROM dual
 UNION ALL

 SELECT 1000, 9, 'Itajá' FROM dual
 UNION ALL

 SELECT 1001, 9, 'Itapaci' FROM dual
 UNION ALL

 SELECT 1002, 9, 'Itapirapuã' FROM dual
 UNION ALL

 SELECT 1003, 9, 'Itapuranga' FROM dual
 UNION ALL

 SELECT 1004, 9, 'Itarumã' FROM dual
 UNION ALL

 SELECT 1005, 9, 'Itauçu' FROM dual
 UNION ALL

 SELECT 1006, 9, 'Itumbiara' FROM dual
 UNION ALL

 SELECT 1007, 9, 'Ivolândia' FROM dual
 UNION ALL

 SELECT 1008, 9, 'Jandaia' FROM dual
 UNION ALL

 SELECT 1009, 9, 'Jaraguá' FROM dual
 UNION ALL

 SELECT 1010, 9, 'Jataí' FROM dual
 UNION ALL

 SELECT 1011, 9, 'Jaupaci' FROM dual
 UNION ALL

 SELECT 1012, 9, 'Jesúpolis' FROM dual
 UNION ALL

 SELECT 1013, 9, 'Joviânia' FROM dual
 UNION ALL

 SELECT 1014, 9, 'Jussara' FROM dual
 UNION ALL

 SELECT 1015, 9, 'Lagoa Santa' FROM dual
 UNION ALL

 SELECT 1016, 9, 'Leopoldo de Bulhões' FROM dual
 UNION ALL

 SELECT 1017, 9, 'Luziânia' FROM dual
 UNION ALL

 SELECT 1018, 9, 'Mairipotaba' FROM dual
 UNION ALL

 SELECT 1019, 9, 'Mambaí' FROM dual
 UNION ALL

 SELECT 1020, 9, 'Mara Rosa' FROM dual
 UNION ALL

 SELECT 1021, 9, 'Marzagão' FROM dual
 UNION ALL

 SELECT 1022, 9, 'Matrinchã' FROM dual
 UNION ALL

 SELECT 1023, 9, 'Maurilândia' FROM dual
 UNION ALL

 SELECT 1024, 9, 'Mimoso de Goiás' FROM dual
 UNION ALL

 SELECT 1025, 9, 'Minaçu' FROM dual
 UNION ALL

 SELECT 1026, 9, 'Mineiros' FROM dual
 UNION ALL

 SELECT 1027, 9, 'Moiporá' FROM dual
 UNION ALL

 SELECT 1028, 9, 'Monte Alegre de Goiás' FROM dual
 UNION ALL

 SELECT 1029, 9, 'Montes Claros de Goiás' FROM dual
 UNION ALL

 SELECT 1030, 9, 'Montividiu' FROM dual
 UNION ALL

 SELECT 1031, 9, 'Montividiu do Norte' FROM dual
 UNION ALL

 SELECT 1032, 9, 'Morrinhos' FROM dual
 UNION ALL

 SELECT 1033, 9, 'Morro Agudo de Goiás' FROM dual
 UNION ALL

 SELECT 1034, 9, 'Mossâmedes' FROM dual
 UNION ALL

 SELECT 1035, 9, 'Mozarlândia' FROM dual
 UNION ALL

 SELECT 1036, 9, 'Mundo Novo' FROM dual
 UNION ALL

 SELECT 1037, 9, 'Mutunópolis' FROM dual
 UNION ALL

 SELECT 1038, 9, 'Nazário' FROM dual
 UNION ALL

 SELECT 1039, 9, 'Nerópolis' FROM dual
 UNION ALL

 SELECT 1040, 9, 'Niquelândia' FROM dual
 UNION ALL

 SELECT 1041, 9, 'Nova América' FROM dual
 UNION ALL

 SELECT 1042, 9, 'Nova Aurora' FROM dual
 UNION ALL

 SELECT 1043, 9, 'Nova Crixás' FROM dual
 UNION ALL

 SELECT 1044, 9, 'Nova Glória' FROM dual
 UNION ALL

 SELECT 1045, 9, 'Nova Iguaçu de Goiás' FROM dual
 UNION ALL

 SELECT 1046, 9, 'Nova Roma' FROM dual
 UNION ALL

 SELECT 1047, 9, 'Nova Veneza' FROM dual
 UNION ALL

 SELECT 1048, 9, 'Novo Brasil' FROM dual
 UNION ALL

 SELECT 1049, 9, 'Novo Gama' FROM dual
 UNION ALL

 SELECT 1050, 9, 'Novo Planalto' FROM dual
 UNION ALL

 SELECT 1051, 9, 'Orizona' FROM dual
 UNION ALL

 SELECT 1052, 9, 'Ouro Verde de Goiás' FROM dual
 UNION ALL

 SELECT 1053, 9, 'Ouvidor' FROM dual
 UNION ALL

 SELECT 1054, 9, 'Padre Bernardo' FROM dual
 UNION ALL

 SELECT 1055, 9, 'Palestina de Goiás' FROM dual
 UNION ALL

 SELECT 1056, 9, 'Palmeiras de Goiás' FROM dual
 UNION ALL

 SELECT 1057, 9, 'Palmelo' FROM dual
 UNION ALL

 SELECT 1058, 9, 'Palminópolis' FROM dual
 UNION ALL

 SELECT 1059, 9, 'Panamá' FROM dual
 UNION ALL

 SELECT 1060, 9, 'Paranaiguara' FROM dual
 UNION ALL

 SELECT 1061, 9, 'Paraúna' FROM dual
 UNION ALL

 SELECT 1062, 9, 'Perolândia' FROM dual
 UNION ALL

 SELECT 1063, 9, 'Petrolina de Goiás' FROM dual
 UNION ALL

 SELECT 1064, 9, 'Pilar de Goiás' FROM dual
 UNION ALL

 SELECT 1065, 9, 'Piracanjuba' FROM dual
 UNION ALL

 SELECT 1066, 9, 'Piranhas' FROM dual
 UNION ALL

 SELECT 1067, 9, 'Pirenópolis' FROM dual
 UNION ALL

 SELECT 1068, 9, 'Pires do Rio' FROM dual
 UNION ALL

 SELECT 1069, 9, 'Planaltina' FROM dual
 UNION ALL

 SELECT 1070, 9, 'Pontalina' FROM dual
 UNION ALL

 SELECT 1071, 9, 'Porangatu' FROM dual
 UNION ALL

 SELECT 1072, 9, 'Porteirão' FROM dual
 UNION ALL

 SELECT 1073, 9, 'Portelândia' FROM dual
 UNION ALL

 SELECT 1074, 9, 'Posse' FROM dual
 UNION ALL

 SELECT 1075, 9, 'Professor Jamil' FROM dual
 UNION ALL

 SELECT 1076, 9, 'Quirinópolis' FROM dual
 UNION ALL

 SELECT 1077, 9, 'Rialma' FROM dual
 UNION ALL

 SELECT 1078, 9, 'Rianápolis' FROM dual
 UNION ALL

 SELECT 1079, 9, 'Rio Quente' FROM dual
 UNION ALL

 SELECT 1080, 9, 'Rio Verde' FROM dual
 UNION ALL

 SELECT 1081, 9, 'Rubiataba' FROM dual
 UNION ALL

 SELECT 1082, 9, 'Sanclerlândia' FROM dual
 UNION ALL

 SELECT 1083, 9, 'Santa Bárbara de Goiás' FROM dual
 UNION ALL

 SELECT 1084, 9, 'Santa Cruz de Goiás' FROM dual
 UNION ALL

 SELECT 1085, 9, 'Santa Fé de Goiás' FROM dual
 UNION ALL

 SELECT 1086, 9, 'Santa Helena de Goiás' FROM dual
 UNION ALL

 SELECT 1087, 9, 'Santa Isabel' FROM dual
 UNION ALL

 SELECT 1088, 9, 'Santa Rita do Araguaia' FROM dual
 UNION ALL

 SELECT 1089, 9, 'Santa Rita do Novo Destino' FROM dual
 UNION ALL

 SELECT 1090, 9, 'Santa Rosa de Goiás' FROM dual
 UNION ALL

 SELECT 1091, 9, 'Santa Tereza de Goiás' FROM dual
 UNION ALL

 SELECT 1092, 9, 'Santa Terezinha de Goiás' FROM dual
 UNION ALL

 SELECT 1093, 9, 'Santo Antônio da Barra' FROM dual
 UNION ALL

 SELECT 1094, 9, 'Santo Antônio de Goiás' FROM dual
 UNION ALL

 SELECT 1095, 9, 'Santo Antônio do Descoberto' FROM dual
 UNION ALL

 SELECT 1096, 9, 'São Domingos' FROM dual
 UNION ALL

 SELECT 1097, 9, 'São Francisco de Goiás' FROM dual
 UNION ALL

 SELECT 1098, 9, 'São João d`Aliança' FROM dual
 UNION ALL

 SELECT 1099, 9, 'São João da Paraúna' FROM dual
 UNION ALL

 SELECT 1100, 9, 'São Luís de Montes Belos' FROM dual
 UNION ALL

 SELECT 1101, 9, 'São Luíz do Norte' FROM dual
 UNION ALL

 SELECT 1102, 9, 'São Miguel do Araguaia' FROM dual
 UNION ALL

 SELECT 1103, 9, 'São Miguel do Passa Quatro' FROM dual
 UNION ALL

 SELECT 1104, 9, 'São Patrício' FROM dual
 UNION ALL

 SELECT 1105, 9, 'São Simão' FROM dual
 UNION ALL

 SELECT 1106, 9, 'Senador Canedo' FROM dual
 UNION ALL

 SELECT 1107, 9, 'Serranópolis' FROM dual
 UNION ALL

 SELECT 1108, 9, 'Silvânia' FROM dual
 UNION ALL

 SELECT 1109, 9, 'Simolândia' FROM dual
 UNION ALL

 SELECT 1110, 9, 'Sítio d`Abadia' FROM dual
 UNION ALL

 SELECT 1111, 9, 'Taquaral de Goiás' FROM dual
 UNION ALL

 SELECT 1112, 9, 'Teresina de Goiás' FROM dual
 UNION ALL

 SELECT 1113, 9, 'Terezópolis de Goiás' FROM dual
 UNION ALL

 SELECT 1114, 9, 'Três Ranchos' FROM dual
 UNION ALL

 SELECT 1115, 9, 'Trindade' FROM dual
 UNION ALL

 SELECT 1116, 9, 'Trombas' FROM dual
 UNION ALL

 SELECT 1117, 9, 'Turvânia' FROM dual
 UNION ALL

 SELECT 1118, 9, 'Turvelândia' FROM dual
 UNION ALL

 SELECT 1119, 9, 'Uirapuru' FROM dual
 UNION ALL

 SELECT 1120, 9, 'Uruaçu' FROM dual
 UNION ALL

 SELECT 1121, 9, 'Uruana' FROM dual
 UNION ALL

 SELECT 1122, 9, 'Urutaí' FROM dual
 UNION ALL

 SELECT 1123, 9, 'Valparaíso de Goiás' FROM dual
 UNION ALL

 SELECT 1124, 9, 'Varjão' FROM dual
 UNION ALL

 SELECT 1125, 9, 'Vianópolis' FROM dual
 UNION ALL

 SELECT 1126, 9, 'Vicentinópolis' FROM dual
 UNION ALL

 SELECT 1127, 9, 'Vila Boa' FROM dual
 UNION ALL

 SELECT 1128, 9, 'Vila Propício' FROM dual
 UNION ALL

 SELECT 1129, 10, 'Açailândia' FROM dual
 UNION ALL

 SELECT 1130, 10, 'Afonso Cunha' FROM dual
 UNION ALL

 SELECT 1131, 10, 'Água Doce do Maranhão' FROM dual
 UNION ALL

 SELECT 1132, 10, 'Alcântara' FROM dual
 UNION ALL

 SELECT 1133, 10, 'Aldeias Altas' FROM dual
 UNION ALL

 SELECT 1134, 10, 'Altamira do Maranhão' FROM dual
 UNION ALL

 SELECT 1135, 10, 'Alto Alegre do Maranhão' FROM dual
 UNION ALL

 SELECT 1136, 10, 'Alto Alegre do Pindaré' FROM dual
 UNION ALL

 SELECT 1137, 10, 'Alto Parnaíba' FROM dual
 UNION ALL

 SELECT 1138, 10, 'Amapá do Maranhão' FROM dual
 UNION ALL

 SELECT 1139, 10, 'Amarante do Maranhão' FROM dual
 UNION ALL

 SELECT 1140, 10, 'Anajatuba' FROM dual
 UNION ALL

 SELECT 1141, 10, 'Anapurus' FROM dual
 UNION ALL

 SELECT 1142, 10, 'Apicum-Açu' FROM dual
 UNION ALL

 SELECT 1143, 10, 'Araguanã' FROM dual
 UNION ALL

 SELECT 1144, 10, 'Araioses' FROM dual
 UNION ALL

 SELECT 1145, 10, 'Arame' FROM dual
 UNION ALL

 SELECT 1146, 10, 'Arari' FROM dual
 UNION ALL

 SELECT 1147, 10, 'Axixá' FROM dual
 UNION ALL

 SELECT 1148, 10, 'Bacabal' FROM dual
 UNION ALL

 SELECT 1149, 10, 'Bacabeira' FROM dual
 UNION ALL

 SELECT 1150, 10, 'Bacuri' FROM dual
 UNION ALL

 SELECT 1151, 10, 'Bacurituba' FROM dual
 UNION ALL

 SELECT 1152, 10, 'Balsas' FROM dual
 UNION ALL

 SELECT 1153, 10, 'Barão de Grajaú' FROM dual
 UNION ALL

 SELECT 1154, 10, 'Barra do Corda' FROM dual
 UNION ALL

 SELECT 1155, 10, 'Barreirinhas' FROM dual
 UNION ALL

 SELECT 1156, 10, 'Bela Vista do Maranhão' FROM dual
 UNION ALL

 SELECT 1157, 10, 'Belágua' FROM dual
 UNION ALL

 SELECT 1158, 10, 'Benedito Leite' FROM dual
 UNION ALL

 SELECT 1159, 10, 'Bequimão' FROM dual
 UNION ALL

 SELECT 1160, 10, 'Bernardo do Mearim' FROM dual
 UNION ALL

 SELECT 1161, 10, 'Boa Vista do Gurupi' FROM dual
 UNION ALL

 SELECT 1162, 10, 'Bom Jardim' FROM dual
 UNION ALL

 SELECT 1163, 10, 'Bom Jesus das Selvas' FROM dual
 UNION ALL

 SELECT 1164, 10, 'Bom Lugar' FROM dual
 UNION ALL

 SELECT 1165, 10, 'Brejo' FROM dual
 UNION ALL

 SELECT 1166, 10, 'Brejo de Areia' FROM dual
 UNION ALL

 SELECT 1167, 10, 'Buriti' FROM dual
 UNION ALL

 SELECT 1168, 10, 'Buriti Bravo' FROM dual
 UNION ALL

 SELECT 1169, 10, 'Buriticupu' FROM dual
 UNION ALL

 SELECT 1170, 10, 'Buritirana' FROM dual
 UNION ALL

 SELECT 1171, 10, 'Cachoeira Grande' FROM dual
 UNION ALL

 SELECT 1172, 10, 'Cajapió' FROM dual
 UNION ALL

 SELECT 1173, 10, 'Cajari' FROM dual
 UNION ALL

 SELECT 1174, 10, 'Campestre do Maranhão' FROM dual
 UNION ALL

 SELECT 1175, 10, 'Cândido Mendes' FROM dual
 UNION ALL

 SELECT 1176, 10, 'Cantanhede' FROM dual
 UNION ALL

 SELECT 1177, 10, 'Capinzal do Norte' FROM dual
 UNION ALL

 SELECT 1178, 10, 'Carolina' FROM dual
 UNION ALL

 SELECT 1179, 10, 'Carutapera' FROM dual
 UNION ALL

 SELECT 1180, 10, 'Caxias' FROM dual
 UNION ALL

 SELECT 1181, 10, 'Cedral' FROM dual
 UNION ALL

 SELECT 1182, 10, 'Central do Maranhão' FROM dual
 UNION ALL

 SELECT 1183, 10, 'Centro do Guilherme' FROM dual
 UNION ALL

 SELECT 1184, 10, 'Centro Novo do Maranhão' FROM dual
 UNION ALL

 SELECT 1185, 10, 'Chapadinha' FROM dual
 UNION ALL

 SELECT 1186, 10, 'Cidelândia' FROM dual
 UNION ALL

 SELECT 1187, 10, 'Codó' FROM dual
 UNION ALL

 SELECT 1188, 10, 'Coelho Neto' FROM dual
 UNION ALL

 SELECT 1189, 10, 'Colinas' FROM dual
 UNION ALL

 SELECT 1190, 10, 'Conceição do Lago-Açu' FROM dual
 UNION ALL

 SELECT 1191, 10, 'Coroatá' FROM dual
 UNION ALL

 SELECT 1192, 10, 'Cururupu' FROM dual
 UNION ALL

 SELECT 1193, 10, 'Davinópolis' FROM dual
 UNION ALL

 SELECT 1194, 10, 'Dom Pedro' FROM dual
 UNION ALL

 SELECT 1195, 10, 'Duque Bacelar' FROM dual
 UNION ALL

 SELECT 1196, 10, 'Esperantinópolis' FROM dual
 UNION ALL

 SELECT 1197, 10, 'Estreito' FROM dual
 UNION ALL

 SELECT 1198, 10, 'Feira Nova do Maranhão' FROM dual
 UNION ALL

 SELECT 1199, 10, 'Fernando Falcão' FROM dual
 UNION ALL

 SELECT 1200, 10, 'Formosa da Serra Negra' FROM dual
 UNION ALL

 SELECT 1201, 10, 'Fortaleza dos Nogueiras' FROM dual
 UNION ALL

 SELECT 1202, 10, 'Fortuna' FROM dual
 UNION ALL

 SELECT 1203, 10, 'Godofredo Viana' FROM dual
 UNION ALL

 SELECT 1204, 10, 'Gonçalves Dias' FROM dual
 UNION ALL

 SELECT 1205, 10, 'Governador Archer' FROM dual
 UNION ALL

 SELECT 1206, 10, 'Governador Edison Lobão' FROM dual
 UNION ALL

 SELECT 1207, 10, 'Governador Eugênio Barros' FROM dual
 UNION ALL

 SELECT 1208, 10, 'Governador Luiz Rocha' FROM dual
 UNION ALL

 SELECT 1209, 10, 'Governador Newton Bello' FROM dual
 UNION ALL

 SELECT 1210, 10, 'Governador Nunes Freire' FROM dual
 UNION ALL

 SELECT 1211, 10, 'Graça Aranha' FROM dual
 UNION ALL

 SELECT 1212, 10, 'Grajaú' FROM dual
 UNION ALL

 SELECT 1213, 10, 'Guimarães' FROM dual
 UNION ALL

 SELECT 1214, 10, 'Humberto de Campos' FROM dual
 UNION ALL

 SELECT 1215, 10, 'Icatu' FROM dual
 UNION ALL

 SELECT 1216, 10, 'Igarapé do Meio' FROM dual
 UNION ALL

 SELECT 1217, 10, 'Igarapé Grande' FROM dual
 UNION ALL

 SELECT 1218, 10, 'Imperatriz' FROM dual
 UNION ALL

 SELECT 1219, 10, 'Itaipava do Grajaú' FROM dual
 UNION ALL

 SELECT 1220, 10, 'Itapecuru Mirim' FROM dual
 UNION ALL

 SELECT 1221, 10, 'Itinga do Maranhão' FROM dual
 UNION ALL

 SELECT 1222, 10, 'Jatobá' FROM dual
 UNION ALL

 SELECT 1223, 10, 'Jenipapo dos Vieiras' FROM dual
 UNION ALL

 SELECT 1224, 10, 'João Lisboa' FROM dual
 UNION ALL

 SELECT 1225, 10, 'Joselândia' FROM dual
 UNION ALL

 SELECT 1226, 10, 'Junco do Maranhão' FROM dual
 UNION ALL

 SELECT 1227, 10, 'Lago da Pedra' FROM dual
 UNION ALL

 SELECT 1228, 10, 'Lago do Junco' FROM dual
 UNION ALL

 SELECT 1229, 10, 'Lago dos Rodrigues' FROM dual
 UNION ALL

 SELECT 1230, 10, 'Lago Verde' FROM dual
 UNION ALL

 SELECT 1231, 10, 'Lagoa do Mato' FROM dual
 UNION ALL

 SELECT 1232, 10, 'Lagoa Grande do Maranhão' FROM dual
 UNION ALL

 SELECT 1233, 10, 'Lajeado Novo' FROM dual
 UNION ALL

 SELECT 1234, 10, 'Lima Campos' FROM dual
 UNION ALL

 SELECT 1235, 10, 'Loreto' FROM dual
 UNION ALL

 SELECT 1236, 10, 'Luís Domingues' FROM dual
 UNION ALL

 SELECT 1237, 10, 'Magalhães de Almeida' FROM dual
 UNION ALL

 SELECT 1238, 10, 'Maracaçumé' FROM dual
 UNION ALL

 SELECT 1239, 10, 'Marajá do Sena' FROM dual
 UNION ALL

 SELECT 1240, 10, 'Maranhãozinho' FROM dual
 UNION ALL

 SELECT 1241, 10, 'Mata Roma' FROM dual
 UNION ALL

 SELECT 1242, 10, 'Matinha' FROM dual
 UNION ALL

 SELECT 1243, 10, 'Matões' FROM dual
 UNION ALL

 SELECT 1244, 10, 'Matões do Norte' FROM dual
 UNION ALL

 SELECT 1245, 10, 'Milagres do Maranhão' FROM dual
 UNION ALL

 SELECT 1246, 10, 'Mirador' FROM dual
 UNION ALL

 SELECT 1247, 10, 'Miranda do Norte' FROM dual
 UNION ALL

 SELECT 1248, 10, 'Mirinzal' FROM dual
 UNION ALL

 SELECT 1249, 10, 'Monção' FROM dual
 UNION ALL

 SELECT 1250, 10, 'Montes Altos' FROM dual
 UNION ALL

 SELECT 1251, 10, 'Morros' FROM dual
 UNION ALL

 SELECT 1252, 10, 'Nina Rodrigues' FROM dual
 UNION ALL

 SELECT 1253, 10, 'Nova Colinas' FROM dual
 UNION ALL

 SELECT 1254, 10, 'Nova Iorque' FROM dual
 UNION ALL

 SELECT 1255, 10, 'Nova Olinda do Maranhão' FROM dual
 UNION ALL

 SELECT 1256, 10, 'Olho d`Água das Cunhãs' FROM dual
 UNION ALL

 SELECT 1257, 10, 'Olinda Nova do Maranhão' FROM dual
 UNION ALL

 SELECT 1258, 10, 'Paço do Lumiar' FROM dual
 UNION ALL

 SELECT 1259, 10, 'Palmeirândia' FROM dual
 UNION ALL

 SELECT 1260, 10, 'Paraibano' FROM dual
 UNION ALL

 SELECT 1261, 10, 'Parnarama' FROM dual
 UNION ALL

 SELECT 1262, 10, 'Passagem Franca' FROM dual
 UNION ALL

 SELECT 1263, 10, 'Pastos Bons' FROM dual
 UNION ALL

 SELECT 1264, 10, 'Paulino Neves' FROM dual
 UNION ALL

 SELECT 1265, 10, 'Paulo Ramos' FROM dual
 UNION ALL

 SELECT 1266, 10, 'Pedreiras' FROM dual
 UNION ALL

 SELECT 1267, 10, 'Pedro do Rosário' FROM dual
 UNION ALL

 SELECT 1268, 10, 'Penalva' FROM dual
 UNION ALL

 SELECT 1269, 10, 'Peri Mirim' FROM dual
 UNION ALL

 SELECT 1270, 10, 'Peritoró' FROM dual
 UNION ALL

 SELECT 1271, 10, 'Pindaré-Mirim' FROM dual
 UNION ALL

 SELECT 1272, 10, 'Pinheiro' FROM dual
 UNION ALL

 SELECT 1273, 10, 'Pio XII' FROM dual
 UNION ALL

 SELECT 1274, 10, 'Pirapemas' FROM dual
 UNION ALL

 SELECT 1275, 10, 'Poção de Pedras' FROM dual
 UNION ALL

 SELECT 1276, 10, 'Porto Franco' FROM dual
 UNION ALL

 SELECT 1277, 10, 'Porto Rico do Maranhão' FROM dual
 UNION ALL

 SELECT 1278, 10, 'Presidente Dutra' FROM dual
 UNION ALL

 SELECT 1279, 10, 'Presidente Juscelino' FROM dual
 UNION ALL

 SELECT 1280, 10, 'Presidente Médici' FROM dual
 UNION ALL

 SELECT 1281, 10, 'Presidente Sarney' FROM dual
 UNION ALL

 SELECT 1282, 10, 'Presidente Vargas' FROM dual
 UNION ALL

 SELECT 1283, 10, 'Primeira Cruz' FROM dual
 UNION ALL

 SELECT 1284, 10, 'Raposa' FROM dual
 UNION ALL

 SELECT 1285, 10, 'Riachão' FROM dual
 UNION ALL

 SELECT 1286, 10, 'Ribamar Fiquene' FROM dual
 UNION ALL

 SELECT 1287, 10, 'Rosário' FROM dual
 UNION ALL

 SELECT 1288, 10, 'Sambaíba' FROM dual
 UNION ALL

 SELECT 1289, 10, 'Santa Filomena do Maranhão' FROM dual
 UNION ALL

 SELECT 1290, 10, 'Santa Helena' FROM dual
 UNION ALL

 SELECT 1291, 10, 'Santa Inês' FROM dual
 UNION ALL

 SELECT 1292, 10, 'Santa Luzia' FROM dual
 UNION ALL

 SELECT 1293, 10, 'Santa Luzia do Paruá' FROM dual
 UNION ALL

 SELECT 1294, 10, 'Santa Quitéria do Maranhão' FROM dual
 UNION ALL

 SELECT 1295, 10, 'Santa Rita' FROM dual
 UNION ALL

 SELECT 1296, 10, 'Santana do Maranhão' FROM dual
 UNION ALL

 SELECT 1297, 10, 'Santo Amaro do Maranhão' FROM dual
 UNION ALL

 SELECT 1298, 10, 'Santo Antônio dos Lopes' FROM dual
 UNION ALL

 SELECT 1299, 10, 'São Benedito do Rio Preto' FROM dual
 UNION ALL

 SELECT 1300, 10, 'São Bento' FROM dual
 UNION ALL

 SELECT 1301, 10, 'São Bernardo' FROM dual
 UNION ALL

 SELECT 1302, 10, 'São Domingos do Azeitão' FROM dual
 UNION ALL

 SELECT 1303, 10, 'São Domingos do Maranhão' FROM dual
 UNION ALL

 SELECT 1304, 10, 'São Félix de Balsas' FROM dual
 UNION ALL

 SELECT 1305, 10, 'São Francisco do Brejão' FROM dual
 UNION ALL

 SELECT 1306, 10, 'São Francisco do Maranhão' FROM dual
 UNION ALL

 SELECT 1307, 10, 'São João Batista' FROM dual
 UNION ALL

 SELECT 1308, 10, 'São João do Carú' FROM dual
 UNION ALL

 SELECT 1309, 10, 'São João do Paraíso' FROM dual
 UNION ALL

 SELECT 1310, 10, 'São João do Soter' FROM dual
 UNION ALL

 SELECT 1311, 10, 'São João dos Patos' FROM dual
 UNION ALL

 SELECT 1312, 10, 'São José de Ribamar' FROM dual
 UNION ALL

 SELECT 1313, 10, 'São José dos Basílios' FROM dual
 UNION ALL

 SELECT 1314, 10, 'São Luís' FROM dual
 UNION ALL

 SELECT 1315, 10, 'São Luís Gonzaga do Maranhão' FROM dual
 UNION ALL

 SELECT 1316, 10, 'São Mateus do Maranhão' FROM dual
 UNION ALL

 SELECT 1317, 10, 'São Pedro da Água Branca' FROM dual
 UNION ALL

 SELECT 1318, 10, 'São Pedro dos Crentes' FROM dual
 UNION ALL

 SELECT 1319, 10, 'São Raimundo das Mangabeiras' FROM dual
 UNION ALL

 SELECT 1320, 10, 'São Raimundo do Doca Bezerra' FROM dual
 UNION ALL

 SELECT 1321, 10, 'São Roberto' FROM dual
 UNION ALL

 SELECT 1322, 10, 'São Vicente Ferrer' FROM dual
 UNION ALL

 SELECT 1323, 10, 'Satubinha' FROM dual
 UNION ALL

 SELECT 1324, 10, 'Senador Alexandre Costa' FROM dual
 UNION ALL

 SELECT 1325, 10, 'Senador La Rocque' FROM dual
 UNION ALL

 SELECT 1326, 10, 'Serrano do Maranhão' FROM dual
 UNION ALL

 SELECT 1327, 10, 'Sítio Novo' FROM dual
 UNION ALL

 SELECT 1328, 10, 'Sucupira do Norte' FROM dual
 UNION ALL

 SELECT 1329, 10, 'Sucupira do Riachão' FROM dual
 UNION ALL

 SELECT 1330, 10, 'Tasso Fragoso' FROM dual
 UNION ALL

 SELECT 1331, 10, 'Timbiras' FROM dual
 UNION ALL

 SELECT 1332, 10, 'Timon' FROM dual
 UNION ALL

 SELECT 1333, 10, 'Trizidela do Vale' FROM dual
 UNION ALL

 SELECT 1334, 10, 'Tufilândia' FROM dual
 UNION ALL

 SELECT 1335, 10, 'Tuntum' FROM dual
 UNION ALL

 SELECT 1336, 10, 'Turiaçu' FROM dual
 UNION ALL

 SELECT 1337, 10, 'Turilândia' FROM dual
 UNION ALL

 SELECT 1338, 10, 'Tutóia' FROM dual
 UNION ALL

 SELECT 1339, 10, 'Urbano Santos' FROM dual
 UNION ALL

 SELECT 1340, 10, 'Vargem Grande' FROM dual
 UNION ALL

 SELECT 1341, 10, 'Viana' FROM dual
 UNION ALL

 SELECT 1342, 10, 'Vila Nova dos Martírios' FROM dual
 UNION ALL

 SELECT 1343, 10, 'Vitória do Mearim' FROM dual
 UNION ALL

 SELECT 1344, 10, 'Vitorino Freire' FROM dual
 UNION ALL

 SELECT 1345, 10, 'Zé Doca' FROM dual
 UNION ALL

 SELECT 1346, 13, 'Acorizal' FROM dual
 UNION ALL

 SELECT 1347, 13, 'Água Boa' FROM dual
 UNION ALL

 SELECT 1348, 13, 'Alta Floresta' FROM dual
 UNION ALL

 SELECT 1349, 13, 'Alto Araguaia' FROM dual
 UNION ALL

 SELECT 1350, 13, 'Alto Boa Vista' FROM dual
 UNION ALL

 SELECT 1351, 13, 'Alto Garças' FROM dual
 UNION ALL

 SELECT 1352, 13, 'Alto Paraguai' FROM dual
 UNION ALL

 SELECT 1353, 13, 'Alto Taquari' FROM dual
 UNION ALL

 SELECT 1354, 13, 'Apiacás' FROM dual
 UNION ALL

 SELECT 1355, 13, 'Araguaiana' FROM dual
 UNION ALL

 SELECT 1356, 13, 'Araguainha' FROM dual
 UNION ALL

 SELECT 1357, 13, 'Araputanga' FROM dual
 UNION ALL

 SELECT 1358, 13, 'Arenápolis' FROM dual
 UNION ALL

 SELECT 1359, 13, 'Aripuanã' FROM dual
 UNION ALL

 SELECT 1360, 13, 'Barão de Melgaço' FROM dual
 UNION ALL

 SELECT 1361, 13, 'Barra do Bugres' FROM dual
 UNION ALL

 SELECT 1362, 13, 'Barra do Garças' FROM dual
 UNION ALL

 SELECT 1363, 13, 'Bom Jesus do Araguaia' FROM dual
 UNION ALL

 SELECT 1364, 13, 'Brasnorte' FROM dual
 UNION ALL

 SELECT 1365, 13, 'Cáceres' FROM dual
 UNION ALL

 SELECT 1366, 13, 'Campinápolis' FROM dual
 UNION ALL

 SELECT 1367, 13, 'Campo Novo do Parecis' FROM dual
 UNION ALL

 SELECT 1368, 13, 'Campo Verde' FROM dual
 UNION ALL

 SELECT 1369, 13, 'Campos de Júlio' FROM dual
 UNION ALL

 SELECT 1370, 13, 'Canabrava do Norte' FROM dual
 UNION ALL

 SELECT 1371, 13, 'Canarana' FROM dual
 UNION ALL

 SELECT 1372, 13, 'Carlinda' FROM dual
 UNION ALL

 SELECT 1373, 13, 'Castanheira' FROM dual
 UNION ALL

 SELECT 1374, 13, 'Chapada dos Guimarães' FROM dual
 UNION ALL

 SELECT 1375, 13, 'Cláudia' FROM dual
 UNION ALL

 SELECT 1376, 13, 'Cocalinho' FROM dual
 UNION ALL

 SELECT 1377, 13, 'Colíder' FROM dual
 UNION ALL

 SELECT 1378, 13, 'Colniza' FROM dual
 UNION ALL

 SELECT 1379, 13, 'Comodoro' FROM dual
 UNION ALL

 SELECT 1380, 13, 'Confresa' FROM dual
 UNION ALL

 SELECT 1381, 13, 'Conquista d`Oeste' FROM dual
 UNION ALL

 SELECT 1382, 13, 'Cotriguaçu' FROM dual
 UNION ALL

 SELECT 1383, 13, 'Cuiabá' FROM dual
 UNION ALL

 SELECT 1384, 13, 'Curvelândia' FROM dual
 UNION ALL

 SELECT 1385, 13, 'Curvelândia' FROM dual
 UNION ALL

 SELECT 1386, 13, 'Denise' FROM dual
 UNION ALL

 SELECT 1387, 13, 'Diamantino' FROM dual
 UNION ALL

 SELECT 1388, 13, 'Dom Aquino' FROM dual
 UNION ALL

 SELECT 1389, 13, 'Feliz Natal' FROM dual
 UNION ALL

 SELECT 1390, 13, 'Figueirópolis d`Oeste' FROM dual
 UNION ALL

 SELECT 1391, 13, 'Gaúcha do Norte' FROM dual
 UNION ALL

 SELECT 1392, 13, 'General Carneiro' FROM dual
 UNION ALL

 SELECT 1393, 13, 'Glória d`Oeste' FROM dual
 UNION ALL

 SELECT 1394, 13, 'Guarantã do Norte' FROM dual
 UNION ALL

 SELECT 1395, 13, 'Guiratinga' FROM dual
 UNION ALL

 SELECT 1396, 13, 'Indiavaí' FROM dual
 UNION ALL

 SELECT 1397, 13, 'Ipiranga do Norte' FROM dual
 UNION ALL

 SELECT 1398, 13, 'Itanhangá' FROM dual
 UNION ALL

 SELECT 1399, 13, 'Itaúba' FROM dual
 UNION ALL

 SELECT 1400, 13, 'Itiquira' FROM dual
 UNION ALL

 SELECT 1401, 13, 'Jaciara' FROM dual
 UNION ALL

 SELECT 1402, 13, 'Jangada' FROM dual
 UNION ALL

 SELECT 1403, 13, 'Jauru' FROM dual
 UNION ALL

 SELECT 1404, 13, 'Juara' FROM dual
 UNION ALL

 SELECT 1405, 13, 'Juína' FROM dual
 UNION ALL

 SELECT 1406, 13, 'Juruena' FROM dual
 UNION ALL

 SELECT 1407, 13, 'Juscimeira' FROM dual
 UNION ALL

 SELECT 1408, 13, 'Lambari d`Oeste' FROM dual
 UNION ALL

 SELECT 1409, 13, 'Lucas do Rio Verde' FROM dual
 UNION ALL

 SELECT 1410, 13, 'Luciára' FROM dual
 UNION ALL

 SELECT 1411, 13, 'Marcelândia' FROM dual
 UNION ALL

 SELECT 1412, 13, 'Matupá' FROM dual
 UNION ALL

 SELECT 1413, 13, 'Mirassol d`Oeste' FROM dual
 UNION ALL

 SELECT 1414, 13, 'Nobres' FROM dual
 UNION ALL

 SELECT 1415, 13, 'Nortelândia' FROM dual
 UNION ALL

 SELECT 1416, 13, 'Nossa Senhora do Livramento' FROM dual
 UNION ALL

 SELECT 1417, 13, 'Nova Bandeirantes' FROM dual
 UNION ALL

 SELECT 1418, 13, 'Nova Brasilândia' FROM dual
 UNION ALL

 SELECT 1419, 13, 'Nova Canaã do Norte' FROM dual
 UNION ALL

 SELECT 1420, 13, 'Nova Guarita' FROM dual
 UNION ALL

 SELECT 1421, 13, 'Nova Lacerda' FROM dual
 UNION ALL

 SELECT 1422, 13, 'Nova Marilândia' FROM dual
 UNION ALL

 SELECT 1423, 13, 'Nova Maringá' FROM dual
 UNION ALL

 SELECT 1424, 13, 'Nova Monte verde' FROM dual
 UNION ALL

 SELECT 1425, 13, 'Nova Mutum' FROM dual
 UNION ALL

 SELECT 1426, 13, 'Nova Olímpia' FROM dual
 UNION ALL

 SELECT 1427, 13, 'Nova Santa Helena' FROM dual
 UNION ALL

 SELECT 1428, 13, 'Nova Ubiratã' FROM dual
 UNION ALL

 SELECT 1429, 13, 'Nova Xavantina' FROM dual
 UNION ALL

 SELECT 1430, 13, 'Novo Horizonte do Norte' FROM dual
 UNION ALL

 SELECT 1431, 13, 'Novo Mundo' FROM dual
 UNION ALL

 SELECT 1432, 13, 'Novo Santo Antônio' FROM dual
 UNION ALL

 SELECT 1433, 13, 'Novo São Joaquim' FROM dual
 UNION ALL

 SELECT 1434, 13, 'Paranaíta' FROM dual
 UNION ALL

 SELECT 1435, 13, 'Paranatinga' FROM dual
 UNION ALL

 SELECT 1436, 13, 'Pedra Preta' FROM dual
 UNION ALL

 SELECT 1437, 13, 'Peixoto de Azevedo' FROM dual
 UNION ALL

 SELECT 1438, 13, 'Planalto da Serra' FROM dual
 UNION ALL

 SELECT 1439, 13, 'Poconé' FROM dual
 UNION ALL

 SELECT 1440, 13, 'Pontal do Araguaia' FROM dual
 UNION ALL

 SELECT 1441, 13, 'Ponte Branca' FROM dual
 UNION ALL

 SELECT 1442, 13, 'Pontes e Lacerda' FROM dual
 UNION ALL

 SELECT 1443, 13, 'Porto Alegre do Norte' FROM dual
 UNION ALL

 SELECT 1444, 13, 'Porto dos Gaúchos' FROM dual
 UNION ALL

 SELECT 1445, 13, 'Porto Esperidião' FROM dual
 UNION ALL

 SELECT 1446, 13, 'Porto Estrela' FROM dual
 UNION ALL

 SELECT 1447, 13, 'Poxoréo' FROM dual
 UNION ALL

 SELECT 1448, 13, 'Primavera do Leste' FROM dual
 UNION ALL

 SELECT 1449, 13, 'Querência' FROM dual
 UNION ALL

 SELECT 1450, 13, 'Reserva do Cabaçal' FROM dual
 UNION ALL

 SELECT 1451, 13, 'Ribeirão Cascalheira' FROM dual
 UNION ALL

 SELECT 1452, 13, 'Ribeirãozinho' FROM dual
 UNION ALL

 SELECT 1453, 13, 'Rio Branco' FROM dual
 UNION ALL

 SELECT 1454, 13, 'Rondolândia' FROM dual
 UNION ALL

 SELECT 1455, 13, 'Rondonópolis' FROM dual
 UNION ALL

 SELECT 1456, 13, 'Rosário Oeste' FROM dual
 UNION ALL

 SELECT 1457, 13, 'Salto do Céu' FROM dual
 UNION ALL

 SELECT 1458, 13, 'Santa Carmem' FROM dual
 UNION ALL

 SELECT 1459, 13, 'Santa Cruz do Xingu' FROM dual
 UNION ALL

 SELECT 1460, 13, 'Santa Rita do Trivelato' FROM dual
 UNION ALL

 SELECT 1461, 13, 'Santa Terezinha' FROM dual
 UNION ALL

 SELECT 1462, 13, 'Santo Afonso' FROM dual
 UNION ALL

 SELECT 1463, 13, 'Santo Antônio do Leste' FROM dual
 UNION ALL

 SELECT 1464, 13, 'Santo Antônio do Leverger' FROM dual
 UNION ALL

 SELECT 1465, 13, 'São Félix do Araguaia' FROM dual
 UNION ALL

 SELECT 1466, 13, 'São José do Povo' FROM dual
 UNION ALL

 SELECT 1467, 13, 'São José do Rio Claro' FROM dual
 UNION ALL

 SELECT 1468, 13, 'São José do Xingu' FROM dual
 UNION ALL

 SELECT 1469, 13, 'São José dos Quatro Marcos' FROM dual
 UNION ALL

 SELECT 1470, 13, 'São Pedro da Cipa' FROM dual
 UNION ALL

 SELECT 1471, 13, 'Sapezal' FROM dual
 UNION ALL

 SELECT 1472, 13, 'Serra Nova Dourada' FROM dual
 UNION ALL

 SELECT 1473, 13, 'Sinop' FROM dual
 UNION ALL

 SELECT 1474, 13, 'Sorriso' FROM dual
 UNION ALL

 SELECT 1475, 13, 'Tabaporã' FROM dual
 UNION ALL

 SELECT 1476, 13, 'Tangará da Serra' FROM dual
 UNION ALL

 SELECT 1477, 13, 'Tapurah' FROM dual
 UNION ALL

 SELECT 1478, 13, 'Terra Nova do Norte' FROM dual
 UNION ALL

 SELECT 1479, 13, 'Tesouro' FROM dual
 UNION ALL

 SELECT 1480, 13, 'Torixoréu' FROM dual
 UNION ALL

 SELECT 1481, 13, 'União do Sul' FROM dual
 UNION ALL

 SELECT 1482, 13, 'Vale de São Domingos' FROM dual
 UNION ALL

 SELECT 1483, 13, 'Várzea Grande' FROM dual
 UNION ALL

 SELECT 1484, 13, 'Vera' FROM dual
 UNION ALL

 SELECT 1485, 13, 'Vila Bela da Santíssima Trindade' FROM dual
 UNION ALL

 SELECT 1486, 13, 'Vila Rica' FROM dual
 UNION ALL

 SELECT 1487, 12, 'Água Clara' FROM dual
 UNION ALL

 SELECT 1488, 12, 'Alcinópolis' FROM dual
 UNION ALL

 SELECT 1489, 12, 'Amambaí' FROM dual
 UNION ALL

 SELECT 1490, 12, 'Anastácio' FROM dual
 UNION ALL

 SELECT 1491, 12, 'Anaurilândia' FROM dual
 UNION ALL

 SELECT 1492, 12, 'Angélica' FROM dual
 UNION ALL

 SELECT 1493, 12, 'Antônio João' FROM dual
 UNION ALL

 SELECT 1494, 12, 'Aparecida do Taboado' FROM dual
 UNION ALL

 SELECT 1495, 12, 'Aquidauana' FROM dual
 UNION ALL

 SELECT 1496, 12, 'Aral Moreira' FROM dual
 UNION ALL

 SELECT 1497, 12, 'Bandeirantes' FROM dual
 UNION ALL

 SELECT 1498, 12, 'Bataguassu' FROM dual
 UNION ALL

 SELECT 1499, 12, 'Bataiporã' FROM dual
 UNION ALL

 SELECT 1500, 12, 'Bela Vista' FROM dual
 UNION ALL

 SELECT 1501, 12, 'Bodoquena' FROM dual
 UNION ALL

 SELECT 1502, 12, 'Bonito' FROM dual
 UNION ALL

 SELECT 1503, 12, 'Brasilândia' FROM dual
 UNION ALL

 SELECT 1504, 12, 'Caarapó' FROM dual
 UNION ALL

 SELECT 1505, 12, 'Camapuã' FROM dual
 UNION ALL

 SELECT 1506, 12, 'Campo Grande' FROM dual
 UNION ALL

 SELECT 1507, 12, 'Caracol' FROM dual
 UNION ALL

 SELECT 1508, 12, 'Cassilândia' FROM dual
 UNION ALL

 SELECT 1509, 12, 'Chapadão do Sul' FROM dual
 UNION ALL

 SELECT 1510, 12, 'Corguinho' FROM dual
 UNION ALL

 SELECT 1511, 12, 'Coronel Sapucaia' FROM dual
 UNION ALL

 SELECT 1512, 12, 'Corumbá' FROM dual
 UNION ALL

 SELECT 1513, 12, 'Costa Rica' FROM dual
 UNION ALL

 SELECT 1514, 12, 'Coxim' FROM dual
 UNION ALL

 SELECT 1515, 12, 'Deodápolis' FROM dual
 UNION ALL

 SELECT 1516, 12, 'Dois Irmãos do Buriti' FROM dual
 UNION ALL

 SELECT 1517, 12, 'Douradina' FROM dual
 UNION ALL

 SELECT 1518, 12, 'Dourados' FROM dual
 UNION ALL

 SELECT 1519, 12, 'Eldorado' FROM dual
 UNION ALL

 SELECT 1520, 12, 'Fátima do Sul' FROM dual
 UNION ALL

 SELECT 1521, 12, 'Figueirão' FROM dual
 UNION ALL

 SELECT 1522, 12, 'Glória de Dourados' FROM dual
 UNION ALL

 SELECT 1523, 12, 'Guia Lopes da Laguna' FROM dual
 UNION ALL

 SELECT 1524, 12, 'Iguatemi' FROM dual
 UNION ALL

 SELECT 1525, 12, 'Inocência' FROM dual
 UNION ALL

 SELECT 1526, 12, 'Itaporã' FROM dual
 UNION ALL

 SELECT 1527, 12, 'Itaquiraí' FROM dual
 UNION ALL

 SELECT 1528, 12, 'Ivinhema' FROM dual
 UNION ALL

 SELECT 1529, 12, 'Japorã' FROM dual
 UNION ALL

 SELECT 1530, 12, 'Jaraguari' FROM dual
 UNION ALL

 SELECT 1531, 12, 'Jardim' FROM dual
 UNION ALL

 SELECT 1532, 12, 'Jateí' FROM dual
 UNION ALL

 SELECT 1533, 12, 'Juti' FROM dual
 UNION ALL

 SELECT 1534, 12, 'Ladário' FROM dual
 UNION ALL

 SELECT 1535, 12, 'Laguna Carapã' FROM dual
 UNION ALL

 SELECT 1536, 12, 'Maracaju' FROM dual
 UNION ALL

 SELECT 1537, 12, 'Miranda' FROM dual
 UNION ALL

 SELECT 1538, 12, 'Mundo Novo' FROM dual
 UNION ALL

 SELECT 1539, 12, 'Naviraí' FROM dual
 UNION ALL

 SELECT 1540, 12, 'Nioaque' FROM dual
 UNION ALL

 SELECT 1541, 12, 'Nova Alvorada do Sul' FROM dual
 UNION ALL

 SELECT 1542, 12, 'Nova Andradina' FROM dual
 UNION ALL

 SELECT 1543, 12, 'Novo Horizonte do Sul' FROM dual
 UNION ALL

 SELECT 1544, 12, 'Paranaíba' FROM dual
 UNION ALL

 SELECT 1545, 12, 'Paranhos' FROM dual
 UNION ALL

 SELECT 1546, 12, 'Pedro Gomes' FROM dual
 UNION ALL

 SELECT 1547, 12, 'Ponta Porã' FROM dual
 UNION ALL

 SELECT 1548, 12, 'Porto Murtinho' FROM dual
 UNION ALL

 SELECT 1549, 12, 'Ribas do Rio Pardo' FROM dual
 UNION ALL

 SELECT 1550, 12, 'Rio Brilhante' FROM dual
 UNION ALL

 SELECT 1551, 12, 'Rio Negro' FROM dual
 UNION ALL

 SELECT 1552, 12, 'Rio Verde de Mato Grosso' FROM dual
 UNION ALL

 SELECT 1553, 12, 'Rochedo' FROM dual
 UNION ALL

 SELECT 1554, 12, 'Santa Rita do Pardo' FROM dual
 UNION ALL

 SELECT 1555, 12, 'São Gabriel do Oeste' FROM dual
 UNION ALL

 SELECT 1556, 12, 'Selvíria' FROM dual
 UNION ALL

 SELECT 1557, 12, 'Sete Quedas' FROM dual
 UNION ALL

 SELECT 1558, 12, 'Sidrolândia' FROM dual
 UNION ALL

 SELECT 1559, 12, 'Sonora' FROM dual
 UNION ALL

 SELECT 1560, 12, 'Tacuru' FROM dual
 UNION ALL

 SELECT 1561, 12, 'Taquarussu' FROM dual
 UNION ALL

 SELECT 1562, 12, 'Terenos' FROM dual
 UNION ALL

 SELECT 1563, 12, 'Três Lagoas' FROM dual
 UNION ALL

 SELECT 1564, 12, 'Vicentina' FROM dual
 UNION ALL

 SELECT 1565, 11, 'Abadia dos Dourados' FROM dual
 UNION ALL

 SELECT 1566, 11, 'Abaeté' FROM dual
 UNION ALL

 SELECT 1567, 11, 'Abre Campo' FROM dual
 UNION ALL

 SELECT 1568, 11, 'Acaiaca' FROM dual
 UNION ALL

 SELECT 1569, 11, 'Açucena' FROM dual
 UNION ALL

 SELECT 1570, 11, 'Água Boa' FROM dual
 UNION ALL

 SELECT 1571, 11, 'Água Comprida' FROM dual
 UNION ALL

 SELECT 1572, 11, 'Aguanil' FROM dual
 UNION ALL

 SELECT 1573, 11, 'Águas Formosas' FROM dual
 UNION ALL

 SELECT 1574, 11, 'Águas Vermelhas' FROM dual
 UNION ALL

 SELECT 1575, 11, 'Aimorés' FROM dual
 UNION ALL

 SELECT 1576, 11, 'Aiuruoca' FROM dual
 UNION ALL

 SELECT 1577, 11, 'Alagoa' FROM dual
 UNION ALL

 SELECT 1578, 11, 'Albertina' FROM dual
 UNION ALL

 SELECT 1579, 11, 'Além Paraíba' FROM dual
 UNION ALL

 SELECT 1580, 11, 'Alfenas' FROM dual
 UNION ALL

 SELECT 1581, 11, 'Alfredo Vasconcelos' FROM dual
 UNION ALL

 SELECT 1582, 11, 'Almenara' FROM dual
 UNION ALL

 SELECT 1583, 11, 'Alpercata' FROM dual
 UNION ALL

 SELECT 1584, 11, 'Alpinópolis' FROM dual
 UNION ALL

 SELECT 1585, 11, 'Alterosa' FROM dual
 UNION ALL

 SELECT 1586, 11, 'Alto Caparaó' FROM dual
 UNION ALL

 SELECT 1587, 11, 'Alto Jequitibá' FROM dual
 UNION ALL

 SELECT 1588, 11, 'Alto Rio Doce' FROM dual
 UNION ALL

 SELECT 1589, 11, 'Alvarenga' FROM dual
 UNION ALL

 SELECT 1590, 11, 'Alvinópolis' FROM dual
 UNION ALL

 SELECT 1591, 11, 'Alvorada de Minas' FROM dual
 UNION ALL

 SELECT 1592, 11, 'Amparo do Serra' FROM dual
 UNION ALL

 SELECT 1593, 11, 'Andradas' FROM dual
 UNION ALL

 SELECT 1594, 11, 'Andrelândia' FROM dual
 UNION ALL

 SELECT 1595, 11, 'Angelândia' FROM dual
 UNION ALL

 SELECT 1596, 11, 'Antônio Carlos' FROM dual
 UNION ALL

 SELECT 1597, 11, 'Antônio Dias' FROM dual
 UNION ALL

 SELECT 1598, 11, 'Antônio Prado de Minas' FROM dual
 UNION ALL

 SELECT 1599, 11, 'Araçaí' FROM dual
 UNION ALL

 SELECT 1600, 11, 'Aracitaba' FROM dual
 UNION ALL

 SELECT 1601, 11, 'Araçuaí' FROM dual
 UNION ALL

 SELECT 1602, 11, 'Araguari' FROM dual
 UNION ALL

 SELECT 1603, 11, 'Arantina' FROM dual
 UNION ALL

 SELECT 1604, 11, 'Araponga' FROM dual
 UNION ALL

 SELECT 1605, 11, 'Araporã' FROM dual
 UNION ALL

 SELECT 1606, 11, 'Arapuá' FROM dual
 UNION ALL

 SELECT 1607, 11, 'Araújos' FROM dual
 UNION ALL

 SELECT 1608, 11, 'Araxá' FROM dual
 UNION ALL

 SELECT 1609, 11, 'Arceburgo' FROM dual
 UNION ALL

 SELECT 1610, 11, 'Arcos' FROM dual
 UNION ALL

 SELECT 1611, 11, 'Areado' FROM dual
 UNION ALL

 SELECT 1612, 11, 'Argirita' FROM dual
 UNION ALL

 SELECT 1613, 11, 'Aricanduva' FROM dual
 UNION ALL

 SELECT 1614, 11, 'Arinos' FROM dual
 UNION ALL

 SELECT 1615, 11, 'Astolfo Dutra' FROM dual
 UNION ALL

 SELECT 1616, 11, 'Ataléia' FROM dual
 UNION ALL

 SELECT 1617, 11, 'Augusto de Lima' FROM dual
 UNION ALL

 SELECT 1618, 11, 'Baependi' FROM dual
 UNION ALL

 SELECT 1619, 11, 'Baldim' FROM dual
 UNION ALL

 SELECT 1620, 11, 'Bambuí' FROM dual
 UNION ALL

 SELECT 1621, 11, 'Bandeira' FROM dual
 UNION ALL

 SELECT 1622, 11, 'Bandeira do Sul' FROM dual
 UNION ALL

 SELECT 1623, 11, 'Barão de Cocais' FROM dual
 UNION ALL

 SELECT 1624, 11, 'Barão de Monte Alto' FROM dual
 UNION ALL

 SELECT 1625, 11, 'Barbacena' FROM dual
 UNION ALL

 SELECT 1626, 11, 'Barra Longa' FROM dual
 UNION ALL

 SELECT 1627, 11, 'Barroso' FROM dual
 UNION ALL

 SELECT 1628, 11, 'Bela Vista de Minas' FROM dual
 UNION ALL

 SELECT 1629, 11, 'Belmiro Braga' FROM dual
 UNION ALL

 SELECT 1630, 11, 'Belo Horizonte' FROM dual
 UNION ALL

 SELECT 1631, 11, 'Belo Oriente' FROM dual
 UNION ALL

 SELECT 1632, 11, 'Belo Vale' FROM dual
 UNION ALL

 SELECT 1633, 11, 'Berilo' FROM dual
 UNION ALL

 SELECT 1634, 11, 'Berizal' FROM dual
 UNION ALL

 SELECT 1635, 11, 'Bertópolis' FROM dual
 UNION ALL

 SELECT 1636, 11, 'Betim' FROM dual
 UNION ALL

 SELECT 1637, 11, 'Bias Fortes' FROM dual
 UNION ALL

 SELECT 1638, 11, 'Bicas' FROM dual
 UNION ALL

 SELECT 1639, 11, 'Biquinhas' FROM dual
 UNION ALL

 SELECT 1640, 11, 'Boa Esperança' FROM dual
 UNION ALL

 SELECT 1641, 11, 'Bocaina de Minas' FROM dual
 UNION ALL

 SELECT 1642, 11, 'Bocaiúva' FROM dual
 UNION ALL

 SELECT 1643, 11, 'Bom Despacho' FROM dual
 UNION ALL

 SELECT 1644, 11, 'Bom Jardim de Minas' FROM dual
 UNION ALL

 SELECT 1645, 11, 'Bom Jesus da Penha' FROM dual
 UNION ALL

 SELECT 1646, 11, 'Bom Jesus do Amparo' FROM dual
 UNION ALL

 SELECT 1647, 11, 'Bom Jesus do Galho' FROM dual
 UNION ALL

 SELECT 1648, 11, 'Bom Repouso' FROM dual
 UNION ALL

 SELECT 1649, 11, 'Bom Sucesso' FROM dual
 UNION ALL

 SELECT 1650, 11, 'Bonfim' FROM dual
 UNION ALL

 SELECT 1651, 11, 'Bonfinópolis de Minas' FROM dual
 UNION ALL

 SELECT 1652, 11, 'Bonito de Minas' FROM dual
 UNION ALL

 SELECT 1653, 11, 'Borda da Mata' FROM dual
 UNION ALL

 SELECT 1654, 11, 'Botelhos' FROM dual
 UNION ALL

 SELECT 1655, 11, 'Botumirim' FROM dual
 UNION ALL

 SELECT 1656, 11, 'Brás Pires' FROM dual
 UNION ALL

 SELECT 1657, 11, 'Brasilândia de Minas' FROM dual
 UNION ALL

 SELECT 1658, 11, 'Brasília de Minas' FROM dual
 UNION ALL

 SELECT 1659, 11, 'Brasópolis' FROM dual
 UNION ALL

 SELECT 1660, 11, 'Braúnas' FROM dual
 UNION ALL

 SELECT 1661, 11, 'Brumadinho' FROM dual
 UNION ALL

 SELECT 1662, 11, 'Bueno Brandão' FROM dual
 UNION ALL

 SELECT 1663, 11, 'Buenópolis' FROM dual
 UNION ALL

 SELECT 1664, 11, 'Bugre' FROM dual
 UNION ALL

 SELECT 1665, 11, 'Buritis' FROM dual
 UNION ALL

 SELECT 1666, 11, 'Buritizeiro' FROM dual
 UNION ALL

 SELECT 1667, 11, 'Cabeceira Grande' FROM dual
 UNION ALL

 SELECT 1668, 11, 'Cabo Verde' FROM dual
 UNION ALL

 SELECT 1669, 11, 'Cachoeira da Prata' FROM dual
 UNION ALL

 SELECT 1670, 11, 'Cachoeira de Minas' FROM dual
 UNION ALL

 SELECT 1671, 11, 'Cachoeira de Pajeú' FROM dual
 UNION ALL

 SELECT 1672, 11, 'Cachoeira Dourada' FROM dual
 UNION ALL

 SELECT 1673, 11, 'Caetanópolis' FROM dual
 UNION ALL

 SELECT 1674, 11, 'Caeté' FROM dual
 UNION ALL

 SELECT 1675, 11, 'Caiana' FROM dual
 UNION ALL

 SELECT 1676, 11, 'Cajuri' FROM dual
 UNION ALL

 SELECT 1677, 11, 'Caldas' FROM dual
 UNION ALL

 SELECT 1678, 11, 'Camacho' FROM dual
 UNION ALL

 SELECT 1679, 11, 'Camanducaia' FROM dual
 UNION ALL

 SELECT 1680, 11, 'Cambuí' FROM dual
 UNION ALL

 SELECT 1681, 11, 'Cambuquira' FROM dual
 UNION ALL

 SELECT 1682, 11, 'Campanário' FROM dual
 UNION ALL

 SELECT 1683, 11, 'Campanha' FROM dual
 UNION ALL

 SELECT 1684, 11, 'Campestre' FROM dual
 UNION ALL

 SELECT 1685, 11, 'Campina Verde' FROM dual
 UNION ALL

 SELECT 1686, 11, 'Campo Azul' FROM dual
 UNION ALL

 SELECT 1687, 11, 'Campo Belo' FROM dual
 UNION ALL

 SELECT 1688, 11, 'Campo do Meio' FROM dual
 UNION ALL

 SELECT 1689, 11, 'Campo Florido' FROM dual
 UNION ALL

 SELECT 1690, 11, 'Campos Altos' FROM dual
 UNION ALL

 SELECT 1691, 11, 'Campos Gerais' FROM dual
 UNION ALL

 SELECT 1692, 11, 'Cana Verde' FROM dual
 UNION ALL

 SELECT 1693, 11, 'Canaã' FROM dual
 UNION ALL

 SELECT 1694, 11, 'Canápolis' FROM dual
 UNION ALL

 SELECT 1695, 11, 'Candeias' FROM dual
 UNION ALL

 SELECT 1696, 11, 'Cantagalo' FROM dual
 UNION ALL

 SELECT 1697, 11, 'Caparaó' FROM dual
 UNION ALL

 SELECT 1698, 11, 'Capela Nova' FROM dual
 UNION ALL

 SELECT 1699, 11, 'Capelinha' FROM dual
 UNION ALL

 SELECT 1700, 11, 'Capetinga' FROM dual
 UNION ALL

 SELECT 1701, 11, 'Capim Branco' FROM dual
 UNION ALL

 SELECT 1702, 11, 'Capinópolis' FROM dual
 UNION ALL

 SELECT 1703, 11, 'Capitão Andrade' FROM dual
 UNION ALL

 SELECT 1704, 11, 'Capitão Enéas' FROM dual
 UNION ALL

 SELECT 1705, 11, 'Capitólio' FROM dual
 UNION ALL

 SELECT 1706, 11, 'Caputira' FROM dual
 UNION ALL

 SELECT 1707, 11, 'Caraí' FROM dual
 UNION ALL

 SELECT 1708, 11, 'Caranaíba' FROM dual
 UNION ALL

 SELECT 1709, 11, 'Carandaí' FROM dual
 UNION ALL

 SELECT 1710, 11, 'Carangola' FROM dual
 UNION ALL

 SELECT 1711, 11, 'Caratinga' FROM dual
 UNION ALL

 SELECT 1712, 11, 'Carbonita' FROM dual
 UNION ALL

 SELECT 1713, 11, 'Careaçu' FROM dual
 UNION ALL

 SELECT 1714, 11, 'Carlos Chagas' FROM dual
 UNION ALL

 SELECT 1715, 11, 'Carmésia' FROM dual
 UNION ALL

 SELECT 1716, 11, 'Carmo da Cachoeira' FROM dual
 UNION ALL

 SELECT 1717, 11, 'Carmo da Mata' FROM dual
 UNION ALL

 SELECT 1718, 11, 'Carmo de Minas' FROM dual
 UNION ALL

 SELECT 1719, 11, 'Carmo do Cajuru' FROM dual
 UNION ALL

 SELECT 1720, 11, 'Carmo do Paranaíba' FROM dual
 UNION ALL

 SELECT 1721, 11, 'Carmo do Rio Claro' FROM dual
 UNION ALL

 SELECT 1722, 11, 'Carmópolis de Minas' FROM dual
 UNION ALL

 SELECT 1723, 11, 'Carneirinho' FROM dual
 UNION ALL

 SELECT 1724, 11, 'Carrancas' FROM dual
 UNION ALL

 SELECT 1725, 11, 'Carvalhópolis' FROM dual
 UNION ALL

 SELECT 1726, 11, 'Carvalhos' FROM dual
 UNION ALL

 SELECT 1727, 11, 'Casa Grande' FROM dual
 UNION ALL

 SELECT 1728, 11, 'Cascalho Rico' FROM dual
 UNION ALL

 SELECT 1729, 11, 'Cássia' FROM dual
 UNION ALL

 SELECT 1730, 11, 'Cataguases' FROM dual
 UNION ALL

 SELECT 1731, 11, 'Catas Altas' FROM dual
 UNION ALL

 SELECT 1732, 11, 'Catas Altas da Noruega' FROM dual
 UNION ALL

 SELECT 1733, 11, 'Catuji' FROM dual
 UNION ALL

 SELECT 1734, 11, 'Catuti' FROM dual
 UNION ALL

 SELECT 1735, 11, 'Caxambu' FROM dual
 UNION ALL

 SELECT 1736, 11, 'Cedro do Abaeté' FROM dual
 UNION ALL

 SELECT 1737, 11, 'Central de Minas' FROM dual
 UNION ALL

 SELECT 1738, 11, 'Centralina' FROM dual
 UNION ALL

 SELECT 1739, 11, 'Chácara' FROM dual
 UNION ALL

 SELECT 1740, 11, 'Chalé' FROM dual
 UNION ALL

 SELECT 1741, 11, 'Chapada do Norte' FROM dual
 UNION ALL

 SELECT 1742, 11, 'Chapada Gaúcha' FROM dual
 UNION ALL

 SELECT 1743, 11, 'Chiador' FROM dual
 UNION ALL

 SELECT 1744, 11, 'Cipotânea' FROM dual
 UNION ALL

 SELECT 1745, 11, 'Claraval' FROM dual
 UNION ALL

 SELECT 1746, 11, 'Claro dos Poções' FROM dual
 UNION ALL

 SELECT 1747, 11, 'Cláudio' FROM dual
 UNION ALL

 SELECT 1748, 11, 'Coimbra' FROM dual
 UNION ALL

 SELECT 1749, 11, 'Coluna' FROM dual
 UNION ALL

 SELECT 1750, 11, 'Comendador Gomes' FROM dual
 UNION ALL

 SELECT 1751, 11, 'Comercinho' FROM dual
 UNION ALL

 SELECT 1752, 11, 'Conceição da Aparecida' FROM dual
 UNION ALL

 SELECT 1753, 11, 'Conceição da Barra de Minas' FROM dual
 UNION ALL

 SELECT 1754, 11, 'Conceição das Alagoas' FROM dual
 UNION ALL

 SELECT 1755, 11, 'Conceição das Pedras' FROM dual
 UNION ALL

 SELECT 1756, 11, 'Conceição de Ipanema' FROM dual
 UNION ALL

 SELECT 1757, 11, 'Conceição do Mato Dentro' FROM dual
 UNION ALL

 SELECT 1758, 11, 'Conceição do Pará' FROM dual
 UNION ALL

 SELECT 1759, 11, 'Conceição do Rio Verde' FROM dual
 UNION ALL

 SELECT 1760, 11, 'Conceição dos Ouros' FROM dual
 UNION ALL

 SELECT 1761, 11, 'Cônego Marinho' FROM dual
 UNION ALL

 SELECT 1762, 11, 'Confins' FROM dual
 UNION ALL

 SELECT 1763, 11, 'Congonhal' FROM dual
 UNION ALL

 SELECT 1764, 11, 'Congonhas' FROM dual
 UNION ALL

 SELECT 1765, 11, 'Congonhas do Norte' FROM dual
 UNION ALL

 SELECT 1766, 11, 'Conquista' FROM dual
 UNION ALL

 SELECT 1767, 11, 'Conselheiro Lafaiete' FROM dual
 UNION ALL

 SELECT 1768, 11, 'Conselheiro Pena' FROM dual
 UNION ALL

 SELECT 1769, 11, 'Consolação' FROM dual
 UNION ALL

 SELECT 1770, 11, 'Contagem' FROM dual
 UNION ALL

 SELECT 1771, 11, 'Coqueiral' FROM dual
 UNION ALL

 SELECT 1772, 11, 'Coração de Jesus' FROM dual
 UNION ALL

 SELECT 1773, 11, 'Cordisburgo' FROM dual
 UNION ALL

 SELECT 1774, 11, 'Cordislândia' FROM dual
 UNION ALL

 SELECT 1775, 11, 'Corinto' FROM dual
 UNION ALL

 SELECT 1776, 11, 'Coroaci' FROM dual
 UNION ALL

 SELECT 1777, 11, 'Coromandel' FROM dual
 UNION ALL

 SELECT 1778, 11, 'Coronel Fabriciano' FROM dual
 UNION ALL

 SELECT 1779, 11, 'Coronel Murta' FROM dual
 UNION ALL

 SELECT 1780, 11, 'Coronel Pacheco' FROM dual
 UNION ALL

 SELECT 1781, 11, 'Coronel Xavier Chaves' FROM dual
 UNION ALL

 SELECT 1782, 11, 'Córrego Danta' FROM dual
 UNION ALL

 SELECT 1783, 11, 'Córrego do Bom Jesus' FROM dual
 UNION ALL

 SELECT 1784, 11, 'Córrego Fundo' FROM dual
 UNION ALL

 SELECT 1785, 11, 'Córrego Novo' FROM dual
 UNION ALL

 SELECT 1786, 11, 'Couto de Magalhães de Minas' FROM dual
 UNION ALL

 SELECT 1787, 11, 'Crisólita' FROM dual
 UNION ALL

 SELECT 1788, 11, 'Cristais' FROM dual
 UNION ALL

 SELECT 1789, 11, 'Cristália' FROM dual
 UNION ALL

 SELECT 1790, 11, 'Cristiano Otoni' FROM dual
 UNION ALL

 SELECT 1791, 11, 'Cristina' FROM dual
 UNION ALL

 SELECT 1792, 11, 'Crucilândia' FROM dual
 UNION ALL

 SELECT 1793, 11, 'Cruzeiro da Fortaleza' FROM dual
 UNION ALL

 SELECT 1794, 11, 'Cruzília' FROM dual
 UNION ALL

 SELECT 1795, 11, 'Cuparaque' FROM dual
 UNION ALL

 SELECT 1796, 11, 'Curral de Dentro' FROM dual
 UNION ALL

 SELECT 1797, 11, 'Curvelo' FROM dual
 UNION ALL

 SELECT 1798, 11, 'Datas' FROM dual
 UNION ALL

 SELECT 1799, 11, 'Delfim Moreira' FROM dual
 UNION ALL

 SELECT 1800, 11, 'Delfinópolis' FROM dual
 UNION ALL

 SELECT 1801, 11, 'Delta' FROM dual
 UNION ALL

 SELECT 1802, 11, 'Descoberto' FROM dual
 UNION ALL

 SELECT 1803, 11, 'Desterro de Entre Rios' FROM dual
 UNION ALL

 SELECT 1804, 11, 'Desterro do Melo' FROM dual
 UNION ALL

 SELECT 1805, 11, 'Diamantina' FROM dual
 UNION ALL

 SELECT 1806, 11, 'Diogo de Vasconcelos' FROM dual
 UNION ALL

 SELECT 1807, 11, 'Dionísio' FROM dual
 UNION ALL

 SELECT 1808, 11, 'Divinésia' FROM dual
 UNION ALL

 SELECT 1809, 11, 'Divino' FROM dual
 UNION ALL

 SELECT 1810, 11, 'Divino das Laranjeiras' FROM dual
 UNION ALL

 SELECT 1811, 11, 'Divinolândia de Minas' FROM dual
 UNION ALL

 SELECT 1812, 11, 'Divinópolis' FROM dual
 UNION ALL

 SELECT 1813, 11, 'Divisa Alegre' FROM dual
 UNION ALL

 SELECT 1814, 11, 'Divisa Nova' FROM dual
 UNION ALL

 SELECT 1815, 11, 'Divisópolis' FROM dual
 UNION ALL

 SELECT 1816, 11, 'Dom Bosco' FROM dual
 UNION ALL

 SELECT 1817, 11, 'Dom Cavati' FROM dual
 UNION ALL

 SELECT 1818, 11, 'Dom Joaquim' FROM dual
 UNION ALL

 SELECT 1819, 11, 'Dom Silvério' FROM dual
 UNION ALL

 SELECT 1820, 11, 'Dom Viçoso' FROM dual
 UNION ALL

 SELECT 1821, 11, 'Dona Eusébia' FROM dual
 UNION ALL

 SELECT 1822, 11, 'Dores de Campos' FROM dual
 UNION ALL

 SELECT 1823, 11, 'Dores de Guanhães' FROM dual
 UNION ALL

 SELECT 1824, 11, 'Dores do Indaiá' FROM dual
 UNION ALL

 SELECT 1825, 11, 'Dores do Turvo' FROM dual
 UNION ALL

 SELECT 1826, 11, 'Doresópolis' FROM dual
 UNION ALL

 SELECT 1827, 11, 'Douradoquara' FROM dual
 UNION ALL

 SELECT 1828, 11, 'Durandé' FROM dual
 UNION ALL

 SELECT 1829, 11, 'Elói Mendes' FROM dual
 UNION ALL

 SELECT 1830, 11, 'Engenheiro Caldas' FROM dual
 UNION ALL

 SELECT 1831, 11, 'Engenheiro Navarro' FROM dual
 UNION ALL

 SELECT 1832, 11, 'Entre Folhas' FROM dual
 UNION ALL

 SELECT 1833, 11, 'Entre Rios de Minas' FROM dual
 UNION ALL

 SELECT 1834, 11, 'Ervália' FROM dual
 UNION ALL

 SELECT 1835, 11, 'Esmeraldas' FROM dual
 UNION ALL

 SELECT 1836, 11, 'Espera Feliz' FROM dual
 UNION ALL

 SELECT 1837, 11, 'Espinosa' FROM dual
 UNION ALL

 SELECT 1838, 11, 'Espírito Santo do Dourado' FROM dual
 UNION ALL

 SELECT 1839, 11, 'Estiva' FROM dual
 UNION ALL

 SELECT 1840, 11, 'Estrela Dalva' FROM dual
 UNION ALL

 SELECT 1841, 11, 'Estrela do Indaiá' FROM dual
 UNION ALL

 SELECT 1842, 11, 'Estrela do Sul' FROM dual
 UNION ALL

 SELECT 1843, 11, 'Eugenópolis' FROM dual
 UNION ALL

 SELECT 1844, 11, 'Ewbank da Câmara' FROM dual
 UNION ALL

 SELECT 1845, 11, 'Extrema' FROM dual
 UNION ALL

 SELECT 1846, 11, 'Fama' FROM dual
 UNION ALL

 SELECT 1847, 11, 'Faria Lemos' FROM dual
 UNION ALL

 SELECT 1848, 11, 'Felício dos Santos' FROM dual
 UNION ALL

 SELECT 1849, 11, 'Felisburgo' FROM dual
 UNION ALL

 SELECT 1850, 11, 'Felixlândia' FROM dual
 UNION ALL

 SELECT 1851, 11, 'Fernandes Tourinho' FROM dual
 UNION ALL

 SELECT 1852, 11, 'Ferros' FROM dual
 UNION ALL

 SELECT 1853, 11, 'Fervedouro' FROM dual
 UNION ALL

 SELECT 1854, 11, 'Florestal' FROM dual
 UNION ALL

 SELECT 1855, 11, 'Formiga' FROM dual
 UNION ALL

 SELECT 1856, 11, 'Formoso' FROM dual
 UNION ALL

 SELECT 1857, 11, 'Fortaleza de Minas' FROM dual
 UNION ALL

 SELECT 1858, 11, 'Fortuna de Minas' FROM dual
 UNION ALL

 SELECT 1859, 11, 'Francisco Badaró' FROM dual
 UNION ALL

 SELECT 1860, 11, 'Francisco Dumont' FROM dual
 UNION ALL

 SELECT 1861, 11, 'Francisco Sá' FROM dual
 UNION ALL

 SELECT 1862, 11, 'Franciscópolis' FROM dual
 UNION ALL

 SELECT 1863, 11, 'Frei Gaspar' FROM dual
 UNION ALL

 SELECT 1864, 11, 'Frei Inocêncio' FROM dual
 UNION ALL

 SELECT 1865, 11, 'Frei Lagonegro' FROM dual
 UNION ALL

 SELECT 1866, 11, 'Fronteira' FROM dual
 UNION ALL

 SELECT 1867, 11, 'Fronteira dos Vales' FROM dual
 UNION ALL

 SELECT 1868, 11, 'Fruta de Leite' FROM dual
 UNION ALL

 SELECT 1869, 11, 'Frutal' FROM dual
 UNION ALL

 SELECT 1870, 11, 'Funilândia' FROM dual
 UNION ALL

 SELECT 1871, 11, 'Galiléia' FROM dual
 UNION ALL

 SELECT 1872, 11, 'Gameleiras' FROM dual
 UNION ALL

 SELECT 1873, 11, 'Glaucilândia' FROM dual
 UNION ALL

 SELECT 1874, 11, 'Goiabeira' FROM dual
 UNION ALL

 SELECT 1875, 11, 'Goianá' FROM dual
 UNION ALL

 SELECT 1876, 11, 'Gonçalves' FROM dual
 UNION ALL

 SELECT 1877, 11, 'Gonzaga' FROM dual
 UNION ALL

 SELECT 1878, 11, 'Gouveia' FROM dual
 UNION ALL

 SELECT 1879, 11, 'Governador Valadares' FROM dual
 UNION ALL

 SELECT 1880, 11, 'Grão Mogol' FROM dual
 UNION ALL

 SELECT 1881, 11, 'Grupiara' FROM dual
 UNION ALL

 SELECT 1882, 11, 'Guanhães' FROM dual
 UNION ALL

 SELECT 1883, 11, 'Guapé' FROM dual
 UNION ALL

 SELECT 1884, 11, 'Guaraciaba' FROM dual
 UNION ALL

 SELECT 1885, 11, 'Guaraciama' FROM dual
 UNION ALL

 SELECT 1886, 11, 'Guaranésia' FROM dual
 UNION ALL

 SELECT 1887, 11, 'Guarani' FROM dual
 UNION ALL

 SELECT 1888, 11, 'Guarará' FROM dual
 UNION ALL

 SELECT 1889, 11, 'Guarda-Mor' FROM dual
 UNION ALL

 SELECT 1890, 11, 'Guaxupé' FROM dual
 UNION ALL

 SELECT 1891, 11, 'Guidoval' FROM dual
 UNION ALL

 SELECT 1892, 11, 'Guimarânia' FROM dual
 UNION ALL

 SELECT 1893, 11, 'Guiricema' FROM dual
 UNION ALL

 SELECT 1894, 11, 'Gurinhatã' FROM dual
 UNION ALL

 SELECT 1895, 11, 'Heliodora' FROM dual
 UNION ALL

 SELECT 1896, 11, 'Iapu' FROM dual
 UNION ALL

 SELECT 1897, 11, 'Ibertioga' FROM dual
 UNION ALL

 SELECT 1898, 11, 'Ibiá' FROM dual
 UNION ALL

 SELECT 1899, 11, 'Ibiaí' FROM dual
 UNION ALL

 SELECT 1900, 11, 'Ibiracatu' FROM dual
 UNION ALL

 SELECT 1901, 11, 'Ibiraci' FROM dual
 UNION ALL

 SELECT 1902, 11, 'Ibirité' FROM dual
 UNION ALL

 SELECT 1903, 11, 'Ibitiúra de Minas' FROM dual
 UNION ALL

 SELECT 1904, 11, 'Ibituruna' FROM dual
 UNION ALL

 SELECT 1905, 11, 'Icaraí de Minas' FROM dual
 UNION ALL

 SELECT 1906, 11, 'Igarapé' FROM dual
 UNION ALL

 SELECT 1907, 11, 'Igaratinga' FROM dual
 UNION ALL

 SELECT 1908, 11, 'Iguatama' FROM dual
 UNION ALL

 SELECT 1909, 11, 'Ijaci' FROM dual
 UNION ALL

 SELECT 1910, 11, 'Ilicínea' FROM dual
 UNION ALL

 SELECT 1911, 11, 'Imbé de Minas' FROM dual
 UNION ALL

 SELECT 1912, 11, 'Inconfidentes' FROM dual
 UNION ALL

 SELECT 1913, 11, 'Indaiabira' FROM dual
 UNION ALL

 SELECT 1914, 11, 'Indianópolis' FROM dual
 UNION ALL

 SELECT 1915, 11, 'Ingaí' FROM dual
 UNION ALL

 SELECT 1916, 11, 'Inhapim' FROM dual
 UNION ALL

 SELECT 1917, 11, 'Inhaúma' FROM dual
 UNION ALL

 SELECT 1918, 11, 'Inimutaba' FROM dual
 UNION ALL

 SELECT 1919, 11, 'Ipaba' FROM dual
 UNION ALL

 SELECT 1920, 11, 'Ipanema' FROM dual
 UNION ALL

 SELECT 1921, 11, 'Ipatinga' FROM dual
 UNION ALL

 SELECT 1922, 11, 'Ipiaçu' FROM dual
 UNION ALL

 SELECT 1923, 11, 'Ipuiúna' FROM dual
 UNION ALL

 SELECT 1924, 11, 'Iraí de Minas' FROM dual
 UNION ALL

 SELECT 1925, 11, 'Itabira' FROM dual
 UNION ALL

 SELECT 1926, 11, 'Itabirinha de Mantena' FROM dual
 UNION ALL

 SELECT 1927, 11, 'Itabirito' FROM dual
 UNION ALL

 SELECT 1928, 11, 'Itacambira' FROM dual
 UNION ALL

 SELECT 1929, 11, 'Itacarambi' FROM dual
 UNION ALL

 SELECT 1930, 11, 'Itaguara' FROM dual
 UNION ALL

 SELECT 1931, 11, 'Itaipé' FROM dual
 UNION ALL

 SELECT 1932, 11, 'Itajubá' FROM dual
 UNION ALL

 SELECT 1933, 11, 'Itamarandiba' FROM dual
 UNION ALL

 SELECT 1934, 11, 'Itamarati de Minas' FROM dual
 UNION ALL

 SELECT 1935, 11, 'Itambacuri' FROM dual
 UNION ALL

 SELECT 1936, 11, 'Itambé do Mato Dentro' FROM dual
 UNION ALL

 SELECT 1937, 11, 'Itamogi' FROM dual
 UNION ALL

 SELECT 1938, 11, 'Itamonte' FROM dual
 UNION ALL

 SELECT 1939, 11, 'Itanhandu' FROM dual
 UNION ALL

 SELECT 1940, 11, 'Itanhomi' FROM dual
 UNION ALL

 SELECT 1941, 11, 'Itaobim' FROM dual
 UNION ALL

 SELECT 1942, 11, 'Itapagipe' FROM dual
 UNION ALL

 SELECT 1943, 11, 'Itapecerica' FROM dual
 UNION ALL

 SELECT 1944, 11, 'Itapeva' FROM dual
 UNION ALL

 SELECT 1945, 11, 'Itatiaiuçu' FROM dual
 UNION ALL

 SELECT 1946, 11, 'Itaú de Minas' FROM dual
 UNION ALL

 SELECT 1947, 11, 'Itaúna' FROM dual
 UNION ALL

 SELECT 1948, 11, 'Itaverava' FROM dual
 UNION ALL

 SELECT 1949, 11, 'Itinga' FROM dual
 UNION ALL

 SELECT 1950, 11, 'Itueta' FROM dual
 UNION ALL

 SELECT 1951, 11, 'Ituiutaba' FROM dual
 UNION ALL

 SELECT 1952, 11, 'Itumirim' FROM dual
 UNION ALL

 SELECT 1953, 11, 'Iturama' FROM dual
 UNION ALL

 SELECT 1954, 11, 'Itutinga' FROM dual
 UNION ALL

 SELECT 1955, 11, 'Jaboticatubas' FROM dual
 UNION ALL

 SELECT 1956, 11, 'Jacinto' FROM dual
 UNION ALL

 SELECT 1957, 11, 'Jacuí' FROM dual
 UNION ALL

 SELECT 1958, 11, 'Jacutinga' FROM dual
 UNION ALL

 SELECT 1959, 11, 'Jaguaraçu' FROM dual
 UNION ALL

 SELECT 1960, 11, 'Jaíba' FROM dual
 UNION ALL

 SELECT 1961, 11, 'Jampruca' FROM dual
 UNION ALL

 SELECT 1962, 11, 'Janaúba' FROM dual
 UNION ALL

 SELECT 1963, 11, 'Januária' FROM dual
 UNION ALL

 SELECT 1964, 11, 'Japaraíba' FROM dual
 UNION ALL

 SELECT 1965, 11, 'Japonvar' FROM dual
 UNION ALL

 SELECT 1966, 11, 'Jeceaba' FROM dual
 UNION ALL

 SELECT 1967, 11, 'Jenipapo de Minas' FROM dual
 UNION ALL

 SELECT 1968, 11, 'Jequeri' FROM dual
 UNION ALL

 SELECT 1969, 11, 'Jequitaí' FROM dual
 UNION ALL

 SELECT 1970, 11, 'Jequitibá' FROM dual
 UNION ALL

 SELECT 1971, 11, 'Jequitinhonha' FROM dual
 UNION ALL

 SELECT 1972, 11, 'Jesuânia' FROM dual
 UNION ALL

 SELECT 1973, 11, 'Joaíma' FROM dual
 UNION ALL

 SELECT 1974, 11, 'Joanésia' FROM dual
 UNION ALL

 SELECT 1975, 11, 'João Monlevade' FROM dual
 UNION ALL

 SELECT 1976, 11, 'João Pinheiro' FROM dual
 UNION ALL

 SELECT 1977, 11, 'Joaquim Felício' FROM dual
 UNION ALL

 SELECT 1978, 11, 'Jordânia' FROM dual
 UNION ALL

 SELECT 1979, 11, 'José Gonçalves de Minas' FROM dual
 UNION ALL

 SELECT 1980, 11, 'José Raydan' FROM dual
 UNION ALL

 SELECT 1981, 11, 'Josenópolis' FROM dual
 UNION ALL

 SELECT 1982, 11, 'Juatuba' FROM dual
 UNION ALL

 SELECT 1983, 11, 'Juiz de Fora' FROM dual
 UNION ALL

 SELECT 1984, 11, 'Juramento' FROM dual
 UNION ALL

 SELECT 1985, 11, 'Juruaia' FROM dual
 UNION ALL

 SELECT 1986, 11, 'Juvenília' FROM dual
 UNION ALL

 SELECT 1987, 11, 'Ladainha' FROM dual
 UNION ALL

 SELECT 1988, 11, 'Lagamar' FROM dual
 UNION ALL

 SELECT 1989, 11, 'Lagoa da Prata' FROM dual
 UNION ALL

 SELECT 1990, 11, 'Lagoa dos Patos' FROM dual
 UNION ALL

 SELECT 1991, 11, 'Lagoa Dourada' FROM dual
 UNION ALL

 SELECT 1992, 11, 'Lagoa Formosa' FROM dual
 UNION ALL

 SELECT 1993, 11, 'Lagoa Grande' FROM dual
 UNION ALL

 SELECT 1994, 11, 'Lagoa Santa' FROM dual
 UNION ALL

 SELECT 1995, 11, 'Lajinha' FROM dual
 UNION ALL

 SELECT 1996, 11, 'Lambari' FROM dual
 UNION ALL

 SELECT 1997, 11, 'Lamim' FROM dual
 UNION ALL

 SELECT 1998, 11, 'Laranjal' FROM dual
 UNION ALL

 SELECT 1999, 11, 'Lassance' FROM dual
 UNION ALL

 SELECT 2000, 11, 'Lavras' FROM dual
 UNION ALL

 SELECT 2001, 11, 'Leandro Ferreira' FROM dual
 UNION ALL

 SELECT 2002, 11, 'Leme do Prado' FROM dual
 UNION ALL

 SELECT 2003, 11, 'Leopoldina' FROM dual
 UNION ALL

 SELECT 2004, 11, 'Liberdade' FROM dual
 UNION ALL

 SELECT 2005, 11, 'Lima Duarte' FROM dual
 UNION ALL

 SELECT 2006, 11, 'Limeira do Oeste' FROM dual
 UNION ALL

 SELECT 2007, 11, 'Lontra' FROM dual
 UNION ALL

 SELECT 2008, 11, 'Luisburgo' FROM dual
 UNION ALL

 SELECT 2009, 11, 'Luislândia' FROM dual
 UNION ALL

 SELECT 2010, 11, 'Luminárias' FROM dual
 UNION ALL

 SELECT 2011, 11, 'Luz' FROM dual
 UNION ALL

 SELECT 2012, 11, 'Machacalis' FROM dual
 UNION ALL

 SELECT 2013, 11, 'Machado' FROM dual
 UNION ALL

 SELECT 2014, 11, 'Madre de Deus de Minas' FROM dual
 UNION ALL

 SELECT 2015, 11, 'Malacacheta' FROM dual
 UNION ALL

 SELECT 2016, 11, 'Mamonas' FROM dual
 UNION ALL

 SELECT 2017, 11, 'Manga' FROM dual
 UNION ALL

 SELECT 2018, 11, 'Manhuaçu' FROM dual
 UNION ALL

 SELECT 2019, 11, 'Manhumirim' FROM dual
 UNION ALL

 SELECT 2020, 11, 'Mantena' FROM dual
 UNION ALL

 SELECT 2021, 11, 'Mar de Espanha' FROM dual
 UNION ALL

 SELECT 2022, 11, 'Maravilhas' FROM dual
 UNION ALL

 SELECT 2023, 11, 'Maria da Fé' FROM dual
 UNION ALL

 SELECT 2024, 11, 'Mariana' FROM dual
 UNION ALL

 SELECT 2025, 11, 'Marilac' FROM dual
 UNION ALL

 SELECT 2026, 11, 'Mário Campos' FROM dual
 UNION ALL

 SELECT 2027, 11, 'Maripá de Minas' FROM dual
 UNION ALL

 SELECT 2028, 11, 'Marliéria' FROM dual
 UNION ALL

 SELECT 2029, 11, 'Marmelópolis' FROM dual
 UNION ALL

 SELECT 2030, 11, 'Martinho Campos' FROM dual
 UNION ALL

 SELECT 2031, 11, 'Martins Soares' FROM dual
 UNION ALL

 SELECT 2032, 11, 'Mata Verde' FROM dual
 UNION ALL

 SELECT 2033, 11, 'Materlândia' FROM dual
 UNION ALL

 SELECT 2034, 11, 'Mateus Leme' FROM dual
 UNION ALL

 SELECT 2035, 11, 'Mathias Lobato' FROM dual
 UNION ALL

 SELECT 2036, 11, 'Matias Barbosa' FROM dual
 UNION ALL

 SELECT 2037, 11, 'Matias Cardoso' FROM dual
 UNION ALL

 SELECT 2038, 11, 'Matipó' FROM dual
 UNION ALL

 SELECT 2039, 11, 'Mato Verde' FROM dual
 UNION ALL

 SELECT 2040, 11, 'Matozinhos' FROM dual
 UNION ALL

 SELECT 2041, 11, 'Matutina' FROM dual
 UNION ALL

 SELECT 2042, 11, 'Medeiros' FROM dual
 UNION ALL

 SELECT 2043, 11, 'Medina' FROM dual
 UNION ALL

 SELECT 2044, 11, 'Mendes Pimentel' FROM dual
 UNION ALL

 SELECT 2045, 11, 'Mercês' FROM dual
 UNION ALL

 SELECT 2046, 11, 'Mesquita' FROM dual
 UNION ALL

 SELECT 2047, 11, 'Minas Novas' FROM dual
 UNION ALL

 SELECT 2048, 11, 'Minduri' FROM dual
 UNION ALL

 SELECT 2049, 11, 'Mirabela' FROM dual
 UNION ALL

 SELECT 2050, 11, 'Miradouro' FROM dual
 UNION ALL

 SELECT 2051, 11, 'Miraí' FROM dual
 UNION ALL

 SELECT 2052, 11, 'Miravânia' FROM dual
 UNION ALL

 SELECT 2053, 11, 'Moeda' FROM dual
 UNION ALL

 SELECT 2054, 11, 'Moema' FROM dual
 UNION ALL

 SELECT 2055, 11, 'Monjolos' FROM dual
 UNION ALL

 SELECT 2056, 11, 'Monsenhor Paulo' FROM dual
 UNION ALL

 SELECT 2057, 11, 'Montalvânia' FROM dual
 UNION ALL

 SELECT 2058, 11, 'Monte Alegre de Minas' FROM dual
 UNION ALL

 SELECT 2059, 11, 'Monte Azul' FROM dual
 UNION ALL

 SELECT 2060, 11, 'Monte Belo' FROM dual
 UNION ALL

 SELECT 2061, 11, 'Monte Carmelo' FROM dual
 UNION ALL

 SELECT 2062, 11, 'Monte Formoso' FROM dual
 UNION ALL

 SELECT 2063, 11, 'Monte Santo de Minas' FROM dual
 UNION ALL

 SELECT 2064, 11, 'Monte Sião' FROM dual
 UNION ALL

 SELECT 2065, 11, 'Montes Claros' FROM dual
 UNION ALL

 SELECT 2066, 11, 'Montezuma' FROM dual
 UNION ALL

 SELECT 2067, 11, 'Morada Nova de Minas' FROM dual
 UNION ALL

 SELECT 2068, 11, 'Morro da Garça' FROM dual
 UNION ALL

 SELECT 2069, 11, 'Morro do Pilar' FROM dual
 UNION ALL

 SELECT 2070, 11, 'Munhoz' FROM dual
 UNION ALL

 SELECT 2071, 11, 'Muriaé' FROM dual
 UNION ALL

 SELECT 2072, 11, 'Mutum' FROM dual
 UNION ALL

 SELECT 2073, 11, 'Muzambinho' FROM dual
 UNION ALL

 SELECT 2074, 11, 'Nacip Raydan' FROM dual
 UNION ALL

 SELECT 2075, 11, 'Nanuque' FROM dual
 UNION ALL

 SELECT 2076, 11, 'Naque' FROM dual
 UNION ALL

 SELECT 2077, 11, 'Natalândia' FROM dual
 UNION ALL

 SELECT 2078, 11, 'Natércia' FROM dual
 UNION ALL

 SELECT 2079, 11, 'Nazareno' FROM dual
 UNION ALL

 SELECT 2080, 11, 'Nepomuceno' FROM dual
 UNION ALL

 SELECT 2081, 11, 'Ninheira' FROM dual
 UNION ALL

 SELECT 2082, 11, 'Nova Belém' FROM dual
 UNION ALL

 SELECT 2083, 11, 'Nova Era' FROM dual
 UNION ALL

 SELECT 2084, 11, 'Nova Lima' FROM dual
 UNION ALL

 SELECT 2085, 11, 'Nova Módica' FROM dual
 UNION ALL

 SELECT 2086, 11, 'Nova Ponte' FROM dual
 UNION ALL

 SELECT 2087, 11, 'Nova Porteirinha' FROM dual
 UNION ALL

 SELECT 2088, 11, 'Nova Resende' FROM dual
 UNION ALL

 SELECT 2089, 11, 'Nova Serrana' FROM dual
 UNION ALL

 SELECT 2090, 11, 'Nova União' FROM dual
 UNION ALL

 SELECT 2091, 11, 'Novo Cruzeiro' FROM dual
 UNION ALL

 SELECT 2092, 11, 'Novo Oriente de Minas' FROM dual
 UNION ALL

 SELECT 2093, 11, 'Novorizonte' FROM dual
 UNION ALL

 SELECT 2094, 11, 'Olaria' FROM dual
 UNION ALL

 SELECT 2095, 11, 'Olhos-d`Água' FROM dual
 UNION ALL

 SELECT 2096, 11, 'Olímpio Noronha' FROM dual
 UNION ALL

 SELECT 2097, 11, 'Oliveira' FROM dual
 UNION ALL

 SELECT 2098, 11, 'Oliveira Fortes' FROM dual
 UNION ALL

 SELECT 2099, 11, 'Onça de Pitangui' FROM dual
 UNION ALL

 SELECT 2100, 11, 'Oratórios' FROM dual
 UNION ALL

 SELECT 2101, 11, 'Orizânia' FROM dual
 UNION ALL

 SELECT 2102, 11, 'Ouro Branco' FROM dual
 UNION ALL

 SELECT 2103, 11, 'Ouro Fino' FROM dual
 UNION ALL

 SELECT 2104, 11, 'Ouro Preto' FROM dual
 UNION ALL

 SELECT 2105, 11, 'Ouro Verde de Minas' FROM dual
 UNION ALL

 SELECT 2106, 11, 'Padre Carvalho' FROM dual
 UNION ALL

 SELECT 2107, 11, 'Padre Paraíso' FROM dual
 UNION ALL

 SELECT 2108, 11, 'Pai Pedro' FROM dual
 UNION ALL

 SELECT 2109, 11, 'Paineiras' FROM dual
 UNION ALL

 SELECT 2110, 11, 'Pains' FROM dual
 UNION ALL

 SELECT 2111, 11, 'Paiva' FROM dual
 UNION ALL

 SELECT 2112, 11, 'Palma' FROM dual
 UNION ALL

 SELECT 2113, 11, 'Palmópolis' FROM dual
 UNION ALL

 SELECT 2114, 11, 'Papagaios' FROM dual
 UNION ALL

 SELECT 2115, 11, 'Pará de Minas' FROM dual
 UNION ALL

 SELECT 2116, 11, 'Paracatu' FROM dual
 UNION ALL

 SELECT 2117, 11, 'Paraguaçu' FROM dual
 UNION ALL

 SELECT 2118, 11, 'Paraisópolis' FROM dual
 UNION ALL

 SELECT 2119, 11, 'Paraopeba' FROM dual
 UNION ALL

 SELECT 2120, 11, 'Passa Quatro' FROM dual
 UNION ALL

 SELECT 2121, 11, 'Passa Tempo' FROM dual
 UNION ALL

 SELECT 2122, 11, 'Passabém' FROM dual
 UNION ALL

 SELECT 2123, 11, 'Passa-Vinte' FROM dual
 UNION ALL

 SELECT 2124, 11, 'Passos' FROM dual
 UNION ALL

 SELECT 2125, 11, 'Patis' FROM dual
 UNION ALL

 SELECT 2126, 11, 'Patos de Minas' FROM dual
 UNION ALL

 SELECT 2127, 11, 'Patrocínio' FROM dual
 UNION ALL

 SELECT 2128, 11, 'Patrocínio do Muriaé' FROM dual
 UNION ALL

 SELECT 2129, 11, 'Paula Cândido' FROM dual
 UNION ALL

 SELECT 2130, 11, 'Paulistas' FROM dual
 UNION ALL

 SELECT 2131, 11, 'Pavão' FROM dual
 UNION ALL

 SELECT 2132, 11, 'Peçanha' FROM dual
 UNION ALL

 SELECT 2133, 11, 'Pedra Azul' FROM dual
 UNION ALL

 SELECT 2134, 11, 'Pedra Bonita' FROM dual
 UNION ALL

 SELECT 2135, 11, 'Pedra do Anta' FROM dual
 UNION ALL

 SELECT 2136, 11, 'Pedra do Indaiá' FROM dual
 UNION ALL

 SELECT 2137, 11, 'Pedra Dourada' FROM dual
 UNION ALL

 SELECT 2138, 11, 'Pedralva' FROM dual
 UNION ALL

 SELECT 2139, 11, 'Pedras de Maria da Cruz' FROM dual
 UNION ALL

 SELECT 2140, 11, 'Pedrinópolis' FROM dual
 UNION ALL

 SELECT 2141, 11, 'Pedro Leopoldo' FROM dual
 UNION ALL

 SELECT 2142, 11, 'Pedro Teixeira' FROM dual
 UNION ALL

 SELECT 2143, 11, 'Pequeri' FROM dual
 UNION ALL

 SELECT 2144, 11, 'Pequi' FROM dual
 UNION ALL

 SELECT 2145, 11, 'Perdigão' FROM dual
 UNION ALL

 SELECT 2146, 11, 'Perdizes' FROM dual
 UNION ALL

 SELECT 2147, 11, 'Perdões' FROM dual
 UNION ALL

 SELECT 2148, 11, 'Periquito' FROM dual
 UNION ALL

 SELECT 2149, 11, 'Pescador' FROM dual
 UNION ALL

 SELECT 2150, 11, 'Piau' FROM dual
 UNION ALL

 SELECT 2151, 11, 'Piedade de Caratinga' FROM dual
 UNION ALL

 SELECT 2152, 11, 'Piedade de Ponte Nova' FROM dual
 UNION ALL

 SELECT 2153, 11, 'Piedade do Rio Grande' FROM dual
 UNION ALL

 SELECT 2154, 11, 'Piedade dos Gerais' FROM dual
 UNION ALL

 SELECT 2155, 11, 'Pimenta' FROM dual
 UNION ALL

 SELECT 2156, 11, 'Pingo-d`Água' FROM dual
 UNION ALL

 SELECT 2157, 11, 'Pintópolis' FROM dual
 UNION ALL

 SELECT 2158, 11, 'Piracema' FROM dual
 UNION ALL

 SELECT 2159, 11, 'Pirajuba' FROM dual
 UNION ALL

 SELECT 2160, 11, 'Piranga' FROM dual
 UNION ALL

 SELECT 2161, 11, 'Piranguçu' FROM dual
 UNION ALL

 SELECT 2162, 11, 'Piranguinho' FROM dual
 UNION ALL

 SELECT 2163, 11, 'Pirapetinga' FROM dual
 UNION ALL

 SELECT 2164, 11, 'Pirapora' FROM dual
 UNION ALL

 SELECT 2165, 11, 'Piraúba' FROM dual
 UNION ALL

 SELECT 2166, 11, 'Pitangui' FROM dual
 UNION ALL

 SELECT 2167, 11, 'Piumhi' FROM dual
 UNION ALL

 SELECT 2168, 11, 'Planura' FROM dual
 UNION ALL

 SELECT 2169, 11, 'Poço Fundo' FROM dual
 UNION ALL

 SELECT 2170, 11, 'Poços de Caldas' FROM dual
 UNION ALL

 SELECT 2171, 11, 'Pocrane' FROM dual
 UNION ALL

 SELECT 2172, 11, 'Pompéu' FROM dual
 UNION ALL

 SELECT 2173, 11, 'Ponte Nova' FROM dual
 UNION ALL

 SELECT 2174, 11, 'Ponto Chique' FROM dual
 UNION ALL

 SELECT 2175, 11, 'Ponto dos Volantes' FROM dual
 UNION ALL

 SELECT 2176, 11, 'Porteirinha' FROM dual
 UNION ALL

 SELECT 2177, 11, 'Porto Firme' FROM dual
 UNION ALL

 SELECT 2178, 11, 'Poté' FROM dual
 UNION ALL

 SELECT 2179, 11, 'Pouso Alegre' FROM dual
 UNION ALL

 SELECT 2180, 11, 'Pouso Alto' FROM dual
 UNION ALL

 SELECT 2181, 11, 'Prados' FROM dual
 UNION ALL

 SELECT 2182, 11, 'Prata' FROM dual
 UNION ALL

 SELECT 2183, 11, 'Pratápolis' FROM dual
 UNION ALL

 SELECT 2184, 11, 'Pratinha' FROM dual
 UNION ALL

 SELECT 2185, 11, 'Presidente Bernardes' FROM dual
 UNION ALL

 SELECT 2186, 11, 'Presidente Juscelino' FROM dual
 UNION ALL

 SELECT 2187, 11, 'Presidente Kubitschek' FROM dual
 UNION ALL

 SELECT 2188, 11, 'Presidente Olegário' FROM dual
 UNION ALL

 SELECT 2189, 11, 'Prudente de Morais' FROM dual
 UNION ALL

 SELECT 2190, 11, 'Quartel Geral' FROM dual
 UNION ALL

 SELECT 2191, 11, 'Queluzito' FROM dual
 UNION ALL

 SELECT 2192, 11, 'Raposos' FROM dual
 UNION ALL

 SELECT 2193, 11, 'Raul Soares' FROM dual
 UNION ALL

 SELECT 2194, 11, 'Recreio' FROM dual
 UNION ALL

 SELECT 2195, 11, 'Reduto' FROM dual
 UNION ALL

 SELECT 2196, 11, 'Resende Costa' FROM dual
 UNION ALL

 SELECT 2197, 11, 'Resplendor' FROM dual
 UNION ALL

 SELECT 2198, 11, 'Ressaquinha' FROM dual
 UNION ALL

 SELECT 2199, 11, 'Riachinho' FROM dual
 UNION ALL

 SELECT 2200, 11, 'Riacho dos Machados' FROM dual
 UNION ALL

 SELECT 2201, 11, 'Ribeirão das Neves' FROM dual
 UNION ALL

 SELECT 2202, 11, 'Ribeirão Vermelho' FROM dual
 UNION ALL

 SELECT 2203, 11, 'Rio Acima' FROM dual
 UNION ALL

 SELECT 2204, 11, 'Rio Casca' FROM dual
 UNION ALL

 SELECT 2205, 11, 'Rio do Prado' FROM dual
 UNION ALL

 SELECT 2206, 11, 'Rio Doce' FROM dual
 UNION ALL

 SELECT 2207, 11, 'Rio Espera' FROM dual
 UNION ALL

 SELECT 2208, 11, 'Rio Manso' FROM dual
 UNION ALL

 SELECT 2209, 11, 'Rio Novo' FROM dual
 UNION ALL

 SELECT 2210, 11, 'Rio Paranaíba' FROM dual
 UNION ALL

 SELECT 2211, 11, 'Rio Pardo de Minas' FROM dual
 UNION ALL

 SELECT 2212, 11, 'Rio Piracicaba' FROM dual
 UNION ALL

 SELECT 2213, 11, 'Rio Pomba' FROM dual
 UNION ALL

 SELECT 2214, 11, 'Rio Preto' FROM dual
 UNION ALL

 SELECT 2215, 11, 'Rio Vermelho' FROM dual
 UNION ALL

 SELECT 2216, 11, 'Ritápolis' FROM dual
 UNION ALL

 SELECT 2217, 11, 'Rochedo de Minas' FROM dual
 UNION ALL

 SELECT 2218, 11, 'Rodeiro' FROM dual
 UNION ALL

 SELECT 2219, 11, 'Romaria' FROM dual
 UNION ALL

 SELECT 2220, 11, 'Rosário da Limeira' FROM dual
 UNION ALL

 SELECT 2221, 11, 'Rubelita' FROM dual
 UNION ALL

 SELECT 2222, 11, 'Rubim' FROM dual
 UNION ALL

 SELECT 2223, 11, 'Sabará' FROM dual
 UNION ALL

 SELECT 2224, 11, 'Sabinópolis' FROM dual
 UNION ALL

 SELECT 2225, 11, 'Sacramento' FROM dual
 UNION ALL

 SELECT 2226, 11, 'Salinas' FROM dual
 UNION ALL

 SELECT 2227, 11, 'Salto da Divisa' FROM dual
 UNION ALL

 SELECT 2228, 11, 'Santa Bárbara' FROM dual
 UNION ALL

 SELECT 2229, 11, 'Santa Bárbara do Leste' FROM dual
 UNION ALL

 SELECT 2230, 11, 'Santa Bárbara do Monte Verde' FROM dual
 UNION ALL

 SELECT 2231, 11, 'Santa Bárbara do Tugúrio' FROM dual
 UNION ALL

 SELECT 2232, 11, 'Santa Cruz de Minas' FROM dual
 UNION ALL

 SELECT 2233, 11, 'Santa Cruz de Salinas' FROM dual
 UNION ALL

 SELECT 2234, 11, 'Santa Cruz do Escalvado' FROM dual
 UNION ALL

 SELECT 2235, 11, 'Santa Efigênia de Minas' FROM dual
 UNION ALL

 SELECT 2236, 11, 'Santa Fé de Minas' FROM dual
 UNION ALL

 SELECT 2237, 11, 'Santa Helena de Minas' FROM dual
 UNION ALL

 SELECT 2238, 11, 'Santa Juliana' FROM dual
 UNION ALL

 SELECT 2239, 11, 'Santa Luzia' FROM dual
 UNION ALL

 SELECT 2240, 11, 'Santa Margarida' FROM dual
 UNION ALL

 SELECT 2241, 11, 'Santa Maria de Itabira' FROM dual
 UNION ALL

 SELECT 2242, 11, 'Santa Maria do Salto' FROM dual
 UNION ALL

 SELECT 2243, 11, 'Santa Maria do Suaçuí' FROM dual
 UNION ALL

 SELECT 2244, 11, 'Santa Rita de Caldas' FROM dual
 UNION ALL

 SELECT 2245, 11, 'Santa Rita de Ibitipoca' FROM dual
 UNION ALL

 SELECT 2246, 11, 'Santa Rita de Jacutinga' FROM dual
 UNION ALL

 SELECT 2247, 11, 'Santa Rita de Minas' FROM dual
 UNION ALL

 SELECT 2248, 11, 'Santa Rita do Itueto' FROM dual
 UNION ALL

 SELECT 2249, 11, 'Santa Rita do Sapucaí' FROM dual
 UNION ALL

 SELECT 2250, 11, 'Santa Rosa da Serra' FROM dual
 UNION ALL

 SELECT 2251, 11, 'Santa Vitória' FROM dual
 UNION ALL

 SELECT 2252, 11, 'Santana da Vargem' FROM dual
 UNION ALL

 SELECT 2253, 11, 'Santana de Cataguases' FROM dual
 UNION ALL

 SELECT 2254, 11, 'Santana de Pirapama' FROM dual
 UNION ALL

 SELECT 2255, 11, 'Santana do Deserto' FROM dual
 UNION ALL

 SELECT 2256, 11, 'Santana do Garambéu' FROM dual
 UNION ALL

 SELECT 2257, 11, 'Santana do Jacaré' FROM dual
 UNION ALL

 SELECT 2258, 11, 'Santana do Manhuaçu' FROM dual
 UNION ALL

 SELECT 2259, 11, 'Santana do Paraíso' FROM dual
 UNION ALL

 SELECT 2260, 11, 'Santana do Riacho' FROM dual
 UNION ALL

 SELECT 2261, 11, 'Santana dos Montes' FROM dual
 UNION ALL

 SELECT 2262, 11, 'Santo Antônio do Amparo' FROM dual
 UNION ALL

 SELECT 2263, 11, 'Santo Antônio do Aventureiro' FROM dual
 UNION ALL

 SELECT 2264, 11, 'Santo Antônio do Grama' FROM dual
 UNION ALL

 SELECT 2265, 11, 'Santo Antônio do Itambé' FROM dual
 UNION ALL

 SELECT 2266, 11, 'Santo Antônio do Jacinto' FROM dual
 UNION ALL

 SELECT 2267, 11, 'Santo Antônio do Monte' FROM dual
 UNION ALL

 SELECT 2268, 11, 'Santo Antônio do Retiro' FROM dual
 UNION ALL

 SELECT 2269, 11, 'Santo Antônio do Rio Abaixo' FROM dual
 UNION ALL

 SELECT 2270, 11, 'Santo Hipólito' FROM dual
 UNION ALL

 SELECT 2271, 11, 'Santos Dumont' FROM dual
 UNION ALL

 SELECT 2272, 11, 'São Bento Abade' FROM dual
 UNION ALL

 SELECT 2273, 11, 'São Brás do Suaçuí' FROM dual
 UNION ALL

 SELECT 2274, 11, 'São Domingos das Dores' FROM dual
 UNION ALL

 SELECT 2275, 11, 'São Domingos do Prata' FROM dual
 UNION ALL

 SELECT 2276, 11, 'São Félix de Minas' FROM dual
 UNION ALL

 SELECT 2277, 11, 'São Francisco' FROM dual
 UNION ALL

 SELECT 2278, 11, 'São Francisco de Paula' FROM dual
 UNION ALL

 SELECT 2279, 11, 'São Francisco de Sales' FROM dual
 UNION ALL

 SELECT 2280, 11, 'São Francisco do Glória' FROM dual
 UNION ALL

 SELECT 2281, 11, 'São Geraldo' FROM dual
 UNION ALL

 SELECT 2282, 11, 'São Geraldo da Piedade' FROM dual
 UNION ALL

 SELECT 2283, 11, 'São Geraldo do Baixio' FROM dual
 UNION ALL

 SELECT 2284, 11, 'São Gonçalo do Abaeté' FROM dual
 UNION ALL

 SELECT 2285, 11, 'São Gonçalo do Pará' FROM dual
 UNION ALL

 SELECT 2286, 11, 'São Gonçalo do Rio Abaixo' FROM dual
 UNION ALL

 SELECT 2287, 11, 'São Gonçalo do Rio Preto' FROM dual
 UNION ALL

 SELECT 2288, 11, 'São Gonçalo do Sapucaí' FROM dual
 UNION ALL

 SELECT 2289, 11, 'São Gotardo' FROM dual
 UNION ALL

 SELECT 2290, 11, 'São João Batista do Glória' FROM dual
 UNION ALL

 SELECT 2291, 11, 'São João da Lagoa' FROM dual
 UNION ALL

 SELECT 2292, 11, 'São João da Mata' FROM dual
 UNION ALL

 SELECT 2293, 11, 'São João da Ponte' FROM dual
 UNION ALL

 SELECT 2294, 11, 'São João das Missões' FROM dual
 UNION ALL

 SELECT 2295, 11, 'São João del Rei' FROM dual
 UNION ALL

 SELECT 2296, 11, 'São João do Manhuaçu' FROM dual
 UNION ALL

 SELECT 2297, 11, 'São João do Manteninha' FROM dual
 UNION ALL

 SELECT 2298, 11, 'São João do Oriente' FROM dual
 UNION ALL

 SELECT 2299, 11, 'São João do Pacuí' FROM dual
 UNION ALL

 SELECT 2300, 11, 'São João do Paraíso' FROM dual
 UNION ALL

 SELECT 2301, 11, 'São João Evangelista' FROM dual
 UNION ALL

 SELECT 2302, 11, 'São João Nepomuceno' FROM dual
 UNION ALL

 SELECT 2303, 11, 'São Joaquim de Bicas' FROM dual
 UNION ALL

 SELECT 2304, 11, 'São José da Barra' FROM dual
 UNION ALL

 SELECT 2305, 11, 'São José da Lapa' FROM dual
 UNION ALL

 SELECT 2306, 11, 'São José da Safira' FROM dual
 UNION ALL

 SELECT 2307, 11, 'São José da Varginha' FROM dual
 UNION ALL

 SELECT 2308, 11, 'São José do Alegre' FROM dual
 UNION ALL

 SELECT 2309, 11, 'São José do Divino' FROM dual
 UNION ALL

 SELECT 2310, 11, 'São José do Goiabal' FROM dual
 UNION ALL

 SELECT 2311, 11, 'São José do Jacuri' FROM dual
 UNION ALL

 SELECT 2312, 11, 'São José do Mantimento' FROM dual
 UNION ALL

 SELECT 2313, 11, 'São Lourenço' FROM dual
 UNION ALL

 SELECT 2314, 11, 'São Miguel do Anta' FROM dual
 UNION ALL

 SELECT 2315, 11, 'São Pedro da União' FROM dual
 UNION ALL

 SELECT 2316, 11, 'São Pedro do Suaçuí' FROM dual
 UNION ALL

 SELECT 2317, 11, 'São Pedro dos Ferros' FROM dual
 UNION ALL

 SELECT 2318, 11, 'São Romão' FROM dual
 UNION ALL

 SELECT 2319, 11, 'São Roque de Minas' FROM dual
 UNION ALL

 SELECT 2320, 11, 'São Sebastião da Bela Vista' FROM dual
 UNION ALL

 SELECT 2321, 11, 'São Sebastião da Vargem Alegre' FROM dual
 UNION ALL

 SELECT 2322, 11, 'São Sebastião do Anta' FROM dual
 UNION ALL

 SELECT 2323, 11, 'São Sebastião do Maranhão' FROM dual
 UNION ALL

 SELECT 2324, 11, 'São Sebastião do Oeste' FROM dual
 UNION ALL

 SELECT 2325, 11, 'São Sebastião do Paraíso' FROM dual
 UNION ALL

 SELECT 2326, 11, 'São Sebastião do Rio Preto' FROM dual
 UNION ALL

 SELECT 2327, 11, 'São Sebastião do Rio Verde' FROM dual
 UNION ALL

 SELECT 2328, 11, 'São Thomé das Letras' FROM dual
 UNION ALL

 SELECT 2329, 11, 'São Tiago' FROM dual
 UNION ALL

 SELECT 2330, 11, 'São Tomás de Aquino' FROM dual
 UNION ALL

 SELECT 2331, 11, 'São Vicente de Minas' FROM dual
 UNION ALL

 SELECT 2332, 11, 'Sapucaí-Mirim' FROM dual
 UNION ALL

 SELECT 2333, 11, 'Sardoá' FROM dual
 UNION ALL

 SELECT 2334, 11, 'Sarzedo' FROM dual
 UNION ALL

 SELECT 2335, 11, 'Sem-Peixe' FROM dual
 UNION ALL

 SELECT 2336, 11, 'Senador Amaral' FROM dual
 UNION ALL

 SELECT 2337, 11, 'Senador Cortes' FROM dual
 UNION ALL

 SELECT 2338, 11, 'Senador Firmino' FROM dual
 UNION ALL

 SELECT 2339, 11, 'Senador José Bento' FROM dual
 UNION ALL

 SELECT 2340, 11, 'Senador Modestino Gonçalves' FROM dual
 UNION ALL

 SELECT 2341, 11, 'Senhora de Oliveira' FROM dual
 UNION ALL

 SELECT 2342, 11, 'Senhora do Porto' FROM dual
 UNION ALL

 SELECT 2343, 11, 'Senhora dos Remédios' FROM dual
 UNION ALL

 SELECT 2344, 11, 'Sericita' FROM dual
 UNION ALL

 SELECT 2345, 11, 'Seritinga' FROM dual
 UNION ALL

 SELECT 2346, 11, 'Serra Azul de Minas' FROM dual
 UNION ALL

 SELECT 2347, 11, 'Serra da Saudade' FROM dual
 UNION ALL

 SELECT 2348, 11, 'Serra do Salitre' FROM dual
 UNION ALL

 SELECT 2349, 11, 'Serra dos Aimorés' FROM dual
 UNION ALL

 SELECT 2350, 11, 'Serrania' FROM dual
 UNION ALL

 SELECT 2351, 11, 'Serranópolis de Minas' FROM dual
 UNION ALL

 SELECT 2352, 11, 'Serranos' FROM dual
 UNION ALL

 SELECT 2353, 11, 'Serro' FROM dual
 UNION ALL

 SELECT 2354, 11, 'Sete Lagoas' FROM dual
 UNION ALL

 SELECT 2355, 11, 'Setubinha' FROM dual
 UNION ALL

 SELECT 2356, 11, 'Silveirânia' FROM dual
 UNION ALL

 SELECT 2357, 11, 'Silvianópolis' FROM dual
 UNION ALL

 SELECT 2358, 11, 'Simão Pereira' FROM dual
 UNION ALL

 SELECT 2359, 11, 'Simonésia' FROM dual
 UNION ALL

 SELECT 2360, 11, 'Sobrália' FROM dual
 UNION ALL

 SELECT 2361, 11, 'Soledade de Minas' FROM dual
 UNION ALL

 SELECT 2362, 11, 'Tabuleiro' FROM dual
 UNION ALL

 SELECT 2363, 11, 'Taiobeiras' FROM dual
 UNION ALL

 SELECT 2364, 11, 'Taparuba' FROM dual
 UNION ALL

 SELECT 2365, 11, 'Tapira' FROM dual
 UNION ALL

 SELECT 2366, 11, 'Tapiraí' FROM dual
 UNION ALL

 SELECT 2367, 11, 'Taquaraçu de Minas' FROM dual
 UNION ALL

 SELECT 2368, 11, 'Tarumirim' FROM dual
 UNION ALL

 SELECT 2369, 11, 'Teixeiras' FROM dual
 UNION ALL

 SELECT 2370, 11, 'Teófilo Otoni' FROM dual
 UNION ALL

 SELECT 2371, 11, 'Timóteo' FROM dual
 UNION ALL

 SELECT 2372, 11, 'Tiradentes' FROM dual
 UNION ALL

 SELECT 2373, 11, 'Tiros' FROM dual
 UNION ALL

 SELECT 2374, 11, 'Tocantins' FROM dual
 UNION ALL

 SELECT 2375, 11, 'Tocos do Moji' FROM dual
 UNION ALL

 SELECT 2376, 11, 'Toledo' FROM dual
 UNION ALL

 SELECT 2377, 11, 'Tombos' FROM dual
 UNION ALL

 SELECT 2378, 11, 'Três Corações' FROM dual
 UNION ALL

 SELECT 2379, 11, 'Três Marias' FROM dual
 UNION ALL

 SELECT 2380, 11, 'Três Pontas' FROM dual
 UNION ALL

 SELECT 2381, 11, 'Tumiritinga' FROM dual
 UNION ALL

 SELECT 2382, 11, 'Tupaciguara' FROM dual
 UNION ALL

 SELECT 2383, 11, 'Turmalina' FROM dual
 UNION ALL

 SELECT 2384, 11, 'Turvolândia' FROM dual
 UNION ALL

 SELECT 2385, 11, 'Ubá' FROM dual
 UNION ALL

 SELECT 2386, 11, 'Ubaí' FROM dual
 UNION ALL

 SELECT 2387, 11, 'Ubaporanga' FROM dual
 UNION ALL

 SELECT 2388, 11, 'Uberaba' FROM dual
 UNION ALL

 SELECT 2389, 11, 'Uberlândia' FROM dual
 UNION ALL

 SELECT 2390, 11, 'Umburatiba' FROM dual
 UNION ALL

 SELECT 2391, 11, 'Unaí' FROM dual
 UNION ALL

 SELECT 2392, 11, 'União de Minas' FROM dual
 UNION ALL

 SELECT 2393, 11, 'Uruana de Minas' FROM dual
 UNION ALL

 SELECT 2394, 11, 'Urucânia' FROM dual
 UNION ALL

 SELECT 2395, 11, 'Urucuia' FROM dual
 UNION ALL

 SELECT 2396, 11, 'Vargem Alegre' FROM dual
 UNION ALL

 SELECT 2397, 11, 'Vargem Bonita' FROM dual
 UNION ALL

 SELECT 2398, 11, 'Vargem Grande do Rio Pardo' FROM dual
 UNION ALL

 SELECT 2399, 11, 'Varginha' FROM dual
 UNION ALL

 SELECT 2400, 11, 'Varjão de Minas' FROM dual
 UNION ALL

 SELECT 2401, 11, 'Várzea da Palma' FROM dual
 UNION ALL

 SELECT 2402, 11, 'Varzelândia' FROM dual
 UNION ALL

 SELECT 2403, 11, 'Vazante' FROM dual
 UNION ALL

 SELECT 2404, 11, 'Verdelândia' FROM dual
 UNION ALL

 SELECT 2405, 11, 'Veredinha' FROM dual
 UNION ALL

 SELECT 2406, 11, 'Veríssimo' FROM dual
 UNION ALL

 SELECT 2407, 11, 'Vermelho Novo' FROM dual
 UNION ALL

 SELECT 2408, 11, 'Vespasiano' FROM dual
 UNION ALL

 SELECT 2409, 11, 'Viçosa' FROM dual
 UNION ALL

 SELECT 2410, 11, 'Vieiras' FROM dual
 UNION ALL

 SELECT 2411, 11, 'Virgem da Lapa' FROM dual
 UNION ALL

 SELECT 2412, 11, 'Virgínia' FROM dual
 UNION ALL

 SELECT 2413, 11, 'Virginópolis' FROM dual
 UNION ALL

 SELECT 2414, 11, 'Virgolândia' FROM dual
 UNION ALL

 SELECT 2415, 11, 'Visconde do Rio Branco' FROM dual
 UNION ALL

 SELECT 2416, 11, 'Volta Grande' FROM dual
 UNION ALL

 SELECT 2417, 11, 'Wenceslau Braz' FROM dual
 UNION ALL

 SELECT 2418, 14, 'Abaetetuba' FROM dual
 UNION ALL

 SELECT 2419, 14, 'Abel Figueiredo' FROM dual
 UNION ALL

 SELECT 2420, 14, 'Acará' FROM dual
 UNION ALL

 SELECT 2421, 14, 'Afuá' FROM dual
 UNION ALL

 SELECT 2422, 14, 'Água Azul do Norte' FROM dual
 UNION ALL

 SELECT 2423, 14, 'Alenquer' FROM dual
 UNION ALL

 SELECT 2424, 14, 'Almeirim' FROM dual
 UNION ALL

 SELECT 2425, 14, 'Altamira' FROM dual
 UNION ALL

 SELECT 2426, 14, 'Anajás' FROM dual
 UNION ALL

 SELECT 2427, 14, 'Ananindeua' FROM dual
 UNION ALL

 SELECT 2428, 14, 'Anapu' FROM dual
 UNION ALL

 SELECT 2429, 14, 'Augusto Corrêa' FROM dual
 UNION ALL

 SELECT 2430, 14, 'Aurora do Pará' FROM dual
 UNION ALL

 SELECT 2431, 14, 'Aveiro' FROM dual
 UNION ALL

 SELECT 2432, 14, 'Bagre' FROM dual
 UNION ALL

 SELECT 2433, 14, 'Baião' FROM dual
 UNION ALL

 SELECT 2434, 14, 'Bannach' FROM dual
 UNION ALL

 SELECT 2435, 14, 'Barcarena' FROM dual
 UNION ALL

 SELECT 2436, 14, 'Belém' FROM dual
 UNION ALL

 SELECT 2437, 14, 'Belterra' FROM dual
 UNION ALL

 SELECT 2438, 14, 'Benevides' FROM dual
 UNION ALL

 SELECT 2439, 14, 'Bom Jesus do Tocantins' FROM dual
 UNION ALL

 SELECT 2440, 14, 'Bonito' FROM dual
 UNION ALL

 SELECT 2441, 14, 'Bragança' FROM dual
 UNION ALL

 SELECT 2442, 14, 'Brasil Novo' FROM dual
 UNION ALL

 SELECT 2443, 14, 'Brejo Grande do Araguaia' FROM dual
 UNION ALL

 SELECT 2444, 14, 'Breu Branco' FROM dual
 UNION ALL

 SELECT 2445, 14, 'Breves' FROM dual
 UNION ALL

 SELECT 2446, 14, 'Bujaru' FROM dual
 UNION ALL

 SELECT 2447, 14, 'Cachoeira do Arari' FROM dual
 UNION ALL

 SELECT 2448, 14, 'Cachoeira do Piriá' FROM dual
 UNION ALL

 SELECT 2449, 14, 'Cametá' FROM dual
 UNION ALL

 SELECT 2450, 14, 'Canaã dos Carajás' FROM dual
 UNION ALL

 SELECT 2451, 14, 'Capanema' FROM dual
 UNION ALL

 SELECT 2452, 14, 'Capitão Poço' FROM dual
 UNION ALL

 SELECT 2453, 14, 'Castanhal' FROM dual
 UNION ALL

 SELECT 2454, 14, 'Chaves' FROM dual
 UNION ALL

 SELECT 2455, 14, 'Colares' FROM dual
 UNION ALL

 SELECT 2456, 14, 'Conceição do Araguaia' FROM dual
 UNION ALL

 SELECT 2457, 14, 'Concórdia do Pará' FROM dual
 UNION ALL

 SELECT 2458, 14, 'Cumaru do Norte' FROM dual
 UNION ALL

 SELECT 2459, 14, 'Curionópolis' FROM dual
 UNION ALL

 SELECT 2460, 14, 'Curralinho' FROM dual
 UNION ALL

 SELECT 2461, 14, 'Curuá' FROM dual
 UNION ALL

 SELECT 2462, 14, 'Curuçá' FROM dual
 UNION ALL

 SELECT 2463, 14, 'Dom Eliseu' FROM dual
 UNION ALL

 SELECT 2464, 14, 'Eldorado dos Carajás' FROM dual
 UNION ALL

 SELECT 2465, 14, 'Faro' FROM dual
 UNION ALL

 SELECT 2466, 14, 'Floresta do Araguaia' FROM dual
 UNION ALL

 SELECT 2467, 14, 'Garrafão do Norte' FROM dual
 UNION ALL

 SELECT 2468, 14, 'Goianésia do Pará' FROM dual
 UNION ALL

 SELECT 2469, 14, 'Gurupá' FROM dual
 UNION ALL

 SELECT 2470, 14, 'Igarapé-Açu' FROM dual
 UNION ALL

 SELECT 2471, 14, 'Igarapé-Miri' FROM dual
 UNION ALL

 SELECT 2472, 14, 'Inhangapi' FROM dual
 UNION ALL

 SELECT 2473, 14, 'Ipixuna do Pará' FROM dual
 UNION ALL

 SELECT 2474, 14, 'Irituia' FROM dual
 UNION ALL

 SELECT 2475, 14, 'Itaituba' FROM dual
 UNION ALL

 SELECT 2476, 14, 'Itupiranga' FROM dual
 UNION ALL

 SELECT 2477, 14, 'Jacareacanga' FROM dual
 UNION ALL

 SELECT 2478, 14, 'Jacundá' FROM dual
 UNION ALL

 SELECT 2479, 14, 'Juruti' FROM dual
 UNION ALL

 SELECT 2480, 14, 'Limoeiro do Ajuru' FROM dual
 UNION ALL

 SELECT 2481, 14, 'Mãe do Rio' FROM dual
 UNION ALL

 SELECT 2482, 14, 'Magalhães Barata' FROM dual
 UNION ALL

 SELECT 2483, 14, 'Marabá' FROM dual
 UNION ALL

 SELECT 2484, 14, 'Maracanã' FROM dual
 UNION ALL

 SELECT 2485, 14, 'Marapanim' FROM dual
 UNION ALL

 SELECT 2486, 14, 'Marituba' FROM dual
 UNION ALL

 SELECT 2487, 14, 'Medicilândia' FROM dual
 UNION ALL

 SELECT 2488, 14, 'Melgaço' FROM dual
 UNION ALL

 SELECT 2489, 14, 'Mocajuba' FROM dual
 UNION ALL

 SELECT 2490, 14, 'Moju' FROM dual
 UNION ALL

 SELECT 2491, 14, 'Monte Alegre' FROM dual
 UNION ALL

 SELECT 2492, 14, 'Muaná' FROM dual
 UNION ALL

 SELECT 2493, 14, 'Nova Esperança do Piriá' FROM dual
 UNION ALL

 SELECT 2494, 14, 'Nova Ipixuna' FROM dual
 UNION ALL

 SELECT 2495, 14, 'Nova Timboteua' FROM dual
 UNION ALL

 SELECT 2496, 14, 'Novo Progresso' FROM dual
 UNION ALL

 SELECT 2497, 14, 'Novo Repartimento' FROM dual
 UNION ALL

 SELECT 2498, 14, 'Óbidos' FROM dual
 UNION ALL

 SELECT 2499, 14, 'Oeiras do Pará' FROM dual
 UNION ALL

 SELECT 2500, 14, 'Oriximiná' FROM dual
 UNION ALL

 SELECT 2501, 14, 'Ourém' FROM dual
 UNION ALL

 SELECT 2502, 14, 'Ourilândia do Norte' FROM dual
 UNION ALL

 SELECT 2503, 14, 'Pacajá' FROM dual
 UNION ALL

 SELECT 2504, 14, 'Palestina do Pará' FROM dual
 UNION ALL

 SELECT 2505, 14, 'Paragominas' FROM dual
 UNION ALL

 SELECT 2506, 14, 'Parauapebas' FROM dual
 UNION ALL

 SELECT 2507, 14, 'Pau d`Arco' FROM dual
 UNION ALL

 SELECT 2508, 14, 'Peixe-Boi' FROM dual
 UNION ALL

 SELECT 2509, 14, 'Piçarra' FROM dual
 UNION ALL

 SELECT 2510, 14, 'Placas' FROM dual
 UNION ALL

 SELECT 2511, 14, 'Ponta de Pedras' FROM dual
 UNION ALL

 SELECT 2512, 14, 'Portel' FROM dual
 UNION ALL

 SELECT 2513, 14, 'Porto de Moz' FROM dual
 UNION ALL

 SELECT 2514, 14, 'Prainha' FROM dual
 UNION ALL

 SELECT 2515, 14, 'Primavera' FROM dual
 UNION ALL

 SELECT 2516, 14, 'Quatipuru' FROM dual
 UNION ALL

 SELECT 2517, 14, 'Redenção' FROM dual
 UNION ALL

 SELECT 2518, 14, 'Rio Maria' FROM dual
 UNION ALL

 SELECT 2519, 14, 'Rondon do Pará' FROM dual
 UNION ALL

 SELECT 2520, 14, 'Rurópolis' FROM dual
 UNION ALL

 SELECT 2521, 14, 'Salinópolis' FROM dual
 UNION ALL

 SELECT 2522, 14, 'Salvaterra' FROM dual
 UNION ALL

 SELECT 2523, 14, 'Santa Bárbara do Pará' FROM dual
 UNION ALL

 SELECT 2524, 14, 'Santa Cruz do Arari' FROM dual
 UNION ALL

 SELECT 2525, 14, 'Santa Isabel do Pará' FROM dual
 UNION ALL

 SELECT 2526, 14, 'Santa Luzia do Pará' FROM dual
 UNION ALL

 SELECT 2527, 14, 'Santa Maria das Barreiras' FROM dual
 UNION ALL

 SELECT 2528, 14, 'Santa Maria do Pará' FROM dual
 UNION ALL

 SELECT 2529, 14, 'Santana do Araguaia' FROM dual
 UNION ALL

 SELECT 2530, 14, 'Santarém' FROM dual
 UNION ALL

 SELECT 2531, 14, 'Santarém Novo' FROM dual
 UNION ALL

 SELECT 2532, 14, 'Santo Antônio do Tauá' FROM dual
 UNION ALL

 SELECT 2533, 14, 'São Caetano de Odivelas' FROM dual
 UNION ALL

 SELECT 2534, 14, 'São Domingos do Araguaia' FROM dual
 UNION ALL

 SELECT 2535, 14, 'São Domingos do Capim' FROM dual
 UNION ALL

 SELECT 2536, 14, 'São Félix do Xingu' FROM dual
 UNION ALL

 SELECT 2537, 14, 'São Francisco do Pará' FROM dual
 UNION ALL

 SELECT 2538, 14, 'São Geraldo do Araguaia' FROM dual
 UNION ALL

 SELECT 2539, 14, 'São João da Ponta' FROM dual
 UNION ALL

 SELECT 2540, 14, 'São João de Pirabas' FROM dual
 UNION ALL

 SELECT 2541, 14, 'São João do Araguaia' FROM dual
 UNION ALL

 SELECT 2542, 14, 'São Miguel do Guamá' FROM dual
 UNION ALL

 SELECT 2543, 14, 'São Sebastião da Boa Vista' FROM dual
 UNION ALL

 SELECT 2544, 14, 'Sapucaia' FROM dual
 UNION ALL

 SELECT 2545, 14, 'Senador José Porfírio' FROM dual
 UNION ALL

 SELECT 2546, 14, 'Soure' FROM dual
 UNION ALL

 SELECT 2547, 14, 'Tailândia' FROM dual
 UNION ALL

 SELECT 2548, 14, 'Terra Alta' FROM dual
 UNION ALL

 SELECT 2549, 14, 'Terra Santa' FROM dual
 UNION ALL

 SELECT 2550, 14, 'Tomé-Açu' FROM dual
 UNION ALL

 SELECT 2551, 14, 'Tracuateua' FROM dual
 UNION ALL

 SELECT 2552, 14, 'Trairão' FROM dual
 UNION ALL

 SELECT 2553, 14, 'Tucumã' FROM dual
 UNION ALL

 SELECT 2554, 14, 'Tucuruí' FROM dual
 UNION ALL

 SELECT 2555, 14, 'Ulianópolis' FROM dual
 UNION ALL

 SELECT 2556, 14, 'Uruará' FROM dual
 UNION ALL

 SELECT 2557, 14, 'Vigia' FROM dual
 UNION ALL

 SELECT 2558, 14, 'Viseu' FROM dual
 UNION ALL

 SELECT 2559, 14, 'Vitória do Xingu' FROM dual
 UNION ALL

 SELECT 2560, 14, 'Xinguara' FROM dual
 UNION ALL

 SELECT 2561, 15, 'Água Branca' FROM dual
 UNION ALL

 SELECT 2562, 15, 'Aguiar' FROM dual
 UNION ALL

 SELECT 2563, 15, 'Alagoa Grande' FROM dual
 UNION ALL

 SELECT 2564, 15, 'Alagoa Nova' FROM dual
 UNION ALL

 SELECT 2565, 15, 'Alagoinha' FROM dual
 UNION ALL

 SELECT 2566, 15, 'Alcantil' FROM dual
 UNION ALL

 SELECT 2567, 15, 'Algodão de Jandaíra' FROM dual
 UNION ALL

 SELECT 2568, 15, 'Alhandra' FROM dual
 UNION ALL

 SELECT 2569, 15, 'Amparo' FROM dual
 UNION ALL

 SELECT 2570, 15, 'Aparecida' FROM dual
 UNION ALL

 SELECT 2571, 15, 'Araçagi' FROM dual
 UNION ALL

 SELECT 2572, 15, 'Arara' FROM dual
 UNION ALL

 SELECT 2573, 15, 'Araruna' FROM dual
 UNION ALL

 SELECT 2574, 15, 'Areia' FROM dual
 UNION ALL

 SELECT 2575, 15, 'Areia de Baraúnas' FROM dual
 UNION ALL

 SELECT 2576, 15, 'Areial' FROM dual
 UNION ALL

 SELECT 2577, 15, 'Aroeiras' FROM dual
 UNION ALL

 SELECT 2578, 15, 'Assunção' FROM dual
 UNION ALL

 SELECT 2579, 15, 'Baía da Traição' FROM dual
 UNION ALL

 SELECT 2580, 15, 'Bananeiras' FROM dual
 UNION ALL

 SELECT 2581, 15, 'Baraúna' FROM dual
 UNION ALL

 SELECT 2582, 15, 'Barra de Santa Rosa' FROM dual
 UNION ALL

 SELECT 2583, 15, 'Barra de Santana' FROM dual
 UNION ALL

 SELECT 2584, 15, 'Barra de São Miguel' FROM dual
 UNION ALL

 SELECT 2585, 15, 'Bayeux' FROM dual
 UNION ALL

 SELECT 2586, 15, 'Belém' FROM dual
 UNION ALL

 SELECT 2587, 15, 'Belém do Brejo do Cruz' FROM dual
 UNION ALL

 SELECT 2588, 15, 'Bernardino Batista' FROM dual
 UNION ALL

 SELECT 2589, 15, 'Boa Ventura' FROM dual
 UNION ALL

 SELECT 2590, 15, 'Boa Vista' FROM dual
 UNION ALL

 SELECT 2591, 15, 'Bom Jesus' FROM dual
 UNION ALL

 SELECT 2592, 15, 'Bom Sucesso' FROM dual
 UNION ALL

 SELECT 2593, 15, 'Bonito de Santa Fé' FROM dual
 UNION ALL

 SELECT 2594, 15, 'Boqueirão' FROM dual
 UNION ALL

 SELECT 2595, 15, 'Borborema' FROM dual
 UNION ALL

 SELECT 2596, 15, 'Brejo do Cruz' FROM dual
 UNION ALL

 SELECT 2597, 15, 'Brejo dos Santos' FROM dual
 UNION ALL

 SELECT 2598, 15, 'Caaporã' FROM dual
 UNION ALL

 SELECT 2599, 15, 'Cabaceiras' FROM dual
 UNION ALL

 SELECT 2600, 15, 'Cabedelo' FROM dual
 UNION ALL

 SELECT 2601, 15, 'Cachoeira dos Índios' FROM dual
 UNION ALL

 SELECT 2602, 15, 'Cacimba de Areia' FROM dual
 UNION ALL

 SELECT 2603, 15, 'Cacimba de Dentro' FROM dual
 UNION ALL

 SELECT 2604, 15, 'Cacimbas' FROM dual
 UNION ALL

 SELECT 2605, 15, 'Caiçara' FROM dual
 UNION ALL

 SELECT 2606, 15, 'Cajazeiras' FROM dual
 UNION ALL

 SELECT 2607, 15, 'Cajazeirinhas' FROM dual
 UNION ALL

 SELECT 2608, 15, 'Caldas Brandão' FROM dual
 UNION ALL

 SELECT 2609, 15, 'Camalaú' FROM dual
 UNION ALL

 SELECT 2610, 15, 'Campina Grande' FROM dual
 UNION ALL

 SELECT 2611, 15, 'Campo de Santana' FROM dual
 UNION ALL

 SELECT 2612, 15, 'Capim' FROM dual
 UNION ALL

 SELECT 2613, 15, 'Caraúbas' FROM dual
 UNION ALL

 SELECT 2614, 15, 'Carrapateira' FROM dual
 UNION ALL

 SELECT 2615, 15, 'Casserengue' FROM dual
 UNION ALL

 SELECT 2616, 15, 'Catingueira' FROM dual
 UNION ALL

 SELECT 2617, 15, 'Catolé do Rocha' FROM dual
 UNION ALL

 SELECT 2618, 15, 'Caturité' FROM dual
 UNION ALL

 SELECT 2619, 15, 'Conceição' FROM dual
 UNION ALL

 SELECT 2620, 15, 'Condado' FROM dual
 UNION ALL

 SELECT 2621, 15, 'Conde' FROM dual
 UNION ALL

 SELECT 2622, 15, 'Congo' FROM dual
 UNION ALL

 SELECT 2623, 15, 'Coremas' FROM dual
 UNION ALL

 SELECT 2624, 15, 'Coxixola' FROM dual
 UNION ALL

 SELECT 2625, 15, 'Cruz do Espírito Santo' FROM dual
 UNION ALL

 SELECT 2626, 15, 'Cubati' FROM dual
 UNION ALL

 SELECT 2627, 15, 'Cuité' FROM dual
 UNION ALL

 SELECT 2628, 15, 'Cuité de Mamanguape' FROM dual
 UNION ALL

 SELECT 2629, 15, 'Cuitegi' FROM dual
 UNION ALL

 SELECT 2630, 15, 'Curral de Cima' FROM dual
 UNION ALL

 SELECT 2631, 15, 'Curral Velho' FROM dual
 UNION ALL

 SELECT 2632, 15, 'Damião' FROM dual
 UNION ALL

 SELECT 2633, 15, 'Desterro' FROM dual
 UNION ALL

 SELECT 2634, 15, 'Diamante' FROM dual
 UNION ALL

 SELECT 2635, 15, 'Dona Inês' FROM dual
 UNION ALL

 SELECT 2636, 15, 'Duas Estradas' FROM dual
 UNION ALL

 SELECT 2637, 15, 'Emas' FROM dual
 UNION ALL

 SELECT 2638, 15, 'Esperança' FROM dual
 UNION ALL

 SELECT 2639, 15, 'Fagundes' FROM dual
 UNION ALL

 SELECT 2640, 15, 'Frei Martinho' FROM dual
 UNION ALL

 SELECT 2641, 15, 'Gado Bravo' FROM dual
 UNION ALL

 SELECT 2642, 15, 'Guarabira' FROM dual
 UNION ALL

 SELECT 2643, 15, 'Gurinhém' FROM dual
 UNION ALL

 SELECT 2644, 15, 'Gurjão' FROM dual
 UNION ALL

 SELECT 2645, 15, 'Ibiara' FROM dual
 UNION ALL

 SELECT 2646, 15, 'Igaracy' FROM dual
 UNION ALL

 SELECT 2647, 15, 'Imaculada' FROM dual
 UNION ALL

 SELECT 2648, 15, 'Ingá' FROM dual
 UNION ALL

 SELECT 2649, 15, 'Itabaiana' FROM dual
 UNION ALL

 SELECT 2650, 15, 'Itaporanga' FROM dual
 UNION ALL

 SELECT 2651, 15, 'Itapororoca' FROM dual
 UNION ALL

 SELECT 2652, 15, 'Itatuba' FROM dual
 UNION ALL

 SELECT 2653, 15, 'Jacaraú' FROM dual
 UNION ALL

 SELECT 2654, 15, 'Jericó' FROM dual
 UNION ALL

 SELECT 2655, 15, 'João Pessoa' FROM dual
 UNION ALL

 SELECT 2656, 15, 'Juarez Távora' FROM dual
 UNION ALL

 SELECT 2657, 15, 'Juazeirinho' FROM dual
 UNION ALL

 SELECT 2658, 15, 'Junco do Seridó' FROM dual
 UNION ALL

 SELECT 2659, 15, 'Juripiranga' FROM dual
 UNION ALL

 SELECT 2660, 15, 'Juru' FROM dual
 UNION ALL

 SELECT 2661, 15, 'Lagoa' FROM dual
 UNION ALL

 SELECT 2662, 15, 'Lagoa de Dentro' FROM dual
 UNION ALL

 SELECT 2663, 15, 'Lagoa Seca' FROM dual
 UNION ALL

 SELECT 2664, 15, 'Lastro' FROM dual
 UNION ALL

 SELECT 2665, 15, 'Livramento' FROM dual
 UNION ALL

 SELECT 2666, 15, 'Logradouro' FROM dual
 UNION ALL

 SELECT 2667, 15, 'Lucena' FROM dual
 UNION ALL

 SELECT 2668, 15, 'Mãe d`Água' FROM dual
 UNION ALL

 SELECT 2669, 15, 'Malta' FROM dual
 UNION ALL

 SELECT 2670, 15, 'Mamanguape' FROM dual
 UNION ALL

 SELECT 2671, 15, 'Manaíra' FROM dual
 UNION ALL

 SELECT 2672, 15, 'Marcação' FROM dual
 UNION ALL

 SELECT 2673, 15, 'Mari' FROM dual
 UNION ALL

 SELECT 2674, 15, 'Marizópolis' FROM dual
 UNION ALL

 SELECT 2675, 15, 'Massaranduba' FROM dual
 UNION ALL

 SELECT 2676, 15, 'Mataraca' FROM dual
 UNION ALL

 SELECT 2677, 15, 'Matinhas' FROM dual
 UNION ALL

 SELECT 2678, 15, 'Mato Grosso' FROM dual
 UNION ALL

 SELECT 2679, 15, 'Maturéia' FROM dual
 UNION ALL

 SELECT 2680, 15, 'Mogeiro' FROM dual
 UNION ALL

 SELECT 2681, 15, 'Montadas' FROM dual
 UNION ALL

 SELECT 2682, 15, 'Monte Horebe' FROM dual
 UNION ALL

 SELECT 2683, 15, 'Monteiro' FROM dual
 UNION ALL

 SELECT 2684, 15, 'Mulungu' FROM dual
 UNION ALL

 SELECT 2685, 15, 'Natuba' FROM dual
 UNION ALL

 SELECT 2686, 15, 'Nazarezinho' FROM dual
 UNION ALL

 SELECT 2687, 15, 'Nova Floresta' FROM dual
 UNION ALL

 SELECT 2688, 15, 'Nova Olinda' FROM dual
 UNION ALL

 SELECT 2689, 15, 'Nova Palmeira' FROM dual
 UNION ALL

 SELECT 2690, 15, 'Olho d`Água' FROM dual
 UNION ALL

 SELECT 2691, 15, 'Olivedos' FROM dual
 UNION ALL

 SELECT 2692, 15, 'Ouro Velho' FROM dual
 UNION ALL

 SELECT 2693, 15, 'Parari' FROM dual
 UNION ALL

 SELECT 2694, 15, 'Passagem' FROM dual
 UNION ALL

 SELECT 2695, 15, 'Patos' FROM dual
 UNION ALL

 SELECT 2696, 15, 'Paulista' FROM dual
 UNION ALL

 SELECT 2697, 15, 'Pedra Branca' FROM dual
 UNION ALL

 SELECT 2698, 15, 'Pedra Lavrada' FROM dual
 UNION ALL

 SELECT 2699, 15, 'Pedras de Fogo' FROM dual
 UNION ALL

 SELECT 2700, 15, 'Pedro Régis' FROM dual
 UNION ALL

 SELECT 2701, 15, 'Piancó' FROM dual
 UNION ALL

 SELECT 2702, 15, 'Picuí' FROM dual
 UNION ALL

 SELECT 2703, 15, 'Pilar' FROM dual
 UNION ALL

 SELECT 2704, 15, 'Pilões' FROM dual
 UNION ALL

 SELECT 2705, 15, 'Pilõezinhos' FROM dual
 UNION ALL

 SELECT 2706, 15, 'Pirpirituba' FROM dual
 UNION ALL

 SELECT 2707, 15, 'Pitimbu' FROM dual
 UNION ALL

 SELECT 2708, 15, 'Pocinhos' FROM dual
 UNION ALL

 SELECT 2709, 15, 'Poço Dantas' FROM dual
 UNION ALL

 SELECT 2710, 15, 'Poço de José de Moura' FROM dual
 UNION ALL

 SELECT 2711, 15, 'Pombal' FROM dual
 UNION ALL

 SELECT 2712, 15, 'Prata' FROM dual
 UNION ALL

 SELECT 2713, 15, 'Princesa Isabel' FROM dual
 UNION ALL

 SELECT 2714, 15, 'Puxinanã' FROM dual
 UNION ALL

 SELECT 2715, 15, 'Queimadas' FROM dual
 UNION ALL

 SELECT 2716, 15, 'Quixabá' FROM dual
 UNION ALL

 SELECT 2717, 15, 'Remígio' FROM dual
 UNION ALL

 SELECT 2718, 15, 'Riachão' FROM dual
 UNION ALL

 SELECT 2719, 15, 'Riachão do Bacamarte' FROM dual
 UNION ALL

 SELECT 2720, 15, 'Riachão do Poço' FROM dual
 UNION ALL

 SELECT 2721, 15, 'Riacho de Santo Antônio' FROM dual
 UNION ALL

 SELECT 2722, 15, 'Riacho dos Cavalos' FROM dual
 UNION ALL

 SELECT 2723, 15, 'Rio Tinto' FROM dual
 UNION ALL

 SELECT 2724, 15, 'Salgadinho' FROM dual
 UNION ALL

 SELECT 2725, 15, 'Salgado de São Félix' FROM dual
 UNION ALL

 SELECT 2726, 15, 'Santa Cecília' FROM dual
 UNION ALL

 SELECT 2727, 15, 'Santa Cruz' FROM dual
 UNION ALL

 SELECT 2728, 15, 'Santa Helena' FROM dual
 UNION ALL

 SELECT 2729, 15, 'Santa Inês' FROM dual
 UNION ALL

 SELECT 2730, 15, 'Santa Luzia' FROM dual
 UNION ALL

 SELECT 2731, 15, 'Santa Rita' FROM dual
 UNION ALL

 SELECT 2732, 15, 'Santa Teresinha' FROM dual
 UNION ALL

 SELECT 2733, 15, 'Santana de Mangueira' FROM dual
 UNION ALL

 SELECT 2734, 15, 'Santana dos Garrotes' FROM dual
 UNION ALL

 SELECT 2735, 15, 'Santarém' FROM dual
 UNION ALL

 SELECT 2736, 15, 'Santo André' FROM dual
 UNION ALL

 SELECT 2737, 15, 'São Bentinho' FROM dual
 UNION ALL

 SELECT 2738, 15, 'São Bento' FROM dual
 UNION ALL

 SELECT 2739, 15, 'São Domingos de Pombal' FROM dual
 UNION ALL

 SELECT 2740, 15, 'São Domingos do Cariri' FROM dual
 UNION ALL

 SELECT 2741, 15, 'São Francisco' FROM dual
 UNION ALL

 SELECT 2742, 15, 'São João do Cariri' FROM dual
 UNION ALL

 SELECT 2743, 15, 'São João do Rio do Peixe' FROM dual
 UNION ALL

 SELECT 2744, 15, 'São João do Tigre' FROM dual
 UNION ALL

 SELECT 2745, 15, 'São José da Lagoa Tapada' FROM dual
 UNION ALL

 SELECT 2746, 15, 'São José de Caiana' FROM dual
 UNION ALL

 SELECT 2747, 15, 'São José de Espinharas' FROM dual
 UNION ALL

 SELECT 2748, 15, 'São José de Piranhas' FROM dual
 UNION ALL

 SELECT 2749, 15, 'São José de Princesa' FROM dual
 UNION ALL

 SELECT 2750, 15, 'São José do Bonfim' FROM dual
 UNION ALL

 SELECT 2751, 15, 'São José do Brejo do Cruz' FROM dual
 UNION ALL

 SELECT 2752, 15, 'São José do Sabugi' FROM dual
 UNION ALL

 SELECT 2753, 15, 'São José dos Cordeiros' FROM dual
 UNION ALL

 SELECT 2754, 15, 'São José dos Ramos' FROM dual
 UNION ALL

 SELECT 2755, 15, 'São Mamede' FROM dual
 UNION ALL

 SELECT 2756, 15, 'São Miguel de Taipu' FROM dual
 UNION ALL

 SELECT 2757, 15, 'São Sebastião de Lagoa de Roça' FROM dual
 UNION ALL

 SELECT 2758, 15, 'São Sebastião do Umbuzeiro' FROM dual
 UNION ALL

 SELECT 2759, 15, 'Sapé' FROM dual
 UNION ALL

 SELECT 2760, 15, 'Seridó' FROM dual
 UNION ALL

 SELECT 2761, 15, 'Serra Branca' FROM dual
 UNION ALL

 SELECT 2762, 15, 'Serra da Raiz' FROM dual
 UNION ALL

 SELECT 2763, 15, 'Serra Grande' FROM dual
 UNION ALL

 SELECT 2764, 15, 'Serra Redonda' FROM dual
 UNION ALL

 SELECT 2765, 15, 'Serraria' FROM dual
 UNION ALL

 SELECT 2766, 15, 'Sertãozinho' FROM dual
 UNION ALL

 SELECT 2767, 15, 'Sobrado' FROM dual
 UNION ALL

 SELECT 2768, 15, 'Solânea' FROM dual
 UNION ALL

 SELECT 2769, 15, 'Soledade' FROM dual
 UNION ALL

 SELECT 2770, 15, 'Sossêgo' FROM dual
 UNION ALL

 SELECT 2771, 15, 'Sousa' FROM dual
 UNION ALL

 SELECT 2772, 15, 'Sumé' FROM dual
 UNION ALL

 SELECT 2773, 15, 'Taperoá' FROM dual
 UNION ALL

 SELECT 2774, 15, 'Tavares' FROM dual
 UNION ALL

 SELECT 2775, 15, 'Teixeira' FROM dual
 UNION ALL

 SELECT 2776, 15, 'Tenório' FROM dual
 UNION ALL

 SELECT 2777, 15, 'Triunfo' FROM dual
 UNION ALL

 SELECT 2778, 15, 'Uiraúna' FROM dual
 UNION ALL

 SELECT 2779, 15, 'Umbuzeiro' FROM dual
 UNION ALL

 SELECT 2780, 15, 'Várzea' FROM dual
 UNION ALL

 SELECT 2781, 15, 'Vieirópolis' FROM dual
 UNION ALL

 SELECT 2782, 15, 'Vista Serrana' FROM dual
 UNION ALL

 SELECT 2783, 15, 'Zabelê' FROM dual
 UNION ALL

 SELECT 2784, 18, 'Abatiá' FROM dual
 UNION ALL

 SELECT 2785, 18, 'Adrianópolis' FROM dual
 UNION ALL

 SELECT 2786, 18, 'Agudos do Sul' FROM dual
 UNION ALL

 SELECT 2787, 18, 'Almirante Tamandaré' FROM dual
 UNION ALL

 SELECT 2788, 18, 'Altamira do Paraná' FROM dual
 UNION ALL

 SELECT 2789, 18, 'Alto Paraíso' FROM dual
 UNION ALL

 SELECT 2790, 18, 'Alto Paraná' FROM dual
 UNION ALL

 SELECT 2791, 18, 'Alto Piquiri' FROM dual
 UNION ALL

 SELECT 2792, 18, 'Altônia' FROM dual
 UNION ALL

 SELECT 2793, 18, 'Alvorada do Sul' FROM dual
 UNION ALL

 SELECT 2794, 18, 'Amaporã' FROM dual
 UNION ALL

 SELECT 2795, 18, 'Ampére' FROM dual
 UNION ALL

 SELECT 2796, 18, 'Anahy' FROM dual
 UNION ALL

 SELECT 2797, 18, 'Andirá' FROM dual
 UNION ALL

 SELECT 2798, 18, 'Ângulo' FROM dual
 UNION ALL

 SELECT 2799, 18, 'Antonina' FROM dual
 UNION ALL

 SELECT 2800, 18, 'Antônio Olinto' FROM dual
 UNION ALL

 SELECT 2801, 18, 'Apucarana' FROM dual
 UNION ALL

 SELECT 2802, 18, 'Arapongas' FROM dual
 UNION ALL

 SELECT 2803, 18, 'Arapoti' FROM dual
 UNION ALL

 SELECT 2804, 18, 'Arapuã' FROM dual
 UNION ALL

 SELECT 2805, 18, 'Araruna' FROM dual
 UNION ALL

 SELECT 2806, 18, 'Araucária' FROM dual
 UNION ALL

 SELECT 2807, 18, 'Ariranha do Ivaí' FROM dual
 UNION ALL

 SELECT 2808, 18, 'Assaí' FROM dual
 UNION ALL

 SELECT 2809, 18, 'Assis Chateaubriand' FROM dual
 UNION ALL

 SELECT 2810, 18, 'Astorga' FROM dual
 UNION ALL

 SELECT 2811, 18, 'Atalaia' FROM dual
 UNION ALL

 SELECT 2812, 18, 'Balsa Nova' FROM dual
 UNION ALL

 SELECT 2813, 18, 'Bandeirantes' FROM dual
 UNION ALL

 SELECT 2814, 18, 'Barbosa Ferraz' FROM dual
 UNION ALL

 SELECT 2815, 18, 'Barra do Jacaré' FROM dual
 UNION ALL

 SELECT 2816, 18, 'Barracão' FROM dual
 UNION ALL

 SELECT 2817, 18, 'Bela Vista da Caroba' FROM dual
 UNION ALL

 SELECT 2818, 18, 'Bela Vista do Paraíso' FROM dual
 UNION ALL

 SELECT 2819, 18, 'Bituruna' FROM dual
 UNION ALL

 SELECT 2820, 18, 'Boa Esperança' FROM dual
 UNION ALL

 SELECT 2821, 18, 'Boa Esperança do Iguaçu' FROM dual
 UNION ALL

 SELECT 2822, 18, 'Boa Ventura de São Roque' FROM dual
 UNION ALL

 SELECT 2823, 18, 'Boa Vista da Aparecida' FROM dual
 UNION ALL

 SELECT 2824, 18, 'Bocaiúva do Sul' FROM dual
 UNION ALL

 SELECT 2825, 18, 'Bom Jesus do Sul' FROM dual
 UNION ALL

 SELECT 2826, 18, 'Bom Sucesso' FROM dual
 UNION ALL

 SELECT 2827, 18, 'Bom Sucesso do Sul' FROM dual
 UNION ALL

 SELECT 2828, 18, 'Borrazópolis' FROM dual
 UNION ALL

 SELECT 2829, 18, 'Braganey' FROM dual
 UNION ALL

 SELECT 2830, 18, 'Brasilândia do Sul' FROM dual
 UNION ALL

 SELECT 2831, 18, 'Cafeara' FROM dual
 UNION ALL

 SELECT 2832, 18, 'Cafelândia' FROM dual
 UNION ALL

 SELECT 2833, 18, 'Cafezal do Sul' FROM dual
 UNION ALL

 SELECT 2834, 18, 'Califórnia' FROM dual
 UNION ALL

 SELECT 2835, 18, 'Cambará' FROM dual
 UNION ALL

 SELECT 2836, 18, 'Cambé' FROM dual
 UNION ALL

 SELECT 2837, 18, 'Cambira' FROM dual
 UNION ALL

 SELECT 2838, 18, 'Campina da Lagoa' FROM dual
 UNION ALL

 SELECT 2839, 18, 'Campina do Simão' FROM dual
 UNION ALL

 SELECT 2840, 18, 'Campina Grande do Sul' FROM dual
 UNION ALL

 SELECT 2841, 18, 'Campo Bonito' FROM dual
 UNION ALL

 SELECT 2842, 18, 'Campo do Tenente' FROM dual
 UNION ALL

 SELECT 2843, 18, 'Campo Largo' FROM dual
 UNION ALL

 SELECT 2844, 18, 'Campo Magro' FROM dual
 UNION ALL

 SELECT 2845, 18, 'Campo Mourão' FROM dual
 UNION ALL

 SELECT 2846, 18, 'Cândido de Abreu' FROM dual
 UNION ALL

 SELECT 2847, 18, 'Candói' FROM dual
 UNION ALL

 SELECT 2848, 18, 'Cantagalo' FROM dual
 UNION ALL

 SELECT 2849, 18, 'Capanema' FROM dual
 UNION ALL

 SELECT 2850, 18, 'Capitão Leônidas Marques' FROM dual
 UNION ALL

 SELECT 2851, 18, 'Carambeí' FROM dual
 UNION ALL

 SELECT 2852, 18, 'Carlópolis' FROM dual
 UNION ALL

 SELECT 2853, 18, 'Cascavel' FROM dual
 UNION ALL

 SELECT 2854, 18, 'Castro' FROM dual
 UNION ALL

 SELECT 2855, 18, 'Catanduvas' FROM dual
 UNION ALL

 SELECT 2856, 18, 'Centenário do Sul' FROM dual
 UNION ALL

 SELECT 2857, 18, 'Cerro Azul' FROM dual
 UNION ALL

 SELECT 2858, 18, 'Céu Azul' FROM dual
 UNION ALL

 SELECT 2859, 18, 'Chopinzinho' FROM dual
 UNION ALL

 SELECT 2860, 18, 'Cianorte' FROM dual
 UNION ALL

 SELECT 2861, 18, 'Cidade Gaúcha' FROM dual
 UNION ALL

 SELECT 2862, 18, 'Clevelândia' FROM dual
 UNION ALL

 SELECT 2863, 18, 'Colombo' FROM dual
 UNION ALL

 SELECT 2864, 18, 'Colorado' FROM dual
 UNION ALL

 SELECT 2865, 18, 'Congonhinhas' FROM dual
 UNION ALL

 SELECT 2866, 18, 'Conselheiro Mairinck' FROM dual
 UNION ALL

 SELECT 2867, 18, 'Contenda' FROM dual
 UNION ALL

 SELECT 2868, 18, 'Corbélia' FROM dual
 UNION ALL

 SELECT 2869, 18, 'Cornélio Procópio' FROM dual
 UNION ALL

 SELECT 2870, 18, 'Coronel Domingos Soares' FROM dual
 UNION ALL

 SELECT 2871, 18, 'Coronel Vivida' FROM dual
 UNION ALL

 SELECT 2872, 18, 'Corumbataí do Sul' FROM dual
 UNION ALL

 SELECT 2873, 18, 'Cruz Machado' FROM dual
 UNION ALL

 SELECT 2874, 18, 'Cruzeiro do Iguaçu' FROM dual
 UNION ALL

 SELECT 2875, 18, 'Cruzeiro do Oeste' FROM dual
 UNION ALL

 SELECT 2876, 18, 'Cruzeiro do Sul' FROM dual
 UNION ALL

 SELECT 2877, 18, 'Cruzmaltina' FROM dual
 UNION ALL

 SELECT 2878, 18, 'Curitiba' FROM dual
 UNION ALL

 SELECT 2879, 18, 'Curiúva' FROM dual
 UNION ALL

 SELECT 2880, 18, 'Diamante d`Oeste' FROM dual
 UNION ALL

 SELECT 2881, 18, 'Diamante do Norte' FROM dual
 UNION ALL

 SELECT 2882, 18, 'Diamante do Sul' FROM dual
 UNION ALL

 SELECT 2883, 18, 'Dois Vizinhos' FROM dual
 UNION ALL

 SELECT 2884, 18, 'Douradina' FROM dual
 UNION ALL

 SELECT 2885, 18, 'Doutor Camargo' FROM dual
 UNION ALL

 SELECT 2886, 18, 'Doutor Ulysses' FROM dual
 UNION ALL

 SELECT 2887, 18, 'Enéas Marques' FROM dual
 UNION ALL

 SELECT 2888, 18, 'Engenheiro Beltrão' FROM dual
 UNION ALL

 SELECT 2889, 18, 'Entre Rios do Oeste' FROM dual
 UNION ALL

 SELECT 2890, 18, 'Esperança Nova' FROM dual
 UNION ALL

 SELECT 2891, 18, 'Espigão Alto do Iguaçu' FROM dual
 UNION ALL

 SELECT 2892, 18, 'Farol' FROM dual
 UNION ALL

 SELECT 2893, 18, 'Faxinal' FROM dual
 UNION ALL

 SELECT 2894, 18, 'Fazenda Rio Grande' FROM dual
 UNION ALL

 SELECT 2895, 18, 'Fênix' FROM dual
 UNION ALL

 SELECT 2896, 18, 'Fernandes Pinheiro' FROM dual
 UNION ALL

 SELECT 2897, 18, 'Figueira' FROM dual
 UNION ALL

 SELECT 2898, 18, 'Flor da Serra do Sul' FROM dual
 UNION ALL

 SELECT 2899, 18, 'Floraí' FROM dual
 UNION ALL

 SELECT 2900, 18, 'Floresta' FROM dual
 UNION ALL

 SELECT 2901, 18, 'Florestópolis' FROM dual
 UNION ALL

 SELECT 2902, 18, 'Flórida' FROM dual
 UNION ALL

 SELECT 2903, 18, 'Formosa do Oeste' FROM dual
 UNION ALL

 SELECT 2904, 18, 'Foz do Iguaçu' FROM dual
 UNION ALL

 SELECT 2905, 18, 'Foz do Jordão' FROM dual
 UNION ALL

 SELECT 2906, 18, 'Francisco Alves' FROM dual
 UNION ALL

 SELECT 2907, 18, 'Francisco Beltrão' FROM dual
 UNION ALL

 SELECT 2908, 18, 'General Carneiro' FROM dual
 UNION ALL

 SELECT 2909, 18, 'Godoy Moreira' FROM dual
 UNION ALL

 SELECT 2910, 18, 'Goioerê' FROM dual
 UNION ALL

 SELECT 2911, 18, 'Goioxim' FROM dual
 UNION ALL

 SELECT 2912, 18, 'Grandes Rios' FROM dual
 UNION ALL

 SELECT 2913, 18, 'Guaíra' FROM dual
 UNION ALL

 SELECT 2914, 18, 'Guairaçá' FROM dual
 UNION ALL

 SELECT 2915, 18, 'Guamiranga' FROM dual
 UNION ALL

 SELECT 2916, 18, 'Guapirama' FROM dual
 UNION ALL

 SELECT 2917, 18, 'Guaporema' FROM dual
 UNION ALL

 SELECT 2918, 18, 'Guaraci' FROM dual
 UNION ALL

 SELECT 2919, 18, 'Guaraniaçu' FROM dual
 UNION ALL

 SELECT 2920, 18, 'Guarapuava' FROM dual
 UNION ALL

 SELECT 2921, 18, 'Guaraqueçaba' FROM dual
 UNION ALL

 SELECT 2922, 18, 'Guaratuba' FROM dual
 UNION ALL

 SELECT 2923, 18, 'Honório Serpa' FROM dual
 UNION ALL

 SELECT 2924, 18, 'Ibaiti' FROM dual
 UNION ALL

 SELECT 2925, 18, 'Ibema' FROM dual
 UNION ALL

 SELECT 2926, 18, 'Ibiporã' FROM dual
 UNION ALL

 SELECT 2927, 18, 'Icaraíma' FROM dual
 UNION ALL

 SELECT 2928, 18, 'Iguaraçu' FROM dual
 UNION ALL

 SELECT 2929, 18, 'Iguatu' FROM dual
 UNION ALL

 SELECT 2930, 18, 'Imbaú' FROM dual
 UNION ALL

 SELECT 2931, 18, 'Imbituva' FROM dual
 UNION ALL

 SELECT 2932, 18, 'Inácio Martins' FROM dual
 UNION ALL

 SELECT 2933, 18, 'Inajá' FROM dual
 UNION ALL

 SELECT 2934, 18, 'Indianópolis' FROM dual
 UNION ALL

 SELECT 2935, 18, 'Ipiranga' FROM dual
 UNION ALL

 SELECT 2936, 18, 'Iporã' FROM dual
 UNION ALL

 SELECT 2937, 18, 'Iracema do Oeste' FROM dual
 UNION ALL

 SELECT 2938, 18, 'Irati' FROM dual
 UNION ALL

 SELECT 2939, 18, 'Iretama' FROM dual
 UNION ALL

 SELECT 2940, 18, 'Itaguajé' FROM dual
 UNION ALL

 SELECT 2941, 18, 'Itaipulândia' FROM dual
 UNION ALL

 SELECT 2942, 18, 'Itambaracá' FROM dual
 UNION ALL

 SELECT 2943, 18, 'Itambé' FROM dual
 UNION ALL

 SELECT 2944, 18, 'Itapejara d`Oeste' FROM dual
 UNION ALL

 SELECT 2945, 18, 'Itaperuçu' FROM dual
 UNION ALL

 SELECT 2946, 18, 'Itaúna do Sul' FROM dual
 UNION ALL

 SELECT 2947, 18, 'Ivaí' FROM dual
 UNION ALL

 SELECT 2948, 18, 'Ivaiporã' FROM dual
 UNION ALL

 SELECT 2949, 18, 'Ivaté' FROM dual
 UNION ALL

 SELECT 2950, 18, 'Ivatuba' FROM dual
 UNION ALL

 SELECT 2951, 18, 'Jaboti' FROM dual
 UNION ALL

 SELECT 2952, 18, 'Jacarezinho' FROM dual
 UNION ALL

 SELECT 2953, 18, 'Jaguapitã' FROM dual
 UNION ALL

 SELECT 2954, 18, 'Jaguariaíva' FROM dual
 UNION ALL

 SELECT 2955, 18, 'Jandaia do Sul' FROM dual
 UNION ALL

 SELECT 2956, 18, 'Janiópolis' FROM dual
 UNION ALL

 SELECT 2957, 18, 'Japira' FROM dual
 UNION ALL

 SELECT 2958, 18, 'Japurá' FROM dual
 UNION ALL

 SELECT 2959, 18, 'Jardim Alegre' FROM dual
 UNION ALL

 SELECT 2960, 18, 'Jardim Olinda' FROM dual
 UNION ALL

 SELECT 2961, 18, 'Jataizinho' FROM dual
 UNION ALL

 SELECT 2962, 18, 'Jesuítas' FROM dual
 UNION ALL

 SELECT 2963, 18, 'Joaquim Távora' FROM dual
 UNION ALL

 SELECT 2964, 18, 'Jundiaí do Sul' FROM dual
 UNION ALL

 SELECT 2965, 18, 'Juranda' FROM dual
 UNION ALL

 SELECT 2966, 18, 'Jussara' FROM dual
 UNION ALL

 SELECT 2967, 18, 'Kaloré' FROM dual
 UNION ALL

 SELECT 2968, 18, 'Lapa' FROM dual
 UNION ALL

 SELECT 2969, 18, 'Laranjal' FROM dual
 UNION ALL

 SELECT 2970, 18, 'Laranjeiras do Sul' FROM dual
 UNION ALL

 SELECT 2971, 18, 'Leópolis' FROM dual
 UNION ALL

 SELECT 2972, 18, 'Lidianópolis' FROM dual
 UNION ALL

 SELECT 2973, 18, 'Lindoeste' FROM dual
 UNION ALL

 SELECT 2974, 18, 'Loanda' FROM dual
 UNION ALL

 SELECT 2975, 18, 'Lobato' FROM dual
 UNION ALL

 SELECT 2976, 18, 'Londrina' FROM dual
 UNION ALL

 SELECT 2977, 18, 'Luiziana' FROM dual
 UNION ALL

 SELECT 2978, 18, 'Lunardelli' FROM dual
 UNION ALL

 SELECT 2979, 18, 'Lupionópolis' FROM dual
 UNION ALL

 SELECT 2980, 18, 'Mallet' FROM dual
 UNION ALL

 SELECT 2981, 18, 'Mamborê' FROM dual
 UNION ALL

 SELECT 2982, 18, 'Mandaguaçu' FROM dual
 UNION ALL

 SELECT 2983, 18, 'Mandaguari' FROM dual
 UNION ALL

 SELECT 2984, 18, 'Mandirituba' FROM dual
 UNION ALL

 SELECT 2985, 18, 'Manfrinópolis' FROM dual
 UNION ALL

 SELECT 2986, 18, 'Mangueirinha' FROM dual
 UNION ALL

 SELECT 2987, 18, 'Manoel Ribas' FROM dual
 UNION ALL

 SELECT 2988, 18, 'Marechal Cândido Rondon' FROM dual
 UNION ALL

 SELECT 2989, 18, 'Maria Helena' FROM dual
 UNION ALL

 SELECT 2990, 18, 'Marialva' FROM dual
 UNION ALL

 SELECT 2991, 18, 'Marilândia do Sul' FROM dual
 UNION ALL

 SELECT 2992, 18, 'Marilena' FROM dual
 UNION ALL

 SELECT 2993, 18, 'Mariluz' FROM dual
 UNION ALL

 SELECT 2994, 18, 'Maringá' FROM dual
 UNION ALL

 SELECT 2995, 18, 'Mariópolis' FROM dual
 UNION ALL

 SELECT 2996, 18, 'Maripá' FROM dual
 UNION ALL

 SELECT 2997, 18, 'Marmeleiro' FROM dual
 UNION ALL

 SELECT 2998, 18, 'Marquinho' FROM dual
 UNION ALL

 SELECT 2999, 18, 'Marumbi' FROM dual
 UNION ALL

 SELECT 3000, 18, 'Matelândia' FROM dual
 UNION ALL

 SELECT 3001, 18, 'Matinhos' FROM dual
 UNION ALL

 SELECT 3002, 18, 'Mato Rico' FROM dual
 UNION ALL

 SELECT 3003, 18, 'Mauá da Serra' FROM dual
 UNION ALL

 SELECT 3004, 18, 'Medianeira' FROM dual
 UNION ALL

 SELECT 3005, 18, 'Mercedes' FROM dual
 UNION ALL

 SELECT 3006, 18, 'Mirador' FROM dual
 UNION ALL

 SELECT 3007, 18, 'Miraselva' FROM dual
 UNION ALL

 SELECT 3008, 18, 'Missal' FROM dual
 UNION ALL

 SELECT 3009, 18, 'Moreira Sales' FROM dual
 UNION ALL

 SELECT 3010, 18, 'Morretes' FROM dual
 UNION ALL

 SELECT 3011, 18, 'Munhoz de Melo' FROM dual
 UNION ALL

 SELECT 3012, 18, 'Nossa Senhora das Graças' FROM dual
 UNION ALL

 SELECT 3013, 18, 'Nova Aliança do Ivaí' FROM dual
 UNION ALL

 SELECT 3014, 18, 'Nova América da Colina' FROM dual
 UNION ALL

 SELECT 3015, 18, 'Nova Aurora' FROM dual
 UNION ALL

 SELECT 3016, 18, 'Nova Cantu' FROM dual
 UNION ALL

 SELECT 3017, 18, 'Nova Esperança' FROM dual
 UNION ALL

 SELECT 3018, 18, 'Nova Esperança do Sudoeste' FROM dual
 UNION ALL

 SELECT 3019, 18, 'Nova Fátima' FROM dual
 UNION ALL

 SELECT 3020, 18, 'Nova Laranjeiras' FROM dual
 UNION ALL

 SELECT 3021, 18, 'Nova Londrina' FROM dual
 UNION ALL

 SELECT 3022, 18, 'Nova Olímpia' FROM dual
 UNION ALL

 SELECT 3023, 18, 'Nova Prata do Iguaçu' FROM dual
 UNION ALL

 SELECT 3024, 18, 'Nova Santa Bárbara' FROM dual
 UNION ALL

 SELECT 3025, 18, 'Nova Santa Rosa' FROM dual
 UNION ALL

 SELECT 3026, 18, 'Nova Tebas' FROM dual
 UNION ALL

 SELECT 3027, 18, 'Novo Itacolomi' FROM dual
 UNION ALL

 SELECT 3028, 18, 'Ortigueira' FROM dual
 UNION ALL

 SELECT 3029, 18, 'Ourizona' FROM dual
 UNION ALL

 SELECT 3030, 18, 'Ouro Verde do Oeste' FROM dual
 UNION ALL

 SELECT 3031, 18, 'Paiçandu' FROM dual
 UNION ALL

 SELECT 3032, 18, 'Palmas' FROM dual
 UNION ALL

 SELECT 3033, 18, 'Palmeira' FROM dual
 UNION ALL

 SELECT 3034, 18, 'Palmital' FROM dual
 UNION ALL

 SELECT 3035, 18, 'Palotina' FROM dual
 UNION ALL

 SELECT 3036, 18, 'Paraíso do Norte' FROM dual
 UNION ALL

 SELECT 3037, 18, 'Paranacity' FROM dual
 UNION ALL

 SELECT 3038, 18, 'Paranaguá' FROM dual
 UNION ALL

 SELECT 3039, 18, 'Paranapoema' FROM dual
 UNION ALL

 SELECT 3040, 18, 'Paranavaí' FROM dual
 UNION ALL

 SELECT 3041, 18, 'Pato Bragado' FROM dual
 UNION ALL

 SELECT 3042, 18, 'Pato Branco' FROM dual
 UNION ALL

 SELECT 3043, 18, 'Paula Freitas' FROM dual
 UNION ALL

 SELECT 3044, 18, 'Paulo Frontin' FROM dual
 UNION ALL

 SELECT 3045, 18, 'Peabiru' FROM dual
 UNION ALL

 SELECT 3046, 18, 'Perobal' FROM dual
 UNION ALL

 SELECT 3047, 18, 'Pérola' FROM dual
 UNION ALL

 SELECT 3048, 18, 'Pérola d`Oeste' FROM dual
 UNION ALL

 SELECT 3049, 18, 'Piên' FROM dual
 UNION ALL

 SELECT 3050, 18, 'Pinhais' FROM dual
 UNION ALL

 SELECT 3051, 18, 'Pinhal de São Bento' FROM dual
 UNION ALL

 SELECT 3052, 18, 'Pinhalão' FROM dual
 UNION ALL

 SELECT 3053, 18, 'Pinhão' FROM dual
 UNION ALL

 SELECT 3054, 18, 'Piraí do Sul' FROM dual
 UNION ALL

 SELECT 3055, 18, 'Piraquara' FROM dual
 UNION ALL

 SELECT 3056, 18, 'Pitanga' FROM dual
 UNION ALL

 SELECT 3057, 18, 'Pitangueiras' FROM dual
 UNION ALL

 SELECT 3058, 18, 'Planaltina do Paraná' FROM dual
 UNION ALL

 SELECT 3059, 18, 'Planalto' FROM dual
 UNION ALL

 SELECT 3060, 18, 'Ponta Grossa' FROM dual
 UNION ALL

 SELECT 3061, 18, 'Pontal do Paraná' FROM dual
 UNION ALL

 SELECT 3062, 18, 'Porecatu' FROM dual
 UNION ALL

 SELECT 3063, 18, 'Porto Amazonas' FROM dual
 UNION ALL

 SELECT 3064, 18, 'Porto Barreiro' FROM dual
 UNION ALL

 SELECT 3065, 18, 'Porto Rico' FROM dual
 UNION ALL

 SELECT 3066, 18, 'Porto Vitória' FROM dual
 UNION ALL

 SELECT 3067, 18, 'Prado Ferreira' FROM dual
 UNION ALL

 SELECT 3068, 18, 'Pranchita' FROM dual
 UNION ALL

 SELECT 3069, 18, 'Presidente Castelo Branco' FROM dual
 UNION ALL

 SELECT 3070, 18, 'Primeiro de Maio' FROM dual
 UNION ALL

 SELECT 3071, 18, 'Prudentópolis' FROM dual
 UNION ALL

 SELECT 3072, 18, 'Quarto Centenário' FROM dual
 UNION ALL

 SELECT 3073, 18, 'Quatiguá' FROM dual
 UNION ALL

 SELECT 3074, 18, 'Quatro Barras' FROM dual
 UNION ALL

 SELECT 3075, 18, 'Quatro Pontes' FROM dual
 UNION ALL

 SELECT 3076, 18, 'Quedas do Iguaçu' FROM dual
 UNION ALL

 SELECT 3077, 18, 'Querência do Norte' FROM dual
 UNION ALL

 SELECT 3078, 18, 'Quinta do Sol' FROM dual
 UNION ALL

 SELECT 3079, 18, 'Quitandinha' FROM dual
 UNION ALL

 SELECT 3080, 18, 'Ramilândia' FROM dual
 UNION ALL

 SELECT 3081, 18, 'Rancho Alegre' FROM dual
 UNION ALL

 SELECT 3082, 18, 'Rancho Alegre d`Oeste' FROM dual
 UNION ALL

 SELECT 3083, 18, 'Realeza' FROM dual
 UNION ALL

 SELECT 3084, 18, 'Rebouças' FROM dual
 UNION ALL

 SELECT 3085, 18, 'Renascença' FROM dual
 UNION ALL

 SELECT 3086, 18, 'Reserva' FROM dual
 UNION ALL

 SELECT 3087, 18, 'Reserva do Iguaçu' FROM dual
 UNION ALL

 SELECT 3088, 18, 'Ribeirão Claro' FROM dual
 UNION ALL

 SELECT 3089, 18, 'Ribeirão do Pinhal' FROM dual
 UNION ALL

 SELECT 3090, 18, 'Rio Azul' FROM dual
 UNION ALL

 SELECT 3091, 18, 'Rio Bom' FROM dual
 UNION ALL

 SELECT 3092, 18, 'Rio Bonito do Iguaçu' FROM dual
 UNION ALL

 SELECT 3093, 18, 'Rio Branco do Ivaí' FROM dual
 UNION ALL

 SELECT 3094, 18, 'Rio Branco do Sul' FROM dual
 UNION ALL

 SELECT 3095, 18, 'Rio Negro' FROM dual
 UNION ALL

 SELECT 3096, 18, 'Rolândia' FROM dual
 UNION ALL

 SELECT 3097, 18, 'Roncador' FROM dual
 UNION ALL

 SELECT 3098, 18, 'Rondon' FROM dual
 UNION ALL

 SELECT 3099, 18, 'Rosário do Ivaí' FROM dual
 UNION ALL

 SELECT 3100, 18, 'Sabáudia' FROM dual
 UNION ALL

 SELECT 3101, 18, 'Salgado Filho' FROM dual
 UNION ALL

 SELECT 3102, 18, 'Salto do Itararé' FROM dual
 UNION ALL

 SELECT 3103, 18, 'Salto do Lontra' FROM dual
 UNION ALL

 SELECT 3104, 18, 'Santa Amélia' FROM dual
 UNION ALL

 SELECT 3105, 18, 'Santa Cecília do Pavão' FROM dual
 UNION ALL

 SELECT 3106, 18, 'Santa Cruz de Monte Castelo' FROM dual
 UNION ALL

 SELECT 3107, 18, 'Santa Fé' FROM dual
 UNION ALL

 SELECT 3108, 18, 'Santa Helena' FROM dual
 UNION ALL

 SELECT 3109, 18, 'Santa Inês' FROM dual
 UNION ALL

 SELECT 3110, 18, 'Santa Isabel do Ivaí' FROM dual
 UNION ALL

 SELECT 3111, 18, 'Santa Izabel do Oeste' FROM dual
 UNION ALL

 SELECT 3112, 18, 'Santa Lúcia' FROM dual
 UNION ALL

 SELECT 3113, 18, 'Santa Maria do Oeste' FROM dual
 UNION ALL

 SELECT 3114, 18, 'Santa Mariana' FROM dual
 UNION ALL

 SELECT 3115, 18, 'Santa Mônica' FROM dual
 UNION ALL

 SELECT 3116, 18, 'Santa Tereza do Oeste' FROM dual
 UNION ALL

 SELECT 3117, 18, 'Santa Terezinha de Itaipu' FROM dual
 UNION ALL

 SELECT 3118, 18, 'Santana do Itararé' FROM dual
 UNION ALL

 SELECT 3119, 18, 'Santo Antônio da Platina' FROM dual
 UNION ALL

 SELECT 3120, 18, 'Santo Antônio do Caiuá' FROM dual
 UNION ALL

 SELECT 3121, 18, 'Santo Antônio do Paraíso' FROM dual
 UNION ALL

 SELECT 3122, 18, 'Santo Antônio do Sudoeste' FROM dual
 UNION ALL

 SELECT 3123, 18, 'Santo Inácio' FROM dual
 UNION ALL

 SELECT 3124, 18, 'São Carlos do Ivaí' FROM dual
 UNION ALL

 SELECT 3125, 18, 'São Jerônimo da Serra' FROM dual
 UNION ALL

 SELECT 3126, 18, 'São João' FROM dual
 UNION ALL

 SELECT 3127, 18, 'São João do Caiuá' FROM dual
 UNION ALL

 SELECT 3128, 18, 'São João do Ivaí' FROM dual
 UNION ALL

 SELECT 3129, 18, 'São João do Triunfo' FROM dual
 UNION ALL

 SELECT 3130, 18, 'São Jorge d`Oeste' FROM dual
 UNION ALL

 SELECT 3131, 18, 'São Jorge do Ivaí' FROM dual
 UNION ALL

 SELECT 3132, 18, 'São Jorge do Patrocínio' FROM dual
 UNION ALL

 SELECT 3133, 18, 'São José da Boa Vista' FROM dual
 UNION ALL

 SELECT 3134, 18, 'São José das Palmeiras' FROM dual
 UNION ALL

 SELECT 3135, 18, 'São José dos Pinhais' FROM dual
 UNION ALL

 SELECT 3136, 18, 'São Manoel do Paraná' FROM dual
 UNION ALL

 SELECT 3137, 18, 'São Mateus do Sul' FROM dual
 UNION ALL

 SELECT 3138, 18, 'São Miguel do Iguaçu' FROM dual
 UNION ALL

 SELECT 3139, 18, 'São Pedro do Iguaçu' FROM dual
 UNION ALL

 SELECT 3140, 18, 'São Pedro do Ivaí' FROM dual
 UNION ALL

 SELECT 3141, 18, 'São Pedro do Paraná' FROM dual
 UNION ALL

 SELECT 3142, 18, 'São Sebastião da Amoreira' FROM dual
 UNION ALL

 SELECT 3143, 18, 'São Tomé' FROM dual
 UNION ALL

 SELECT 3144, 18, 'Sapopema' FROM dual
 UNION ALL

 SELECT 3145, 18, 'Sarandi' FROM dual
 UNION ALL

 SELECT 3146, 18, 'Saudade do Iguaçu' FROM dual
 UNION ALL

 SELECT 3147, 18, 'Sengés' FROM dual
 UNION ALL

 SELECT 3148, 18, 'Serranópolis do Iguaçu' FROM dual
 UNION ALL

 SELECT 3149, 18, 'Sertaneja' FROM dual
 UNION ALL

 SELECT 3150, 18, 'Sertanópolis' FROM dual
 UNION ALL

 SELECT 3151, 18, 'Siqueira Campos' FROM dual
 UNION ALL

 SELECT 3152, 18, 'Sulina' FROM dual
 UNION ALL

 SELECT 3153, 18, 'Tamarana' FROM dual
 UNION ALL

 SELECT 3154, 18, 'Tamboara' FROM dual
 UNION ALL

 SELECT 3155, 18, 'Tapejara' FROM dual
 UNION ALL

 SELECT 3156, 18, 'Tapira' FROM dual
 UNION ALL

 SELECT 3157, 18, 'Teixeira Soares' FROM dual
 UNION ALL

 SELECT 3158, 18, 'Telêmaco Borba' FROM dual
 UNION ALL

 SELECT 3159, 18, 'Terra Boa' FROM dual
 UNION ALL

 SELECT 3160, 18, 'Terra Rica' FROM dual
 UNION ALL

 SELECT 3161, 18, 'Terra Roxa' FROM dual
 UNION ALL

 SELECT 3162, 18, 'Tibagi' FROM dual
 UNION ALL

 SELECT 3163, 18, 'Tijucas do Sul' FROM dual
 UNION ALL

 SELECT 3164, 18, 'Toledo' FROM dual
 UNION ALL

 SELECT 3165, 18, 'Tomazina' FROM dual
 UNION ALL

 SELECT 3166, 18, 'Três Barras do Paraná' FROM dual
 UNION ALL

 SELECT 3167, 18, 'Tunas do Paraná' FROM dual
 UNION ALL

 SELECT 3168, 18, 'Tuneiras do Oeste' FROM dual
 UNION ALL

 SELECT 3169, 18, 'Tupãssi' FROM dual
 UNION ALL

 SELECT 3170, 18, 'Turvo' FROM dual
 UNION ALL

 SELECT 3171, 18, 'Ubiratã' FROM dual
 UNION ALL

 SELECT 3172, 18, 'Umuarama' FROM dual
 UNION ALL

 SELECT 3173, 18, 'União da Vitória' FROM dual
 UNION ALL

 SELECT 3174, 18, 'Uniflor' FROM dual
 UNION ALL

 SELECT 3175, 18, 'Uraí' FROM dual
 UNION ALL

 SELECT 3176, 18, 'Ventania' FROM dual
 UNION ALL

 SELECT 3177, 18, 'Vera Cruz do Oeste' FROM dual
 UNION ALL

 SELECT 3178, 18, 'Verê' FROM dual
 UNION ALL

 SELECT 3179, 18, 'Virmond' FROM dual
 UNION ALL

 SELECT 3180, 18, 'Vitorino' FROM dual
 UNION ALL

 SELECT 3181, 18, 'Wenceslau Braz' FROM dual
 UNION ALL

 SELECT 3182, 18, 'Xambrê' FROM dual
 UNION ALL

 SELECT 3183, 16, 'Abreu e Lima' FROM dual
 UNION ALL

 SELECT 3184, 16, 'Afogados da Ingazeira' FROM dual
 UNION ALL

 SELECT 3185, 16, 'Afrânio' FROM dual
 UNION ALL

 SELECT 3186, 16, 'Agrestina' FROM dual
 UNION ALL

 SELECT 3187, 16, 'Água Preta' FROM dual
 UNION ALL

 SELECT 3188, 16, 'Águas Belas' FROM dual
 UNION ALL

 SELECT 3189, 16, 'Alagoinha' FROM dual
 UNION ALL

 SELECT 3190, 16, 'Aliança' FROM dual
 UNION ALL

 SELECT 3191, 16, 'Altinho' FROM dual
 UNION ALL

 SELECT 3192, 16, 'Amaraji' FROM dual
 UNION ALL

 SELECT 3193, 16, 'Angelim' FROM dual
 UNION ALL

 SELECT 3194, 16, 'Araçoiaba' FROM dual
 UNION ALL

 SELECT 3195, 16, 'Araripina' FROM dual
 UNION ALL

 SELECT 3196, 16, 'Arcoverde' FROM dual
 UNION ALL

 SELECT 3197, 16, 'Barra de Guabiraba' FROM dual
 UNION ALL

 SELECT 3198, 16, 'Barreiros' FROM dual
 UNION ALL

 SELECT 3199, 16, 'Belém de Maria' FROM dual
 UNION ALL

 SELECT 3200, 16, 'Belém de São Francisco' FROM dual
 UNION ALL

 SELECT 3201, 16, 'Belo Jardim' FROM dual
 UNION ALL

 SELECT 3202, 16, 'Betânia' FROM dual
 UNION ALL

 SELECT 3203, 16, 'Bezerros' FROM dual
 UNION ALL

 SELECT 3204, 16, 'Bodocó' FROM dual
 UNION ALL

 SELECT 3205, 16, 'Bom Conselho' FROM dual
 UNION ALL

 SELECT 3206, 16, 'Bom Jardim' FROM dual
 UNION ALL

 SELECT 3207, 16, 'Bonito' FROM dual
 UNION ALL

 SELECT 3208, 16, 'Brejão' FROM dual
 UNION ALL

 SELECT 3209, 16, 'Brejinho' FROM dual
 UNION ALL

 SELECT 3210, 16, 'Brejo da Madre de Deus' FROM dual
 UNION ALL

 SELECT 3211, 16, 'Buenos Aires' FROM dual
 UNION ALL

 SELECT 3212, 16, 'Buíque' FROM dual
 UNION ALL

 SELECT 3213, 16, 'Cabo de Santo Agostinho' FROM dual
 UNION ALL

 SELECT 3214, 16, 'Cabrobó' FROM dual
 UNION ALL

 SELECT 3215, 16, 'Cachoeirinha' FROM dual
 UNION ALL

 SELECT 3216, 16, 'Caetés' FROM dual
 UNION ALL

 SELECT 3217, 16, 'Calçado' FROM dual
 UNION ALL

 SELECT 3218, 16, 'Calumbi' FROM dual
 UNION ALL

 SELECT 3219, 16, 'Camaragibe' FROM dual
 UNION ALL

 SELECT 3220, 16, 'Camocim de São Félix' FROM dual
 UNION ALL

 SELECT 3221, 16, 'Camutanga' FROM dual
 UNION ALL

 SELECT 3222, 16, 'Canhotinho' FROM dual
 UNION ALL

 SELECT 3223, 16, 'Capoeiras' FROM dual
 UNION ALL

 SELECT 3224, 16, 'Carnaíba' FROM dual
 UNION ALL

 SELECT 3225, 16, 'Carnaubeira da Penha' FROM dual
 UNION ALL

 SELECT 3226, 16, 'Carpina' FROM dual
 UNION ALL

 SELECT 3227, 16, 'Caruaru' FROM dual
 UNION ALL

 SELECT 3228, 16, 'Casinhas' FROM dual
 UNION ALL

 SELECT 3229, 16, 'Catende' FROM dual
 UNION ALL

 SELECT 3230, 16, 'Cedro' FROM dual
 UNION ALL

 SELECT 3231, 16, 'Chã de Alegria' FROM dual
 UNION ALL

 SELECT 3232, 16, 'Chã Grande' FROM dual
 UNION ALL

 SELECT 3233, 16, 'Condado' FROM dual
 UNION ALL

 SELECT 3234, 16, 'Correntes' FROM dual
 UNION ALL

 SELECT 3235, 16, 'Cortês' FROM dual
 UNION ALL

 SELECT 3236, 16, 'Cumaru' FROM dual
 UNION ALL

 SELECT 3237, 16, 'Cupira' FROM dual
 UNION ALL

 SELECT 3238, 16, 'Custódia' FROM dual
 UNION ALL

 SELECT 3239, 16, 'Dormentes' FROM dual
 UNION ALL

 SELECT 3240, 16, 'Escada' FROM dual
 UNION ALL

 SELECT 3241, 16, 'Exu' FROM dual
 UNION ALL

 SELECT 3242, 16, 'Feira Nova' FROM dual
 UNION ALL

 SELECT 3243, 16, 'Fernando de Noronha' FROM dual
 UNION ALL

 SELECT 3244, 16, 'Ferreiros' FROM dual
 UNION ALL

 SELECT 3245, 16, 'Flores' FROM dual
 UNION ALL

 SELECT 3246, 16, 'Floresta' FROM dual
 UNION ALL

 SELECT 3247, 16, 'Frei Miguelinho' FROM dual
 UNION ALL

 SELECT 3248, 16, 'Gameleira' FROM dual
 UNION ALL

 SELECT 3249, 16, 'Garanhuns' FROM dual
 UNION ALL

 SELECT 3250, 16, 'Glória do Goitá' FROM dual
 UNION ALL

 SELECT 3251, 16, 'Goiana' FROM dual
 UNION ALL

 SELECT 3252, 16, 'Granito' FROM dual
 UNION ALL

 SELECT 3253, 16, 'Gravatá' FROM dual
 UNION ALL

 SELECT 3254, 16, 'Iati' FROM dual
 UNION ALL

 SELECT 3255, 16, 'Ibimirim' FROM dual
 UNION ALL

 SELECT 3256, 16, 'Ibirajuba' FROM dual
 UNION ALL

 SELECT 3257, 16, 'Igarassu' FROM dual
 UNION ALL

 SELECT 3258, 16, 'Iguaraci' FROM dual
 UNION ALL

 SELECT 3259, 16, 'Ilha de Itamaracá' FROM dual
 UNION ALL

 SELECT 3260, 16, 'Inajá' FROM dual
 UNION ALL

 SELECT 3261, 16, 'Ingazeira' FROM dual
 UNION ALL

 SELECT 3262, 16, 'Ipojuca' FROM dual
 UNION ALL

 SELECT 3263, 16, 'Ipubi' FROM dual
 UNION ALL

 SELECT 3264, 16, 'Itacuruba' FROM dual
 UNION ALL

 SELECT 3265, 16, 'Itaíba' FROM dual
 UNION ALL

 SELECT 3266, 16, 'Itambé' FROM dual
 UNION ALL

 SELECT 3267, 16, 'Itapetim' FROM dual
 UNION ALL

 SELECT 3268, 16, 'Itapissuma' FROM dual
 UNION ALL

 SELECT 3269, 16, 'Itaquitinga' FROM dual
 UNION ALL

 SELECT 3270, 16, 'Jaboatão dos Guararapes' FROM dual
 UNION ALL

 SELECT 3271, 16, 'Jaqueira' FROM dual
 UNION ALL

 SELECT 3272, 16, 'Jataúba' FROM dual
 UNION ALL

 SELECT 3273, 16, 'Jatobá' FROM dual
 UNION ALL

 SELECT 3274, 16, 'João Alfredo' FROM dual
 UNION ALL

 SELECT 3275, 16, 'Joaquim Nabuco' FROM dual
 UNION ALL

 SELECT 3276, 16, 'Jucati' FROM dual
 UNION ALL

 SELECT 3277, 16, 'Jupi' FROM dual
 UNION ALL

 SELECT 3278, 16, 'Jurema' FROM dual
 UNION ALL

 SELECT 3279, 16, 'Lagoa do Carro' FROM dual
 UNION ALL

 SELECT 3280, 16, 'Lagoa do Itaenga' FROM dual
 UNION ALL

 SELECT 3281, 16, 'Lagoa do Ouro' FROM dual
 UNION ALL

 SELECT 3282, 16, 'Lagoa dos Gatos' FROM dual
 UNION ALL

 SELECT 3283, 16, 'Lagoa Grande' FROM dual
 UNION ALL

 SELECT 3284, 16, 'Lajedo' FROM dual
 UNION ALL

 SELECT 3285, 16, 'Limoeiro' FROM dual
 UNION ALL

 SELECT 3286, 16, 'Macaparana' FROM dual
 UNION ALL

 SELECT 3287, 16, 'Machados' FROM dual
 UNION ALL

 SELECT 3288, 16, 'Manari' FROM dual
 UNION ALL

 SELECT 3289, 16, 'Maraial' FROM dual
 UNION ALL

 SELECT 3290, 16, 'Mirandiba' FROM dual
 UNION ALL

 SELECT 3291, 16, 'Moreilândia' FROM dual
 UNION ALL

 SELECT 3292, 16, 'Moreno' FROM dual
 UNION ALL

 SELECT 3293, 16, 'Nazaré da Mata' FROM dual
 UNION ALL

 SELECT 3294, 16, 'Olinda' FROM dual
 UNION ALL

 SELECT 3295, 16, 'Orobó' FROM dual
 UNION ALL

 SELECT 3296, 16, 'Orocó' FROM dual
 UNION ALL

 SELECT 3297, 16, 'Ouricuri' FROM dual
 UNION ALL

 SELECT 3298, 16, 'Palmares' FROM dual
 UNION ALL

 SELECT 3299, 16, 'Palmeirina' FROM dual
 UNION ALL

 SELECT 3300, 16, 'Panelas' FROM dual
 UNION ALL

 SELECT 3301, 16, 'Paranatama' FROM dual
 UNION ALL

 SELECT 3302, 16, 'Parnamirim' FROM dual
 UNION ALL

 SELECT 3303, 16, 'Passira' FROM dual
 UNION ALL

 SELECT 3304, 16, 'Paudalho' FROM dual
 UNION ALL

 SELECT 3305, 16, 'Paulista' FROM dual
 UNION ALL

 SELECT 3306, 16, 'Pedra' FROM dual
 UNION ALL

 SELECT 3307, 16, 'Pesqueira' FROM dual
 UNION ALL

 SELECT 3308, 16, 'Petrolândia' FROM dual
 UNION ALL

 SELECT 3309, 16, 'Petrolina' FROM dual
 UNION ALL

 SELECT 3310, 16, 'Poção' FROM dual
 UNION ALL

 SELECT 3311, 16, 'Pombos' FROM dual
 UNION ALL

 SELECT 3312, 16, 'Primavera' FROM dual
 UNION ALL

 SELECT 3313, 16, 'Quipapá' FROM dual
 UNION ALL

 SELECT 3314, 16, 'Quixaba' FROM dual
 UNION ALL

 SELECT 3315, 16, 'Recife' FROM dual
 UNION ALL

 SELECT 3316, 16, 'Riacho das Almas' FROM dual
 UNION ALL

 SELECT 3317, 16, 'Ribeirão' FROM dual
 UNION ALL

 SELECT 3318, 16, 'Rio Formoso' FROM dual
 UNION ALL

 SELECT 3319, 16, 'Sairé' FROM dual
 UNION ALL

 SELECT 3320, 16, 'Salgadinho' FROM dual
 UNION ALL

 SELECT 3321, 16, 'Salgueiro' FROM dual
 UNION ALL

 SELECT 3322, 16, 'Saloá' FROM dual
 UNION ALL

 SELECT 3323, 16, 'Sanharó' FROM dual
 UNION ALL

 SELECT 3324, 16, 'Santa Cruz' FROM dual
 UNION ALL

 SELECT 3325, 16, 'Santa Cruz da Baixa Verde' FROM dual
 UNION ALL

 SELECT 3326, 16, 'Santa Cruz do Capibaribe' FROM dual
 UNION ALL

 SELECT 3327, 16, 'Santa Filomena' FROM dual
 UNION ALL

 SELECT 3328, 16, 'Santa Maria da Boa Vista' FROM dual
 UNION ALL

 SELECT 3329, 16, 'Santa Maria do Cambucá' FROM dual
 UNION ALL

 SELECT 3330, 16, 'Santa Terezinha' FROM dual
 UNION ALL

 SELECT 3331, 16, 'São Benedito do Sul' FROM dual
 UNION ALL

 SELECT 3332, 16, 'São Bento do Una' FROM dual
 UNION ALL

 SELECT 3333, 16, 'São Caitano' FROM dual
 UNION ALL

 SELECT 3334, 16, 'São João' FROM dual
 UNION ALL

 SELECT 3335, 16, 'São Joaquim do Monte' FROM dual
 UNION ALL

 SELECT 3336, 16, 'São José da Coroa Grande' FROM dual
 UNION ALL

 SELECT 3337, 16, 'São José do Belmonte' FROM dual
 UNION ALL

 SELECT 3338, 16, 'São José do Egito' FROM dual
 UNION ALL

 SELECT 3339, 16, 'São Lourenço da Mata' FROM dual
 UNION ALL

 SELECT 3340, 16, 'São Vicente Ferrer' FROM dual
 UNION ALL

 SELECT 3341, 16, 'Serra Talhada' FROM dual
 UNION ALL

 SELECT 3342, 16, 'Serrita' FROM dual
 UNION ALL

 SELECT 3343, 16, 'Sertânia' FROM dual
 UNION ALL

 SELECT 3344, 16, 'Sirinhaém' FROM dual
 UNION ALL

 SELECT 3345, 16, 'Solidão' FROM dual
 UNION ALL

 SELECT 3346, 16, 'Surubim' FROM dual
 UNION ALL

 SELECT 3347, 16, 'Tabira' FROM dual
 UNION ALL

 SELECT 3348, 16, 'Tacaimbó' FROM dual
 UNION ALL

 SELECT 3349, 16, 'Tacaratu' FROM dual
 UNION ALL

 SELECT 3350, 16, 'Tamandaré' FROM dual
 UNION ALL

 SELECT 3351, 16, 'Taquaritinga do Norte' FROM dual
 UNION ALL

 SELECT 3352, 16, 'Terezinha' FROM dual
 UNION ALL

 SELECT 3353, 16, 'Terra Nova' FROM dual
 UNION ALL

 SELECT 3354, 16, 'Timbaúba' FROM dual
 UNION ALL

 SELECT 3355, 16, 'Toritama' FROM dual
 UNION ALL

 SELECT 3356, 16, 'Tracunhaém' FROM dual
 UNION ALL

 SELECT 3357, 16, 'Trindade' FROM dual
 UNION ALL

 SELECT 3358, 16, 'Triunfo' FROM dual
 UNION ALL

 SELECT 3359, 16, 'Tupanatinga' FROM dual
 UNION ALL

 SELECT 3360, 16, 'Tuparetama' FROM dual
 UNION ALL

 SELECT 3361, 16, 'Venturosa' FROM dual
 UNION ALL

 SELECT 3362, 16, 'Verdejante' FROM dual
 UNION ALL

 SELECT 3363, 16, 'Vertente do Lério' FROM dual
 UNION ALL

 SELECT 3364, 16, 'Vertentes' FROM dual
 UNION ALL

 SELECT 3365, 16, 'Vicência' FROM dual
 UNION ALL

 SELECT 3366, 16, 'Vitória de Santo Antão' FROM dual
 UNION ALL

 SELECT 3367, 16, 'Xexéu' FROM dual
 UNION ALL

 SELECT 3368, 17, 'Acauã' FROM dual
 UNION ALL

 SELECT 3369, 17, 'Agricolândia' FROM dual
 UNION ALL

 SELECT 3370, 17, 'Água Branca' FROM dual
 UNION ALL

 SELECT 3371, 17, 'Alagoinha do Piauí' FROM dual
 UNION ALL

 SELECT 3372, 17, 'Alegrete do Piauí' FROM dual
 UNION ALL

 SELECT 3373, 17, 'Alto Longá' FROM dual
 UNION ALL

 SELECT 3374, 17, 'Altos' FROM dual
 UNION ALL

 SELECT 3375, 17, 'Alvorada do Gurguéia' FROM dual
 UNION ALL

 SELECT 3376, 17, 'Amarante' FROM dual
 UNION ALL

 SELECT 3377, 17, 'Angical do Piauí' FROM dual
 UNION ALL

 SELECT 3378, 17, 'Anísio de Abreu' FROM dual
 UNION ALL

 SELECT 3379, 17, 'Antônio Almeida' FROM dual
 UNION ALL

 SELECT 3380, 17, 'Aroazes' FROM dual
 UNION ALL

 SELECT 3381, 17, 'Aroeiras do Itaim' FROM dual
 UNION ALL

 SELECT 3382, 17, 'Arraial' FROM dual
 UNION ALL

 SELECT 3383, 17, 'Assunção do Piauí' FROM dual
 UNION ALL

 SELECT 3384, 17, 'Avelino Lopes' FROM dual
 UNION ALL

 SELECT 3385, 17, 'Baixa Grande do Ribeiro' FROM dual
 UNION ALL

 SELECT 3386, 17, 'Barra d`Alcântara' FROM dual
 UNION ALL

 SELECT 3387, 17, 'Barras' FROM dual
 UNION ALL

 SELECT 3388, 17, 'Barreiras do Piauí' FROM dual
 UNION ALL

 SELECT 3389, 17, 'Barro Duro' FROM dual
 UNION ALL

 SELECT 3390, 17, 'Batalha' FROM dual
 UNION ALL

 SELECT 3391, 17, 'Bela Vista do Piauí' FROM dual
 UNION ALL

 SELECT 3392, 17, 'Belém do Piauí' FROM dual
 UNION ALL

 SELECT 3393, 17, 'Beneditinos' FROM dual
 UNION ALL

 SELECT 3394, 17, 'Bertolínia' FROM dual
 UNION ALL

 SELECT 3395, 17, 'Betânia do Piauí' FROM dual
 UNION ALL

 SELECT 3396, 17, 'Boa Hora' FROM dual
 UNION ALL

 SELECT 3397, 17, 'Bocaina' FROM dual
 UNION ALL

 SELECT 3398, 17, 'Bom Jesus' FROM dual
 UNION ALL

 SELECT 3399, 17, 'Bom Princípio do Piauí' FROM dual
 UNION ALL

 SELECT 3400, 17, 'Bonfim do Piauí' FROM dual
 UNION ALL

 SELECT 3401, 17, 'Boqueirão do Piauí' FROM dual
 UNION ALL

 SELECT 3402, 17, 'Brasileira' FROM dual
 UNION ALL

 SELECT 3403, 17, 'Brejo do Piauí' FROM dual
 UNION ALL

 SELECT 3404, 17, 'Buriti dos Lopes' FROM dual
 UNION ALL

 SELECT 3405, 17, 'Buriti dos Montes' FROM dual
 UNION ALL

 SELECT 3406, 17, 'Cabeceiras do Piauí' FROM dual
 UNION ALL

 SELECT 3407, 17, 'Cajazeiras do Piauí' FROM dual
 UNION ALL

 SELECT 3408, 17, 'Cajueiro da Praia' FROM dual
 UNION ALL

 SELECT 3409, 17, 'Caldeirão Grande do Piauí' FROM dual
 UNION ALL

 SELECT 3410, 17, 'Campinas do Piauí' FROM dual
 UNION ALL

 SELECT 3411, 17, 'Campo Alegre do Fidalgo' FROM dual
 UNION ALL

 SELECT 3412, 17, 'Campo Grande do Piauí' FROM dual
 UNION ALL

 SELECT 3413, 17, 'Campo Largo do Piauí' FROM dual
 UNION ALL

 SELECT 3414, 17, 'Campo Maior' FROM dual
 UNION ALL

 SELECT 3415, 17, 'Canavieira' FROM dual
 UNION ALL

 SELECT 3416, 17, 'Canto do Buriti' FROM dual
 UNION ALL

 SELECT 3417, 17, 'Capitão de Campos' FROM dual
 UNION ALL

 SELECT 3418, 17, 'Capitão Gervásio Oliveira' FROM dual
 UNION ALL

 SELECT 3419, 17, 'Caracol' FROM dual
 UNION ALL

 SELECT 3420, 17, 'Caraúbas do Piauí' FROM dual
 UNION ALL

 SELECT 3421, 17, 'Caridade do Piauí' FROM dual
 UNION ALL

 SELECT 3422, 17, 'Castelo do Piauí' FROM dual
 UNION ALL

 SELECT 3423, 17, 'Caxingó' FROM dual
 UNION ALL

 SELECT 3424, 17, 'Cocal' FROM dual
 UNION ALL

 SELECT 3425, 17, 'Cocal de Telha' FROM dual
 UNION ALL

 SELECT 3426, 17, 'Cocal dos Alves' FROM dual
 UNION ALL

 SELECT 3427, 17, 'Coivaras' FROM dual
 UNION ALL

 SELECT 3428, 17, 'Colônia do Gurguéia' FROM dual
 UNION ALL

 SELECT 3429, 17, 'Colônia do Piauí' FROM dual
 UNION ALL

 SELECT 3430, 17, 'Conceição do Canindé' FROM dual
 UNION ALL

 SELECT 3431, 17, 'Coronel José Dias' FROM dual
 UNION ALL

 SELECT 3432, 17, 'Corrente' FROM dual
 UNION ALL

 SELECT 3433, 17, 'Cristalândia do Piauí' FROM dual
 UNION ALL

 SELECT 3434, 17, 'Cristino Castro' FROM dual
 UNION ALL

 SELECT 3435, 17, 'Curimatá' FROM dual
 UNION ALL

 SELECT 3436, 17, 'Currais' FROM dual
 UNION ALL

 SELECT 3437, 17, 'Curral Novo do Piauí' FROM dual
 UNION ALL

 SELECT 3438, 17, 'Curralinhos' FROM dual
 UNION ALL

 SELECT 3439, 17, 'Demerval Lobão' FROM dual
 UNION ALL

 SELECT 3440, 17, 'Dirceu Arcoverde' FROM dual
 UNION ALL

 SELECT 3441, 17, 'Dom Expedito Lopes' FROM dual
 UNION ALL

 SELECT 3442, 17, 'Dom Inocêncio' FROM dual
 UNION ALL

 SELECT 3443, 17, 'Domingos Mourão' FROM dual
 UNION ALL

 SELECT 3444, 17, 'Elesbão Veloso' FROM dual
 UNION ALL

 SELECT 3445, 17, 'Eliseu Martins' FROM dual
 UNION ALL

 SELECT 3446, 17, 'Esperantina' FROM dual
 UNION ALL

 SELECT 3447, 17, 'Fartura do Piauí' FROM dual
 UNION ALL

 SELECT 3448, 17, 'Flores do Piauí' FROM dual
 UNION ALL

 SELECT 3449, 17, 'Floresta do Piauí' FROM dual
 UNION ALL

 SELECT 3450, 17, 'Floriano' FROM dual
 UNION ALL

 SELECT 3451, 17, 'Francinópolis' FROM dual
 UNION ALL

 SELECT 3452, 17, 'Francisco Ayres' FROM dual
 UNION ALL

 SELECT 3453, 17, 'Francisco Macedo' FROM dual
 UNION ALL

 SELECT 3454, 17, 'Francisco Santos' FROM dual
 UNION ALL

 SELECT 3455, 17, 'Fronteiras' FROM dual
 UNION ALL

 SELECT 3456, 17, 'Geminiano' FROM dual
 UNION ALL

 SELECT 3457, 17, 'Gilbués' FROM dual
 UNION ALL

 SELECT 3458, 17, 'Guadalupe' FROM dual
 UNION ALL

 SELECT 3459, 17, 'Guaribas' FROM dual
 UNION ALL

 SELECT 3460, 17, 'Hugo Napoleão' FROM dual
 UNION ALL

 SELECT 3461, 17, 'Ilha Grande' FROM dual
 UNION ALL

 SELECT 3462, 17, 'Inhuma' FROM dual
 UNION ALL

 SELECT 3463, 17, 'Ipiranga do Piauí' FROM dual
 UNION ALL

 SELECT 3464, 17, 'Isaías Coelho' FROM dual
 UNION ALL

 SELECT 3465, 17, 'Itainópolis' FROM dual
 UNION ALL

 SELECT 3466, 17, 'Itaueira' FROM dual
 UNION ALL

 SELECT 3467, 17, 'Jacobina do Piauí' FROM dual
 UNION ALL

 SELECT 3468, 17, 'Jaicós' FROM dual
 UNION ALL

 SELECT 3469, 17, 'Jardim do Mulato' FROM dual
 UNION ALL

 SELECT 3470, 17, 'Jatobá do Piauí' FROM dual
 UNION ALL

 SELECT 3471, 17, 'Jerumenha' FROM dual
 UNION ALL

 SELECT 3472, 17, 'João Costa' FROM dual
 UNION ALL

 SELECT 3473, 17, 'Joaquim Pires' FROM dual
 UNION ALL

 SELECT 3474, 17, 'Joca Marques' FROM dual
 UNION ALL

 SELECT 3475, 17, 'José de Freitas' FROM dual
 UNION ALL

 SELECT 3476, 17, 'Juazeiro do Piauí' FROM dual
 UNION ALL

 SELECT 3477, 17, 'Júlio Borges' FROM dual
 UNION ALL

 SELECT 3478, 17, 'Jurema' FROM dual
 UNION ALL

 SELECT 3479, 17, 'Lagoa Alegre' FROM dual
 UNION ALL

 SELECT 3480, 17, 'Lagoa de São Francisco' FROM dual
 UNION ALL

 SELECT 3481, 17, 'Lagoa do Barro do Piauí' FROM dual
 UNION ALL

 SELECT 3482, 17, 'Lagoa do Piauí' FROM dual
 UNION ALL

 SELECT 3483, 17, 'Lagoa do Sítio' FROM dual
 UNION ALL

 SELECT 3484, 17, 'Lagoinha do Piauí' FROM dual
 UNION ALL

 SELECT 3485, 17, 'Landri Sales' FROM dual
 UNION ALL

 SELECT 3486, 17, 'Luís Correia' FROM dual
 UNION ALL

 SELECT 3487, 17, 'Luzilândia' FROM dual
 UNION ALL

 SELECT 3488, 17, 'Madeiro' FROM dual
 UNION ALL

 SELECT 3489, 17, 'Manoel Emídio' FROM dual
 UNION ALL

 SELECT 3490, 17, 'Marcolândia' FROM dual
 UNION ALL

 SELECT 3491, 17, 'Marcos Parente' FROM dual
 UNION ALL

 SELECT 3492, 17, 'Massapê do Piauí' FROM dual
 UNION ALL

 SELECT 3493, 17, 'Matias Olímpio' FROM dual
 UNION ALL

 SELECT 3494, 17, 'Miguel Alves' FROM dual
 UNION ALL

 SELECT 3495, 17, 'Miguel Leão' FROM dual
 UNION ALL

 SELECT 3496, 17, 'Milton Brandão' FROM dual
 UNION ALL

 SELECT 3497, 17, 'Monsenhor Gil' FROM dual
 UNION ALL

 SELECT 3498, 17, 'Monsenhor Hipólito' FROM dual
 UNION ALL

 SELECT 3499, 17, 'Monte Alegre do Piauí' FROM dual
 UNION ALL

 SELECT 3500, 17, 'Morro Cabeça no Tempo' FROM dual
 UNION ALL

 SELECT 3501, 17, 'Morro do Chapéu do Piauí' FROM dual
 UNION ALL

 SELECT 3502, 17, 'Murici dos Portelas' FROM dual
 UNION ALL

 SELECT 3503, 17, 'Nazaré do Piauí' FROM dual
 UNION ALL

 SELECT 3504, 17, 'Nossa Senhora de Nazaré' FROM dual
 UNION ALL

 SELECT 3505, 17, 'Nossa Senhora dos Remédios' FROM dual
 UNION ALL

 SELECT 3506, 17, 'Nova Santa Rita' FROM dual
 UNION ALL

 SELECT 3507, 17, 'Novo Oriente do Piauí' FROM dual
 UNION ALL

 SELECT 3508, 17, 'Novo Santo Antônio' FROM dual
 UNION ALL

 SELECT 3509, 17, 'Oeiras' FROM dual
 UNION ALL

 SELECT 3510, 17, 'Olho d`Água do Piauí' FROM dual
 UNION ALL

 SELECT 3511, 17, 'Padre Marcos' FROM dual
 UNION ALL

 SELECT 3512, 17, 'Paes Landim' FROM dual
 UNION ALL

 SELECT 3513, 17, 'Pajeú do Piauí' FROM dual
 UNION ALL

 SELECT 3514, 17, 'Palmeira do Piauí' FROM dual
 UNION ALL

 SELECT 3515, 17, 'Palmeirais' FROM dual
 UNION ALL

 SELECT 3516, 17, 'Paquetá' FROM dual
 UNION ALL

 SELECT 3517, 17, 'Parnaguá' FROM dual
 UNION ALL

 SELECT 3518, 17, 'Parnaíba' FROM dual
 UNION ALL

 SELECT 3519, 17, 'Passagem Franca do Piauí' FROM dual
 UNION ALL

 SELECT 3520, 17, 'Patos do Piauí' FROM dual
 UNION ALL

 SELECT 3521, 17, 'Pau d`Arco do Piauí' FROM dual
 UNION ALL

 SELECT 3522, 17, 'Paulistana' FROM dual
 UNION ALL

 SELECT 3523, 17, 'Pavussu' FROM dual
 UNION ALL

 SELECT 3524, 17, 'Pedro II' FROM dual
 UNION ALL

 SELECT 3525, 17, 'Pedro Laurentino' FROM dual
 UNION ALL

 SELECT 3526, 17, 'Picos' FROM dual
 UNION ALL

 SELECT 3527, 17, 'Pimenteiras' FROM dual
 UNION ALL

 SELECT 3528, 17, 'Pio IX' FROM dual
 UNION ALL

 SELECT 3529, 17, 'Piracuruca' FROM dual
 UNION ALL

 SELECT 3530, 17, 'Piripiri' FROM dual
 UNION ALL

 SELECT 3531, 17, 'Porto' FROM dual
 UNION ALL

 SELECT 3532, 17, 'Porto Alegre do Piauí' FROM dual
 UNION ALL

 SELECT 3533, 17, 'Prata do Piauí' FROM dual
 UNION ALL

 SELECT 3534, 17, 'Queimada Nova' FROM dual
 UNION ALL

 SELECT 3535, 17, 'Redenção do Gurguéia' FROM dual
 UNION ALL

 SELECT 3536, 17, 'Regeneração' FROM dual
 UNION ALL

 SELECT 3537, 17, 'Riacho Frio' FROM dual
 UNION ALL

 SELECT 3538, 17, 'Ribeira do Piauí' FROM dual
 UNION ALL

 SELECT 3539, 17, 'Ribeiro Gonçalves' FROM dual
 UNION ALL

 SELECT 3540, 17, 'Rio Grande do Piauí' FROM dual
 UNION ALL

 SELECT 3541, 17, 'Santa Cruz do Piauí' FROM dual
 UNION ALL

 SELECT 3542, 17, 'Santa Cruz dos Milagres' FROM dual
 UNION ALL

 SELECT 3543, 17, 'Santa Filomena' FROM dual
 UNION ALL

 SELECT 3544, 17, 'Santa Luz' FROM dual
 UNION ALL

 SELECT 3545, 17, 'Santa Rosa do Piauí' FROM dual
 UNION ALL

 SELECT 3546, 17, 'Santana do Piauí' FROM dual
 UNION ALL

 SELECT 3547, 17, 'Santo Antônio de Lisboa' FROM dual
 UNION ALL

 SELECT 3548, 17, 'Santo Antônio dos Milagres' FROM dual
 UNION ALL

 SELECT 3549, 17, 'Santo Inácio do Piauí' FROM dual
 UNION ALL

 SELECT 3550, 17, 'São Braz do Piauí' FROM dual
 UNION ALL

 SELECT 3551, 17, 'São Félix do Piauí' FROM dual
 UNION ALL

 SELECT 3552, 17, 'São Francisco de Assis do Piauí' FROM dual
 UNION ALL

 SELECT 3553, 17, 'São Francisco do Piauí' FROM dual
 UNION ALL

 SELECT 3554, 17, 'São Gonçalo do Gurguéia' FROM dual
 UNION ALL

 SELECT 3555, 17, 'São Gonçalo do Piauí' FROM dual
 UNION ALL

 SELECT 3556, 17, 'São João da Canabrava' FROM dual
 UNION ALL

 SELECT 3557, 17, 'São João da Fronteira' FROM dual
 UNION ALL

 SELECT 3558, 17, 'São João da Serra' FROM dual
 UNION ALL

 SELECT 3559, 17, 'São João da Varjota' FROM dual
 UNION ALL

 SELECT 3560, 17, 'São João do Arraial' FROM dual
 UNION ALL

 SELECT 3561, 17, 'São João do Piauí' FROM dual
 UNION ALL

 SELECT 3562, 17, 'São José do Divino' FROM dual
 UNION ALL

 SELECT 3563, 17, 'São José do Peixe' FROM dual
 UNION ALL

 SELECT 3564, 17, 'São José do Piauí' FROM dual
 UNION ALL

 SELECT 3565, 17, 'São Julião' FROM dual
 UNION ALL

 SELECT 3566, 17, 'São Lourenço do Piauí' FROM dual
 UNION ALL

 SELECT 3567, 17, 'São Luis do Piauí' FROM dual
 UNION ALL

 SELECT 3568, 17, 'São Miguel da Baixa Grande' FROM dual
 UNION ALL

 SELECT 3569, 17, 'São Miguel do Fidalgo' FROM dual
 UNION ALL

 SELECT 3570, 17, 'São Miguel do Tapuio' FROM dual
 UNION ALL

 SELECT 3571, 17, 'São Pedro do Piauí' FROM dual
 UNION ALL

 SELECT 3572, 17, 'São Raimundo Nonato' FROM dual
 UNION ALL

 SELECT 3573, 17, 'Sebastião Barros' FROM dual
 UNION ALL

 SELECT 3574, 17, 'Sebastião Leal' FROM dual
 UNION ALL

 SELECT 3575, 17, 'Sigefredo Pacheco' FROM dual
 UNION ALL

 SELECT 3576, 17, 'Simões' FROM dual
 UNION ALL

 SELECT 3577, 17, 'Simplício Mendes' FROM dual
 UNION ALL

 SELECT 3578, 17, 'Socorro do Piauí' FROM dual
 UNION ALL

 SELECT 3579, 17, 'Sussuapara' FROM dual
 UNION ALL

 SELECT 3580, 17, 'Tamboril do Piauí' FROM dual
 UNION ALL

 SELECT 3581, 17, 'Tanque do Piauí' FROM dual
 UNION ALL

 SELECT 3582, 17, 'Teresina' FROM dual
 UNION ALL

 SELECT 3583, 17, 'União' FROM dual
 UNION ALL

 SELECT 3584, 17, 'Uruçuí' FROM dual
 UNION ALL

 SELECT 3585, 17, 'Valença do Piauí' FROM dual
 UNION ALL

 SELECT 3586, 17, 'Várzea Branca' FROM dual
 UNION ALL

 SELECT 3587, 17, 'Várzea Grande' FROM dual
 UNION ALL

 SELECT 3588, 17, 'Vera Mendes' FROM dual
 UNION ALL

 SELECT 3589, 17, 'Vila Nova do Piauí' FROM dual
 UNION ALL

 SELECT 3590, 17, 'Wall Ferraz' FROM dual
 UNION ALL

 SELECT 3591, 19, 'Angra dos Reis' FROM dual
 UNION ALL

 SELECT 3592, 19, 'Aperibé' FROM dual
 UNION ALL

 SELECT 3593, 19, 'Araruama' FROM dual
 UNION ALL

 SELECT 3594, 19, 'Areal' FROM dual
 UNION ALL

 SELECT 3595, 19, 'Armação dos Búzios' FROM dual
 UNION ALL

 SELECT 3596, 19, 'Arraial do Cabo' FROM dual
 UNION ALL

 SELECT 3597, 19, 'Barra do Piraí' FROM dual
 UNION ALL

 SELECT 3598, 19, 'Barra Mansa' FROM dual
 UNION ALL

 SELECT 3599, 19, 'Belford Roxo' FROM dual
 UNION ALL

 SELECT 3600, 19, 'Bom Jardim' FROM dual
 UNION ALL

 SELECT 3601, 19, 'Bom Jesus do Itabapoana' FROM dual
 UNION ALL

 SELECT 3602, 19, 'Cabo Frio' FROM dual
 UNION ALL

 SELECT 3603, 19, 'Cachoeiras de Macacu' FROM dual
 UNION ALL

 SELECT 3604, 19, 'Cambuci' FROM dual
 UNION ALL

 SELECT 3605, 19, 'Campos dos Goytacazes' FROM dual
 UNION ALL

 SELECT 3606, 19, 'Cantagalo' FROM dual
 UNION ALL

 SELECT 3607, 19, 'Carapebus' FROM dual
 UNION ALL

 SELECT 3608, 19, 'Cardoso Moreira' FROM dual
 UNION ALL

 SELECT 3609, 19, 'Carmo' FROM dual
 UNION ALL

 SELECT 3610, 19, 'Casimiro de Abreu' FROM dual
 UNION ALL

 SELECT 3611, 19, 'Comendador Levy Gasparian' FROM dual
 UNION ALL

 SELECT 3612, 19, 'Conceição de Macabu' FROM dual
 UNION ALL

 SELECT 3613, 19, 'Cordeiro' FROM dual
 UNION ALL

 SELECT 3614, 19, 'Duas Barras' FROM dual
 UNION ALL

 SELECT 3615, 19, 'Duque de Caxias' FROM dual
 UNION ALL

 SELECT 3616, 19, 'Engenheiro Paulo de Frontin' FROM dual
 UNION ALL

 SELECT 3617, 19, 'Guapimirim' FROM dual
 UNION ALL

 SELECT 3618, 19, 'Iguaba Grande' FROM dual
 UNION ALL

 SELECT 3619, 19, 'Itaboraí' FROM dual
 UNION ALL

 SELECT 3620, 19, 'Itaguaí' FROM dual
 UNION ALL

 SELECT 3621, 19, 'Italva' FROM dual
 UNION ALL

 SELECT 3622, 19, 'Itaocara' FROM dual
 UNION ALL

 SELECT 3623, 19, 'Itaperuna' FROM dual
 UNION ALL

 SELECT 3624, 19, 'Itatiaia' FROM dual
 UNION ALL

 SELECT 3625, 19, 'Japeri' FROM dual
 UNION ALL

 SELECT 3626, 19, 'Laje do Muriaé' FROM dual
 UNION ALL

 SELECT 3627, 19, 'Macaé' FROM dual
 UNION ALL

 SELECT 3628, 19, 'Macuco' FROM dual
 UNION ALL

 SELECT 3629, 19, 'Magé' FROM dual
 UNION ALL

 SELECT 3630, 19, 'Mangaratiba' FROM dual
 UNION ALL

 SELECT 3631, 19, 'Maricá' FROM dual
 UNION ALL

 SELECT 3632, 19, 'Mendes' FROM dual
 UNION ALL

 SELECT 3633, 19, 'Mesquita' FROM dual
 UNION ALL

 SELECT 3634, 19, 'Miguel Pereira' FROM dual
 UNION ALL

 SELECT 3635, 19, 'Miracema' FROM dual
 UNION ALL

 SELECT 3636, 19, 'Natividade' FROM dual
 UNION ALL

 SELECT 3637, 19, 'Nilópolis' FROM dual
 UNION ALL

 SELECT 3638, 19, 'Niterói' FROM dual
 UNION ALL

 SELECT 3639, 19, 'Nova Friburgo' FROM dual
 UNION ALL

 SELECT 3640, 19, 'Nova Iguaçu' FROM dual
 UNION ALL

 SELECT 3641, 19, 'Paracambi' FROM dual
 UNION ALL

 SELECT 3642, 19, 'Paraíba do Sul' FROM dual
 UNION ALL

 SELECT 3643, 19, 'Parati' FROM dual
 UNION ALL

 SELECT 3644, 19, 'Paty do Alferes' FROM dual
 UNION ALL

 SELECT 3645, 19, 'Petrópolis' FROM dual
 UNION ALL

 SELECT 3646, 19, 'Pinheiral' FROM dual
 UNION ALL

 SELECT 3647, 19, 'Piraí' FROM dual
 UNION ALL

 SELECT 3648, 19, 'Porciúncula' FROM dual
 UNION ALL

 SELECT 3649, 19, 'Porto Real' FROM dual
 UNION ALL

 SELECT 3650, 19, 'Quatis' FROM dual
 UNION ALL

 SELECT 3651, 19, 'Queimados' FROM dual
 UNION ALL

 SELECT 3652, 19, 'Quissamã' FROM dual
 UNION ALL

 SELECT 3653, 19, 'Resende' FROM dual
 UNION ALL

 SELECT 3654, 19, 'Rio Bonito' FROM dual
 UNION ALL

 SELECT 3655, 19, 'Rio Claro' FROM dual
 UNION ALL

 SELECT 3656, 19, 'Rio das Flores' FROM dual
 UNION ALL

 SELECT 3657, 19, 'Rio das Ostras' FROM dual
 UNION ALL

 SELECT 3658, 19, 'Rio de Janeiro' FROM dual
 UNION ALL

 SELECT 3659, 19, 'Santa Maria Madalena' FROM dual
 UNION ALL

 SELECT 3660, 19, 'Santo Antônio de Pádua' FROM dual
 UNION ALL

 SELECT 3661, 19, 'São Fidélis' FROM dual
 UNION ALL

 SELECT 3662, 19, 'São Francisco de Itabapoana' FROM dual
 UNION ALL

 SELECT 3663, 19, 'São Gonçalo' FROM dual
 UNION ALL

 SELECT 3664, 19, 'São João da Barra' FROM dual
 UNION ALL

 SELECT 3665, 19, 'São João de Meriti' FROM dual
 UNION ALL

 SELECT 3666, 19, 'São José de Ubá' FROM dual
 UNION ALL

 SELECT 3667, 19, 'São José do Vale do Rio Pret' FROM dual
 UNION ALL

 SELECT 3668, 19, 'São Pedro da Aldeia' FROM dual
 UNION ALL

 SELECT 3669, 19, 'São Sebastião do Alto' FROM dual
 UNION ALL

 SELECT 3670, 19, 'Sapucaia' FROM dual
 UNION ALL

 SELECT 3671, 19, 'Saquarema' FROM dual
 UNION ALL

 SELECT 3672, 19, 'Seropédica' FROM dual
 UNION ALL

 SELECT 3673, 19, 'Silva Jardim' FROM dual
 UNION ALL

 SELECT 3674, 19, 'Sumidouro' FROM dual
 UNION ALL

 SELECT 3675, 19, 'Tanguá' FROM dual
 UNION ALL

 SELECT 3676, 19, 'Teresópolis' FROM dual
 UNION ALL

 SELECT 3677, 19, 'Trajano de Morais' FROM dual
 UNION ALL

 SELECT 3678, 19, 'Três Rios' FROM dual
 UNION ALL

 SELECT 3679, 19, 'Valença' FROM dual
 UNION ALL

 SELECT 3680, 19, 'Varre-Sai' FROM dual
 UNION ALL

 SELECT 3681, 19, 'Vassouras' FROM dual
 UNION ALL

 SELECT 3682, 19, 'Volta Redonda' FROM dual
 UNION ALL

 SELECT 3683, 20, 'Acari' FROM dual
 UNION ALL

 SELECT 3684, 20, 'Açu' FROM dual
 UNION ALL

 SELECT 3685, 20, 'Afonso Bezerra' FROM dual
 UNION ALL

 SELECT 3686, 20, 'Água Nova' FROM dual
 UNION ALL

 SELECT 3687, 20, 'Alexandria' FROM dual
 UNION ALL

 SELECT 3688, 20, 'Almino Afonso' FROM dual
 UNION ALL

 SELECT 3689, 20, 'Alto do Rodrigues' FROM dual
 UNION ALL

 SELECT 3690, 20, 'Angicos' FROM dual
 UNION ALL

 SELECT 3691, 20, 'Antônio Martins' FROM dual
 UNION ALL

 SELECT 3692, 20, 'Apodi' FROM dual
 UNION ALL

 SELECT 3693, 20, 'Areia Branca' FROM dual
 UNION ALL

 SELECT 3694, 20, 'Arês' FROM dual
 UNION ALL

 SELECT 3695, 20, 'Augusto Severo' FROM dual
 UNION ALL

 SELECT 3696, 20, 'Baía Formosa' FROM dual
 UNION ALL

 SELECT 3697, 20, 'Baraúna' FROM dual
 UNION ALL

 SELECT 3698, 20, 'Barcelona' FROM dual
 UNION ALL

 SELECT 3699, 20, 'Bento Fernandes' FROM dual
 UNION ALL

 SELECT 3700, 20, 'Bodó' FROM dual
 UNION ALL

 SELECT 3701, 20, 'Bom Jesus' FROM dual
 UNION ALL

 SELECT 3702, 20, 'Brejinho' FROM dual
 UNION ALL

 SELECT 3703, 20, 'Caiçara do Norte' FROM dual
 UNION ALL

 SELECT 3704, 20, 'Caiçara do Rio do Vento' FROM dual
 UNION ALL

 SELECT 3705, 20, 'Caicó' FROM dual
 UNION ALL

 SELECT 3706, 20, 'Campo Redondo' FROM dual
 UNION ALL

 SELECT 3707, 20, 'Canguaretama' FROM dual
 UNION ALL

 SELECT 3708, 20, 'Caraúbas' FROM dual
 UNION ALL

 SELECT 3709, 20, 'Carnaúba dos Dantas' FROM dual
 UNION ALL

 SELECT 3710, 20, 'Carnaubais' FROM dual
 UNION ALL

 SELECT 3711, 20, 'Ceará-Mirim' FROM dual
 UNION ALL

 SELECT 3712, 20, 'Cerro Corá' FROM dual
 UNION ALL

 SELECT 3713, 20, 'Coronel Ezequiel' FROM dual
 UNION ALL

 SELECT 3714, 20, 'Coronel João Pessoa' FROM dual
 UNION ALL

 SELECT 3715, 20, 'Cruzeta' FROM dual
 UNION ALL

 SELECT 3716, 20, 'Currais Novos' FROM dual
 UNION ALL

 SELECT 3717, 20, 'Doutor Severiano' FROM dual
 UNION ALL

 SELECT 3718, 20, 'Encanto' FROM dual
 UNION ALL

 SELECT 3719, 20, 'Equador' FROM dual
 UNION ALL

 SELECT 3720, 20, 'Espírito Santo' FROM dual
 UNION ALL

 SELECT 3721, 20, 'Extremoz' FROM dual
 UNION ALL

 SELECT 3722, 20, 'Felipe Guerra' FROM dual
 UNION ALL

 SELECT 3723, 20, 'Fernando Pedroza' FROM dual
 UNION ALL

 SELECT 3724, 20, 'Florânia' FROM dual
 UNION ALL

 SELECT 3725, 20, 'Francisco Dantas' FROM dual
 UNION ALL

 SELECT 3726, 20, 'Frutuoso Gomes' FROM dual
 UNION ALL

 SELECT 3727, 20, 'Galinhos' FROM dual
 UNION ALL

 SELECT 3728, 20, 'Goianinha' FROM dual
 UNION ALL

 SELECT 3729, 20, 'Governador Dix-Sept Rosado' FROM dual
 UNION ALL

 SELECT 3730, 20, 'Grossos' FROM dual
 UNION ALL

 SELECT 3731, 20, 'Guamaré' FROM dual
 UNION ALL

 SELECT 3732, 20, 'Ielmo Marinho' FROM dual
 UNION ALL

 SELECT 3733, 20, 'Ipanguaçu' FROM dual
 UNION ALL

 SELECT 3734, 20, 'Ipueira' FROM dual
 UNION ALL

 SELECT 3735, 20, 'Itajá' FROM dual
 UNION ALL

 SELECT 3736, 20, 'Itaú' FROM dual
 UNION ALL

 SELECT 3737, 20, 'Jaçanã' FROM dual
 UNION ALL

 SELECT 3738, 20, 'Jandaíra' FROM dual
 UNION ALL

 SELECT 3739, 20, 'Janduís' FROM dual
 UNION ALL

 SELECT 3740, 20, 'Januário Cicco' FROM dual
 UNION ALL

 SELECT 3741, 20, 'Japi' FROM dual
 UNION ALL

 SELECT 3742, 20, 'Jardim de Angicos' FROM dual
 UNION ALL

 SELECT 3743, 20, 'Jardim de Piranhas' FROM dual
 UNION ALL

 SELECT 3744, 20, 'Jardim do Seridó' FROM dual
 UNION ALL

 SELECT 3745, 20, 'João Câmara' FROM dual
 UNION ALL

 SELECT 3746, 20, 'João Dias' FROM dual
 UNION ALL

 SELECT 3747, 20, 'José da Penha' FROM dual
 UNION ALL

 SELECT 3748, 20, 'Jucurutu' FROM dual
 UNION ALL

 SELECT 3749, 20, 'Jundiá' FROM dual
 UNION ALL

 SELECT 3750, 20, 'Lagoa d`Anta' FROM dual
 UNION ALL

 SELECT 3751, 20, 'Lagoa de Pedras' FROM dual
 UNION ALL

 SELECT 3752, 20, 'Lagoa de Velhos' FROM dual
 UNION ALL

 SELECT 3753, 20, 'Lagoa Nova' FROM dual
 UNION ALL

 SELECT 3754, 20, 'Lagoa Salgada' FROM dual
 UNION ALL

 SELECT 3755, 20, 'Lajes' FROM dual
 UNION ALL

 SELECT 3756, 20, 'Lajes Pintadas' FROM dual
 UNION ALL

 SELECT 3757, 20, 'Lucrécia' FROM dual
 UNION ALL

 SELECT 3758, 20, 'Luís Gomes' FROM dual
 UNION ALL

 SELECT 3759, 20, 'Macaíba' FROM dual
 UNION ALL

 SELECT 3760, 20, 'Macau' FROM dual
 UNION ALL

 SELECT 3761, 20, 'Major Sales' FROM dual
 UNION ALL

 SELECT 3762, 20, 'Marcelino Vieira' FROM dual
 UNION ALL

 SELECT 3763, 20, 'Martins' FROM dual
 UNION ALL

 SELECT 3764, 20, 'Maxaranguape' FROM dual
 UNION ALL

 SELECT 3765, 20, 'Messias Targino' FROM dual
 UNION ALL

 SELECT 3766, 20, 'Montanhas' FROM dual
 UNION ALL

 SELECT 3767, 20, 'Monte Alegre' FROM dual
 UNION ALL

 SELECT 3768, 20, 'Monte das Gameleiras' FROM dual
 UNION ALL

 SELECT 3769, 20, 'Mossoró' FROM dual
 UNION ALL

 SELECT 3770, 20, 'Natal' FROM dual
 UNION ALL

 SELECT 3771, 20, 'Nísia Floresta' FROM dual
 UNION ALL

 SELECT 3772, 20, 'Nova Cruz' FROM dual
 UNION ALL

 SELECT 3773, 20, 'Olho-d`Água do Borges' FROM dual
 UNION ALL

 SELECT 3774, 20, 'Ouro Branco' FROM dual
 UNION ALL

 SELECT 3775, 20, 'Paraná' FROM dual
 UNION ALL

 SELECT 3776, 20, 'Paraú' FROM dual
 UNION ALL

 SELECT 3777, 20, 'Parazinho' FROM dual
 UNION ALL

 SELECT 3778, 20, 'Parelhas' FROM dual
 UNION ALL

 SELECT 3779, 20, 'Parnamirim' FROM dual
 UNION ALL

 SELECT 3780, 20, 'Passa e Fica' FROM dual
 UNION ALL

 SELECT 3781, 20, 'Passagem' FROM dual
 UNION ALL

 SELECT 3782, 20, 'Patu' FROM dual
 UNION ALL

 SELECT 3783, 20, 'Pau dos Ferros' FROM dual
 UNION ALL

 SELECT 3784, 20, 'Pedra Grande' FROM dual
 UNION ALL

 SELECT 3785, 20, 'Pedra Preta' FROM dual
 UNION ALL

 SELECT 3786, 20, 'Pedro Avelino' FROM dual
 UNION ALL

 SELECT 3787, 20, 'Pedro Velho' FROM dual
 UNION ALL

 SELECT 3788, 20, 'Pendências' FROM dual
 UNION ALL

 SELECT 3789, 20, 'Pilões' FROM dual
 UNION ALL

 SELECT 3790, 20, 'Poço Branco' FROM dual
 UNION ALL

 SELECT 3791, 20, 'Portalegre' FROM dual
 UNION ALL

 SELECT 3792, 20, 'Porto do Mangue' FROM dual
 UNION ALL

 SELECT 3793, 20, 'Presidente Juscelino' FROM dual
 UNION ALL

 SELECT 3794, 20, 'Pureza' FROM dual
 UNION ALL

 SELECT 3795, 20, 'Rafael Fernandes' FROM dual
 UNION ALL

 SELECT 3796, 20, 'Rafael Godeiro' FROM dual
 UNION ALL

 SELECT 3797, 20, 'Riacho da Cruz' FROM dual
 UNION ALL

 SELECT 3798, 20, 'Riacho de Santana' FROM dual
 UNION ALL

 SELECT 3799, 20, 'Riachuelo' FROM dual
 UNION ALL

 SELECT 3800, 20, 'Rio do Fogo' FROM dual
 UNION ALL

 SELECT 3801, 20, 'Rodolfo Fernandes' FROM dual
 UNION ALL

 SELECT 3802, 20, 'Ruy Barbosa' FROM dual
 UNION ALL

 SELECT 3803, 20, 'Santa Cruz' FROM dual
 UNION ALL

 SELECT 3804, 20, 'Santa Maria' FROM dual
 UNION ALL

 SELECT 3805, 20, 'Santana do Matos' FROM dual
 UNION ALL

 SELECT 3806, 20, 'Santana do Seridó' FROM dual
 UNION ALL

 SELECT 3807, 20, 'Santo Antônio' FROM dual
 UNION ALL

 SELECT 3808, 20, 'São Bento do Norte' FROM dual
 UNION ALL

 SELECT 3809, 20, 'São Bento do Trairí' FROM dual
 UNION ALL

 SELECT 3810, 20, 'São Fernando' FROM dual
 UNION ALL

 SELECT 3811, 20, 'São Francisco do Oeste' FROM dual
 UNION ALL

 SELECT 3812, 20, 'São Gonçalo do Amarante' FROM dual
 UNION ALL

 SELECT 3813, 20, 'São João do Sabugi' FROM dual
 UNION ALL

 SELECT 3814, 20, 'São José de Mipibu' FROM dual
 UNION ALL

 SELECT 3815, 20, 'São José do Campestre' FROM dual
 UNION ALL

 SELECT 3816, 20, 'São José do Seridó' FROM dual
 UNION ALL

 SELECT 3817, 20, 'São Miguel' FROM dual
 UNION ALL

 SELECT 3818, 20, 'São Miguel do Gostoso' FROM dual
 UNION ALL

 SELECT 3819, 20, 'São Paulo do Potengi' FROM dual
 UNION ALL

 SELECT 3820, 20, 'São Pedro' FROM dual
 UNION ALL

 SELECT 3821, 20, 'São Rafael' FROM dual
 UNION ALL

 SELECT 3822, 20, 'São Tomé' FROM dual
 UNION ALL

 SELECT 3823, 20, 'São Vicente' FROM dual
 UNION ALL

 SELECT 3824, 20, 'Senador Elói de Souza' FROM dual
 UNION ALL

 SELECT 3825, 20, 'Senador Georgino Avelino' FROM dual
 UNION ALL

 SELECT 3826, 20, 'Serra de São Bento' FROM dual
 UNION ALL

 SELECT 3827, 20, 'Serra do Mel' FROM dual
 UNION ALL

 SELECT 3828, 20, 'Serra Negra do Norte' FROM dual
 UNION ALL

 SELECT 3829, 20, 'Serrinha' FROM dual
 UNION ALL

 SELECT 3830, 20, 'Serrinha dos Pintos' FROM dual
 UNION ALL

 SELECT 3831, 20, 'Severiano Melo' FROM dual
 UNION ALL

 SELECT 3832, 20, 'Sítio Novo' FROM dual
 UNION ALL

 SELECT 3833, 20, 'Taboleiro Grande' FROM dual
 UNION ALL

 SELECT 3834, 20, 'Taipu' FROM dual
 UNION ALL

 SELECT 3835, 20, 'Tangará' FROM dual
 UNION ALL

 SELECT 3836, 20, 'Tenente Ananias' FROM dual
 UNION ALL

 SELECT 3837, 20, 'Tenente Laurentino Cruz' FROM dual
 UNION ALL

 SELECT 3838, 20, 'Tibau' FROM dual
 UNION ALL

 SELECT 3839, 20, 'Tibau do Sul' FROM dual
 UNION ALL

 SELECT 3840, 20, 'Timbaúba dos Batistas' FROM dual
 UNION ALL

 SELECT 3841, 20, 'Touros' FROM dual
 UNION ALL

 SELECT 3842, 20, 'Triunfo Potiguar' FROM dual
 UNION ALL

 SELECT 3843, 20, 'Umarizal' FROM dual
 UNION ALL

 SELECT 3844, 20, 'Upanema' FROM dual
 UNION ALL

 SELECT 3845, 20, 'Várzea' FROM dual
 UNION ALL

 SELECT 3846, 20, 'Venha-Ver' FROM dual
 UNION ALL

 SELECT 3847, 20, 'Vera Cruz' FROM dual
 UNION ALL

 SELECT 3848, 20, 'Viçosa' FROM dual
 UNION ALL

 SELECT 3849, 20, 'Vila Flor' FROM dual
 UNION ALL

 SELECT 3850, 23, 'Aceguá' FROM dual
 UNION ALL

 SELECT 3851, 23, 'Água Santa' FROM dual
 UNION ALL

 SELECT 3852, 23, 'Agudo' FROM dual
 UNION ALL

 SELECT 3853, 23, 'Ajuricaba' FROM dual
 UNION ALL

 SELECT 3854, 23, 'Alecrim' FROM dual
 UNION ALL

 SELECT 3855, 23, 'Alegrete' FROM dual
 UNION ALL

 SELECT 3856, 23, 'Alegria' FROM dual
 UNION ALL

 SELECT 3857, 23, 'Almirante Tamandaré do Sul' FROM dual
 UNION ALL

 SELECT 3858, 23, 'Alpestre' FROM dual
 UNION ALL

 SELECT 3859, 23, 'Alto Alegre' FROM dual
 UNION ALL

 SELECT 3860, 23, 'Alto Feliz' FROM dual
 UNION ALL

 SELECT 3861, 23, 'Alvorada' FROM dual
 UNION ALL

 SELECT 3862, 23, 'Amaral Ferrador' FROM dual
 UNION ALL

 SELECT 3863, 23, 'Ametista do Sul' FROM dual
 UNION ALL

 SELECT 3864, 23, 'André da Rocha' FROM dual
 UNION ALL

 SELECT 3865, 23, 'Anta Gorda' FROM dual
 UNION ALL

 SELECT 3866, 23, 'Antônio Prado' FROM dual
 UNION ALL

 SELECT 3867, 23, 'Arambaré' FROM dual
 UNION ALL

 SELECT 3868, 23, 'Araricá' FROM dual
 UNION ALL

 SELECT 3869, 23, 'Aratiba' FROM dual
 UNION ALL

 SELECT 3870, 23, 'Arroio do Meio' FROM dual
 UNION ALL

 SELECT 3871, 23, 'Arroio do Padre' FROM dual
 UNION ALL

 SELECT 3872, 23, 'Arroio do Sal' FROM dual
 UNION ALL

 SELECT 3873, 23, 'Arroio do Tigre' FROM dual
 UNION ALL

 SELECT 3874, 23, 'Arroio dos Ratos' FROM dual
 UNION ALL

 SELECT 3875, 23, 'Arroio Grande' FROM dual
 UNION ALL

 SELECT 3876, 23, 'Arvorezinha' FROM dual
 UNION ALL

 SELECT 3877, 23, 'Augusto Pestana' FROM dual
 UNION ALL

 SELECT 3878, 23, 'Áurea' FROM dual
 UNION ALL

 SELECT 3879, 23, 'Bagé' FROM dual
 UNION ALL

 SELECT 3880, 23, 'Balneário Pinhal' FROM dual
 UNION ALL

 SELECT 3881, 23, 'Barão' FROM dual
 UNION ALL

 SELECT 3882, 23, 'Barão de Cotegipe' FROM dual
 UNION ALL

 SELECT 3883, 23, 'Barão do Triunfo' FROM dual
 UNION ALL

 SELECT 3884, 23, 'Barra do Guarita' FROM dual
 UNION ALL

 SELECT 3885, 23, 'Barra do Quaraí' FROM dual
 UNION ALL

 SELECT 3886, 23, 'Barra do Ribeiro' FROM dual
 UNION ALL

 SELECT 3887, 23, 'Barra do Rio Azul' FROM dual
 UNION ALL

 SELECT 3888, 23, 'Barra Funda' FROM dual
 UNION ALL

 SELECT 3889, 23, 'Barracão' FROM dual
 UNION ALL

 SELECT 3890, 23, 'Barros Cassal' FROM dual
 UNION ALL

 SELECT 3891, 23, 'Benjamin Constant do Sul' FROM dual
 UNION ALL

 SELECT 3892, 23, 'Bento Gonçalves' FROM dual
 UNION ALL

 SELECT 3893, 23, 'Boa Vista das Missões' FROM dual
 UNION ALL

 SELECT 3894, 23, 'Boa Vista do Buricá' FROM dual
 UNION ALL

 SELECT 3895, 23, 'Boa Vista do Cadeado' FROM dual
 UNION ALL

 SELECT 3896, 23, 'Boa Vista do Incra' FROM dual
 UNION ALL

 SELECT 3897, 23, 'Boa Vista do Sul' FROM dual
 UNION ALL

 SELECT 3898, 23, 'Bom Jesus' FROM dual
 UNION ALL

 SELECT 3899, 23, 'Bom Princípio' FROM dual
 UNION ALL

 SELECT 3900, 23, 'Bom Progresso' FROM dual
 UNION ALL

 SELECT 3901, 23, 'Bom Retiro do Sul' FROM dual
 UNION ALL

 SELECT 3902, 23, 'Boqueirão do Leão' FROM dual
 UNION ALL

 SELECT 3903, 23, 'Bossoroca' FROM dual
 UNION ALL

 SELECT 3904, 23, 'Bozano' FROM dual
 UNION ALL

 SELECT 3905, 23, 'Braga' FROM dual
 UNION ALL

 SELECT 3906, 23, 'Brochier' FROM dual
 UNION ALL

 SELECT 3907, 23, 'Butiá' FROM dual
 UNION ALL

 SELECT 3908, 23, 'Caçapava do Sul' FROM dual
 UNION ALL

 SELECT 3909, 23, 'Cacequi' FROM dual
 UNION ALL

 SELECT 3910, 23, 'Cachoeira do Sul' FROM dual
 UNION ALL

 SELECT 3911, 23, 'Cachoeirinha' FROM dual
 UNION ALL

 SELECT 3912, 23, 'Cacique Doble' FROM dual
 UNION ALL

 SELECT 3913, 23, 'Caibaté' FROM dual
 UNION ALL

 SELECT 3914, 23, 'Caiçara' FROM dual
 UNION ALL

 SELECT 3915, 23, 'Camaquã' FROM dual
 UNION ALL

 SELECT 3916, 23, 'Camargo' FROM dual
 UNION ALL

 SELECT 3917, 23, 'Cambará do Sul' FROM dual
 UNION ALL

 SELECT 3918, 23, 'Campestre da Serra' FROM dual
 UNION ALL

 SELECT 3919, 23, 'Campina das Missões' FROM dual
 UNION ALL

 SELECT 3920, 23, 'Campinas do Sul' FROM dual
 UNION ALL

 SELECT 3921, 23, 'Campo Bom' FROM dual
 UNION ALL

 SELECT 3922, 23, 'Campo Novo' FROM dual
 UNION ALL

 SELECT 3923, 23, 'Campos Borges' FROM dual
 UNION ALL

 SELECT 3924, 23, 'Candelária' FROM dual
 UNION ALL

 SELECT 3925, 23, 'Cândido Godói' FROM dual
 UNION ALL

 SELECT 3926, 23, 'Candiota' FROM dual
 UNION ALL

 SELECT 3927, 23, 'Canela' FROM dual
 UNION ALL

 SELECT 3928, 23, 'Canguçu' FROM dual
 UNION ALL

 SELECT 3929, 23, 'Canoas' FROM dual
 UNION ALL

 SELECT 3930, 23, 'Canudos do Vale' FROM dual
 UNION ALL

 SELECT 3931, 23, 'Capão Bonito do Sul' FROM dual
 UNION ALL

 SELECT 3932, 23, 'Capão da Canoa' FROM dual
 UNION ALL

 SELECT 3933, 23, 'Capão do Cipó' FROM dual
 UNION ALL

 SELECT 3934, 23, 'Capão do Leão' FROM dual
 UNION ALL

 SELECT 3935, 23, 'Capela de Santana' FROM dual
 UNION ALL

 SELECT 3936, 23, 'Capitão' FROM dual
 UNION ALL

 SELECT 3937, 23, 'Capivari do Sul' FROM dual
 UNION ALL

 SELECT 3938, 23, 'Caraá' FROM dual
 UNION ALL

 SELECT 3939, 23, 'Carazinho' FROM dual
 UNION ALL

 SELECT 3940, 23, 'Carlos Barbosa' FROM dual
 UNION ALL

 SELECT 3941, 23, 'Carlos Gomes' FROM dual
 UNION ALL

 SELECT 3942, 23, 'Casca' FROM dual
 UNION ALL

 SELECT 3943, 23, 'Caseiros' FROM dual
 UNION ALL

 SELECT 3944, 23, 'Catuípe' FROM dual
 UNION ALL

 SELECT 3945, 23, 'Caxias do Sul' FROM dual
 UNION ALL

 SELECT 3946, 23, 'Centenário' FROM dual
 UNION ALL

 SELECT 3947, 23, 'Cerrito' FROM dual
 UNION ALL

 SELECT 3948, 23, 'Cerro Branco' FROM dual
 UNION ALL

 SELECT 3949, 23, 'Cerro Grande' FROM dual
 UNION ALL

 SELECT 3950, 23, 'Cerro Grande do Sul' FROM dual
 UNION ALL

 SELECT 3951, 23, 'Cerro Largo' FROM dual
 UNION ALL

 SELECT 3952, 23, 'Chapada' FROM dual
 UNION ALL

 SELECT 3953, 23, 'Charqueadas' FROM dual
 UNION ALL

 SELECT 3954, 23, 'Charrua' FROM dual
 UNION ALL

 SELECT 3955, 23, 'Chiapeta' FROM dual
 UNION ALL

 SELECT 3956, 23, 'Chuí' FROM dual
 UNION ALL

 SELECT 3957, 23, 'Chuvisca' FROM dual
 UNION ALL

 SELECT 3958, 23, 'Cidreira' FROM dual
 UNION ALL

 SELECT 3959, 23, 'Ciríaco' FROM dual
 UNION ALL

 SELECT 3960, 23, 'Colinas' FROM dual
 UNION ALL

 SELECT 3961, 23, 'Colorado' FROM dual
 UNION ALL

 SELECT 3962, 23, 'Condor' FROM dual
 UNION ALL

 SELECT 3963, 23, 'Constantina' FROM dual
 UNION ALL

 SELECT 3964, 23, 'Coqueiro Baixo' FROM dual
 UNION ALL

 SELECT 3965, 23, 'Coqueiros do Sul' FROM dual
 UNION ALL

 SELECT 3966, 23, 'Coronel Barros' FROM dual
 UNION ALL

 SELECT 3967, 23, 'Coronel Bicaco' FROM dual
 UNION ALL

 SELECT 3968, 23, 'Coronel Pilar' FROM dual
 UNION ALL

 SELECT 3969, 23, 'Cotiporã' FROM dual
 UNION ALL

 SELECT 3970, 23, 'Coxilha' FROM dual
 UNION ALL

 SELECT 3971, 23, 'Crissiumal' FROM dual
 UNION ALL

 SELECT 3972, 23, 'Cristal' FROM dual
 UNION ALL

 SELECT 3973, 23, 'Cristal do Sul' FROM dual
 UNION ALL

 SELECT 3974, 23, 'Cruz Alta' FROM dual
 UNION ALL

 SELECT 3975, 23, 'Cruzaltense' FROM dual
 UNION ALL

 SELECT 3976, 23, 'Cruzeiro do Sul' FROM dual
 UNION ALL

 SELECT 3977, 23, 'David Canabarro' FROM dual
 UNION ALL

 SELECT 3978, 23, 'Derrubadas' FROM dual
 UNION ALL

 SELECT 3979, 23, 'Dezesseis de Novembro' FROM dual
 UNION ALL

 SELECT 3980, 23, 'Dilermando de Aguiar' FROM dual
 UNION ALL

 SELECT 3981, 23, 'Dois Irmãos' FROM dual
 UNION ALL

 SELECT 3982, 23, 'Dois Irmãos das Missões' FROM dual
 UNION ALL

 SELECT 3983, 23, 'Dois Lajeados' FROM dual
 UNION ALL

 SELECT 3984, 23, 'Dom Feliciano' FROM dual
 UNION ALL

 SELECT 3985, 23, 'Dom Pedrito' FROM dual
 UNION ALL

 SELECT 3986, 23, 'Dom Pedro de Alcântara' FROM dual
 UNION ALL

 SELECT 3987, 23, 'Dona Francisca' FROM dual
 UNION ALL

 SELECT 3988, 23, 'Doutor Maurício Cardoso' FROM dual
 UNION ALL

 SELECT 3989, 23, 'Doutor Ricardo' FROM dual
 UNION ALL

 SELECT 3990, 23, 'Eldorado do Sul' FROM dual
 UNION ALL

 SELECT 3991, 23, 'Encantado' FROM dual
 UNION ALL

 SELECT 3992, 23, 'Encruzilhada do Sul' FROM dual
 UNION ALL

 SELECT 3993, 23, 'Engenho Velho' FROM dual
 UNION ALL

 SELECT 3994, 23, 'Entre Rios do Sul' FROM dual
 UNION ALL

 SELECT 3995, 23, 'Entre-Ijuís' FROM dual
 UNION ALL

 SELECT 3996, 23, 'Erebango' FROM dual
 UNION ALL

 SELECT 3997, 23, 'Erechim' FROM dual
 UNION ALL

 SELECT 3998, 23, 'Ernestina' FROM dual
 UNION ALL

 SELECT 3999, 23, 'Erval Grande' FROM dual
 UNION ALL

 SELECT 4000, 23, 'Erval Seco' FROM dual
 UNION ALL

 SELECT 4001, 23, 'Esmeralda' FROM dual
 UNION ALL

 SELECT 4002, 23, 'Esperança do Sul' FROM dual
 UNION ALL

 SELECT 4003, 23, 'Espumoso' FROM dual
 UNION ALL

 SELECT 4004, 23, 'Estação' FROM dual
 UNION ALL

 SELECT 4005, 23, 'Estância Velha' FROM dual
 UNION ALL

 SELECT 4006, 23, 'Esteio' FROM dual
 UNION ALL

 SELECT 4007, 23, 'Estrela' FROM dual
 UNION ALL

 SELECT 4008, 23, 'Estrela Velha' FROM dual
 UNION ALL

 SELECT 4009, 23, 'Eugênio de Castro' FROM dual
 UNION ALL

 SELECT 4010, 23, 'Fagundes Varela' FROM dual
 UNION ALL

 SELECT 4011, 23, 'Farroupilha' FROM dual
 UNION ALL

 SELECT 4012, 23, 'Faxinal do Soturno' FROM dual
 UNION ALL

 SELECT 4013, 23, 'Faxinalzinho' FROM dual
 UNION ALL

 SELECT 4014, 23, 'Fazenda Vilanova' FROM dual
 UNION ALL

 SELECT 4015, 23, 'Feliz' FROM dual
 UNION ALL

 SELECT 4016, 23, 'Flores da Cunha' FROM dual
 UNION ALL

 SELECT 4017, 23, 'Floriano Peixoto' FROM dual
 UNION ALL

 SELECT 4018, 23, 'Fontoura Xavier' FROM dual
 UNION ALL

 SELECT 4019, 23, 'Formigueiro' FROM dual
 UNION ALL

 SELECT 4020, 23, 'Forquetinha' FROM dual
 UNION ALL

 SELECT 4021, 23, 'Fortaleza dos Valos' FROM dual
 UNION ALL

 SELECT 4022, 23, 'Frederico Westphalen' FROM dual
 UNION ALL

 SELECT 4023, 23, 'Garibaldi' FROM dual
 UNION ALL

 SELECT 4024, 23, 'Garruchos' FROM dual
 UNION ALL

 SELECT 4025, 23, 'Gaurama' FROM dual
 UNION ALL

 SELECT 4026, 23, 'General Câmara' FROM dual
 UNION ALL

 SELECT 4027, 23, 'Gentil' FROM dual
 UNION ALL

 SELECT 4028, 23, 'Getúlio Vargas' FROM dual
 UNION ALL

 SELECT 4029, 23, 'Giruá' FROM dual
 UNION ALL

 SELECT 4030, 23, 'Glorinha' FROM dual
 UNION ALL

 SELECT 4031, 23, 'Gramado' FROM dual
 UNION ALL

 SELECT 4032, 23, 'Gramado dos Loureiros' FROM dual
 UNION ALL

 SELECT 4033, 23, 'Gramado Xavier' FROM dual
 UNION ALL

 SELECT 4034, 23, 'Gravataí' FROM dual
 UNION ALL

 SELECT 4035, 23, 'Guabiju' FROM dual
 UNION ALL

 SELECT 4036, 23, 'Guaíba' FROM dual
 UNION ALL

 SELECT 4037, 23, 'Guaporé' FROM dual
 UNION ALL

 SELECT 4038, 23, 'Guarani das Missões' FROM dual
 UNION ALL

 SELECT 4039, 23, 'Harmonia' FROM dual
 UNION ALL

 SELECT 4040, 23, 'Herval' FROM dual
 UNION ALL

 SELECT 4041, 23, 'Herveiras' FROM dual
 UNION ALL

 SELECT 4042, 23, 'Horizontina' FROM dual
 UNION ALL

 SELECT 4043, 23, 'Hulha Negra' FROM dual
 UNION ALL

 SELECT 4044, 23, 'Humaitá' FROM dual
 UNION ALL

 SELECT 4045, 23, 'Ibarama' FROM dual
 UNION ALL

 SELECT 4046, 23, 'Ibiaçá' FROM dual
 UNION ALL

 SELECT 4047, 23, 'Ibiraiaras' FROM dual
 UNION ALL

 SELECT 4048, 23, 'Ibirapuitã' FROM dual
 UNION ALL

 SELECT 4049, 23, 'Ibirubá' FROM dual
 UNION ALL

 SELECT 4050, 23, 'Igrejinha' FROM dual
 UNION ALL

 SELECT 4051, 23, 'Ijuí' FROM dual
 UNION ALL

 SELECT 4052, 23, 'Ilópolis' FROM dual
 UNION ALL

 SELECT 4053, 23, 'Imbé' FROM dual
 UNION ALL

 SELECT 4054, 23, 'Imigrante' FROM dual
 UNION ALL

 SELECT 4055, 23, 'Independência' FROM dual
 UNION ALL

 SELECT 4056, 23, 'Inhacorá' FROM dual
 UNION ALL

 SELECT 4057, 23, 'Ipê' FROM dual
 UNION ALL

 SELECT 4058, 23, 'Ipiranga do Sul' FROM dual
 UNION ALL

 SELECT 4059, 23, 'Iraí' FROM dual
 UNION ALL

 SELECT 4060, 23, 'Itaara' FROM dual
 UNION ALL

 SELECT 4061, 23, 'Itacurubi' FROM dual
 UNION ALL

 SELECT 4062, 23, 'Itapuca' FROM dual
 UNION ALL

 SELECT 4063, 23, 'Itaqui' FROM dual
 UNION ALL

 SELECT 4064, 23, 'Itati' FROM dual
 UNION ALL

 SELECT 4065, 23, 'Itatiba do Sul' FROM dual
 UNION ALL

 SELECT 4066, 23, 'Ivorá' FROM dual
 UNION ALL

 SELECT 4067, 23, 'Ivoti' FROM dual
 UNION ALL

 SELECT 4068, 23, 'Jaboticaba' FROM dual
 UNION ALL

 SELECT 4069, 23, 'Jacuizinho' FROM dual
 UNION ALL

 SELECT 4070, 23, 'Jacutinga' FROM dual
 UNION ALL

 SELECT 4071, 23, 'Jaguarão' FROM dual
 UNION ALL

 SELECT 4072, 23, 'Jaguari' FROM dual
 UNION ALL

 SELECT 4073, 23, 'Jaquirana' FROM dual
 UNION ALL

 SELECT 4074, 23, 'Jari' FROM dual
 UNION ALL

 SELECT 4075, 23, 'Jóia' FROM dual
 UNION ALL

 SELECT 4076, 23, 'Júlio de Castilhos' FROM dual
 UNION ALL

 SELECT 4077, 23, 'Lagoa Bonita do Sul' FROM dual
 UNION ALL

 SELECT 4078, 23, 'Lagoa dos Três Cantos' FROM dual
 UNION ALL

 SELECT 4079, 23, 'Lagoa Vermelha' FROM dual
 UNION ALL

 SELECT 4080, 23, 'Lagoão' FROM dual
 UNION ALL

 SELECT 4081, 23, 'Lajeado' FROM dual
 UNION ALL

 SELECT 4082, 23, 'Lajeado do Bugre' FROM dual
 UNION ALL

 SELECT 4083, 23, 'Lavras do Sul' FROM dual
 UNION ALL

 SELECT 4084, 23, 'Liberato Salzano' FROM dual
 UNION ALL

 SELECT 4085, 23, 'Lindolfo Collor' FROM dual
 UNION ALL

 SELECT 4086, 23, 'Linha Nova' FROM dual
 UNION ALL

 SELECT 4087, 23, 'Maçambara' FROM dual
 UNION ALL

 SELECT 4088, 23, 'Machadinho' FROM dual
 UNION ALL

 SELECT 4089, 23, 'Mampituba' FROM dual
 UNION ALL

 SELECT 4090, 23, 'Manoel Viana' FROM dual
 UNION ALL

 SELECT 4091, 23, 'Maquiné' FROM dual
 UNION ALL

 SELECT 4092, 23, 'Maratá' FROM dual
 UNION ALL

 SELECT 4093, 23, 'Marau' FROM dual
 UNION ALL

 SELECT 4094, 23, 'Marcelino Ramos' FROM dual
 UNION ALL

 SELECT 4095, 23, 'Mariana Pimentel' FROM dual
 UNION ALL

 SELECT 4096, 23, 'Mariano Moro' FROM dual
 UNION ALL

 SELECT 4097, 23, 'Marques de Souza' FROM dual
 UNION ALL

 SELECT 4098, 23, 'Mata' FROM dual
 UNION ALL

 SELECT 4099, 23, 'Mato Castelhano' FROM dual
 UNION ALL

 SELECT 4100, 23, 'Mato Leitão' FROM dual
 UNION ALL

 SELECT 4101, 23, 'Mato Queimado' FROM dual
 UNION ALL

 SELECT 4102, 23, 'Maximiliano de Almeida' FROM dual
 UNION ALL

 SELECT 4103, 23, 'Minas do Leão' FROM dual
 UNION ALL

 SELECT 4104, 23, 'Miraguaí' FROM dual
 UNION ALL

 SELECT 4105, 23, 'Montauri' FROM dual
 UNION ALL

 SELECT 4106, 23, 'Monte Alegre dos Campos' FROM dual
 UNION ALL

 SELECT 4107, 23, 'Monte Belo do Sul' FROM dual
 UNION ALL

 SELECT 4108, 23, 'Montenegro' FROM dual
 UNION ALL

 SELECT 4109, 23, 'Mormaço' FROM dual
 UNION ALL

 SELECT 4110, 23, 'Morrinhos do Sul' FROM dual
 UNION ALL

 SELECT 4111, 23, 'Morro Redondo' FROM dual
 UNION ALL

 SELECT 4112, 23, 'Morro Reuter' FROM dual
 UNION ALL

 SELECT 4113, 23, 'Mostardas' FROM dual
 UNION ALL

 SELECT 4114, 23, 'Muçum' FROM dual
 UNION ALL

 SELECT 4115, 23, 'Muitos Capões' FROM dual
 UNION ALL

 SELECT 4116, 23, 'Muliterno' FROM dual
 UNION ALL

 SELECT 4117, 23, 'Não-Me-Toque' FROM dual
 UNION ALL

 SELECT 4118, 23, 'Nicolau Vergueiro' FROM dual
 UNION ALL

 SELECT 4119, 23, 'Nonoai' FROM dual
 UNION ALL

 SELECT 4120, 23, 'Nova Alvorada' FROM dual
 UNION ALL

 SELECT 4121, 23, 'Nova Araçá' FROM dual
 UNION ALL

 SELECT 4122, 23, 'Nova Bassano' FROM dual
 UNION ALL

 SELECT 4123, 23, 'Nova Boa Vista' FROM dual
 UNION ALL

 SELECT 4124, 23, 'Nova Bréscia' FROM dual
 UNION ALL

 SELECT 4125, 23, 'Nova Candelária' FROM dual
 UNION ALL

 SELECT 4126, 23, 'Nova Esperança do Sul' FROM dual
 UNION ALL

 SELECT 4127, 23, 'Nova Hartz' FROM dual
 UNION ALL

 SELECT 4128, 23, 'Nova Pádua' FROM dual
 UNION ALL

 SELECT 4129, 23, 'Nova Palma' FROM dual
 UNION ALL

 SELECT 4130, 23, 'Nova Petrópolis' FROM dual
 UNION ALL

 SELECT 4131, 23, 'Nova Prata' FROM dual
 UNION ALL

 SELECT 4132, 23, 'Nova Ramada' FROM dual
 UNION ALL

 SELECT 4133, 23, 'Nova Roma do Sul' FROM dual
 UNION ALL

 SELECT 4134, 23, 'Nova Santa Rita' FROM dual
 UNION ALL

 SELECT 4135, 23, 'Novo Barreiro' FROM dual
 UNION ALL

 SELECT 4136, 23, 'Novo Cabrais' FROM dual
 UNION ALL

 SELECT 4137, 23, 'Novo Hamburgo' FROM dual
 UNION ALL

 SELECT 4138, 23, 'Novo Machado' FROM dual
 UNION ALL

 SELECT 4139, 23, 'Novo Tiradentes' FROM dual
 UNION ALL

 SELECT 4140, 23, 'Novo Xingu' FROM dual
 UNION ALL

 SELECT 4141, 23, 'Osório' FROM dual
 UNION ALL

 SELECT 4142, 23, 'Paim Filho' FROM dual
 UNION ALL

 SELECT 4143, 23, 'Palmares do Sul' FROM dual
 UNION ALL

 SELECT 4144, 23, 'Palmeira das Missões' FROM dual
 UNION ALL

 SELECT 4145, 23, 'Palmitinho' FROM dual
 UNION ALL

 SELECT 4146, 23, 'Panambi' FROM dual
 UNION ALL

 SELECT 4147, 23, 'Pantano Grande' FROM dual
 UNION ALL

 SELECT 4148, 23, 'Paraí' FROM dual
 UNION ALL

 SELECT 4149, 23, 'Paraíso do Sul' FROM dual
 UNION ALL

 SELECT 4150, 23, 'Pareci Novo' FROM dual
 UNION ALL

 SELECT 4151, 23, 'Parobé' FROM dual
 UNION ALL

 SELECT 4152, 23, 'Passa Sete' FROM dual
 UNION ALL

 SELECT 4153, 23, 'Passo do Sobrado' FROM dual
 UNION ALL

 SELECT 4154, 23, 'Passo Fundo' FROM dual
 UNION ALL

 SELECT 4155, 23, 'Paulo Bento' FROM dual
 UNION ALL

 SELECT 4156, 23, 'Paverama' FROM dual
 UNION ALL

 SELECT 4157, 23, 'Pedras Altas' FROM dual
 UNION ALL

 SELECT 4158, 23, 'Pedro Osório' FROM dual
 UNION ALL

 SELECT 4159, 23, 'Pejuçara' FROM dual
 UNION ALL

 SELECT 4160, 23, 'Pelotas' FROM dual
 UNION ALL

 SELECT 4161, 23, 'Picada Café' FROM dual
 UNION ALL

 SELECT 4162, 23, 'Pinhal' FROM dual
 UNION ALL

 SELECT 4163, 23, 'Pinhal da Serra' FROM dual
 UNION ALL

 SELECT 4164, 23, 'Pinhal Grande' FROM dual
 UNION ALL

 SELECT 4165, 23, 'Pinheirinho do Vale' FROM dual
 UNION ALL

 SELECT 4166, 23, 'Pinheiro Machado' FROM dual
 UNION ALL

 SELECT 4167, 23, 'Pirapó' FROM dual
 UNION ALL

 SELECT 4168, 23, 'Piratini' FROM dual
 UNION ALL

 SELECT 4169, 23, 'Planalto' FROM dual
 UNION ALL

 SELECT 4170, 23, 'Poço das Antas' FROM dual
 UNION ALL

 SELECT 4171, 23, 'Pontão' FROM dual
 UNION ALL

 SELECT 4172, 23, 'Ponte Preta' FROM dual
 UNION ALL

 SELECT 4173, 23, 'Portão' FROM dual
 UNION ALL

 SELECT 4174, 23, 'Porto Alegre' FROM dual
 UNION ALL

 SELECT 4175, 23, 'Porto Lucena' FROM dual
 UNION ALL

 SELECT 4176, 23, 'Porto Mauá' FROM dual
 UNION ALL

 SELECT 4177, 23, 'Porto Vera Cruz' FROM dual
 UNION ALL

 SELECT 4178, 23, 'Porto Xavier' FROM dual
 UNION ALL

 SELECT 4179, 23, 'Pouso Novo' FROM dual
 UNION ALL

 SELECT 4180, 23, 'Presidente Lucena' FROM dual
 UNION ALL

 SELECT 4181, 23, 'Progresso' FROM dual
 UNION ALL

 SELECT 4182, 23, 'Protásio Alves' FROM dual
 UNION ALL

 SELECT 4183, 23, 'Putinga' FROM dual
 UNION ALL

 SELECT 4184, 23, 'Quaraí' FROM dual
 UNION ALL

 SELECT 4185, 23, 'Quatro Irmãos' FROM dual
 UNION ALL

 SELECT 4186, 23, 'Quevedos' FROM dual
 UNION ALL

 SELECT 4187, 23, 'Quinze de Novembro' FROM dual
 UNION ALL

 SELECT 4188, 23, 'Redentora' FROM dual
 UNION ALL

 SELECT 4189, 23, 'Relvado' FROM dual
 UNION ALL

 SELECT 4190, 23, 'Restinga Seca' FROM dual
 UNION ALL

 SELECT 4191, 23, 'Rio dos Índios' FROM dual
 UNION ALL

 SELECT 4192, 23, 'Rio Grande' FROM dual
 UNION ALL

 SELECT 4193, 23, 'Rio Pardo' FROM dual
 UNION ALL

 SELECT 4194, 23, 'Riozinho' FROM dual
 UNION ALL

 SELECT 4195, 23, 'Roca Sales' FROM dual
 UNION ALL

 SELECT 4196, 23, 'Rodeio Bonito' FROM dual
 UNION ALL

 SELECT 4197, 23, 'Rolador' FROM dual
 UNION ALL

 SELECT 4198, 23, 'Rolante' FROM dual
 UNION ALL

 SELECT 4199, 23, 'Ronda Alta' FROM dual
 UNION ALL

 SELECT 4200, 23, 'Rondinha' FROM dual
 UNION ALL

 SELECT 4201, 23, 'Roque Gonzales' FROM dual
 UNION ALL

 SELECT 4202, 23, 'Rosário do Sul' FROM dual
 UNION ALL

 SELECT 4203, 23, 'Sagrada Família' FROM dual
 UNION ALL

 SELECT 4204, 23, 'Saldanha Marinho' FROM dual
 UNION ALL

 SELECT 4205, 23, 'Salto do Jacuí' FROM dual
 UNION ALL

 SELECT 4206, 23, 'Salvador das Missões' FROM dual
 UNION ALL

 SELECT 4207, 23, 'Salvador do Sul' FROM dual
 UNION ALL

 SELECT 4208, 23, 'Sananduva' FROM dual
 UNION ALL

 SELECT 4209, 23, 'Santa Bárbara do Sul' FROM dual
 UNION ALL

 SELECT 4210, 23, 'Santa Cecília do Sul' FROM dual
 UNION ALL

 SELECT 4211, 23, 'Santa Clara do Sul' FROM dual
 UNION ALL

 SELECT 4212, 23, 'Santa Cruz do Sul' FROM dual
 UNION ALL

 SELECT 4213, 23, 'Santa Margarida do Sul' FROM dual
 UNION ALL

 SELECT 4214, 23, 'Santa Maria' FROM dual
 UNION ALL

 SELECT 4215, 23, 'Santa Maria do Herval' FROM dual
 UNION ALL

 SELECT 4216, 23, 'Santa Rosa' FROM dual
 UNION ALL

 SELECT 4217, 23, 'Santa Tereza' FROM dual
 UNION ALL

 SELECT 4218, 23, 'Santa Vitória do Palmar' FROM dual
 UNION ALL

 SELECT 4219, 23, 'Santana da Boa Vista' FROM dual
 UNION ALL

 SELECT 4220, 23, 'Santana do Livramento' FROM dual
 UNION ALL

 SELECT 4221, 23, 'Santiago' FROM dual
 UNION ALL

 SELECT 4222, 23, 'Santo Ângelo' FROM dual
 UNION ALL

 SELECT 4223, 23, 'Santo Antônio da Patrulha' FROM dual
 UNION ALL

 SELECT 4224, 23, 'Santo Antônio das Missões' FROM dual
 UNION ALL

 SELECT 4225, 23, 'Santo Antônio do Palma' FROM dual
 UNION ALL

 SELECT 4226, 23, 'Santo Antônio do Planalto' FROM dual
 UNION ALL

 SELECT 4227, 23, 'Santo Augusto' FROM dual
 UNION ALL

 SELECT 4228, 23, 'Santo Cristo' FROM dual
 UNION ALL

 SELECT 4229, 23, 'Santo Expedito do Sul' FROM dual
 UNION ALL

 SELECT 4230, 23, 'São Borja' FROM dual
 UNION ALL

 SELECT 4231, 23, 'São Domingos do Sul' FROM dual
 UNION ALL

 SELECT 4232, 23, 'São Francisco de Assis' FROM dual
 UNION ALL

 SELECT 4233, 23, 'São Francisco de Paula' FROM dual
 UNION ALL

 SELECT 4234, 23, 'São Gabriel' FROM dual
 UNION ALL

 SELECT 4235, 23, 'São Jerônimo' FROM dual
 UNION ALL

 SELECT 4236, 23, 'São João da Urtiga' FROM dual
 UNION ALL

 SELECT 4237, 23, 'São João do Polêsine' FROM dual
 UNION ALL

 SELECT 4238, 23, 'São Jorge' FROM dual
 UNION ALL

 SELECT 4239, 23, 'São José das Missões' FROM dual
 UNION ALL

 SELECT 4240, 23, 'São José do Herval' FROM dual
 UNION ALL

 SELECT 4241, 23, 'São José do Hortêncio' FROM dual
 UNION ALL

 SELECT 4242, 23, 'São José do Inhacorá' FROM dual
 UNION ALL

 SELECT 4243, 23, 'São José do Norte' FROM dual
 UNION ALL

 SELECT 4244, 23, 'São José do Ouro' FROM dual
 UNION ALL

 SELECT 4245, 23, 'São José do Sul' FROM dual
 UNION ALL

 SELECT 4246, 23, 'São José dos Ausentes' FROM dual
 UNION ALL

 SELECT 4247, 23, 'São Leopoldo' FROM dual
 UNION ALL

 SELECT 4248, 23, 'São Lourenço do Sul' FROM dual
 UNION ALL

 SELECT 4249, 23, 'São Luiz Gonzaga' FROM dual
 UNION ALL

 SELECT 4250, 23, 'São Marcos' FROM dual
 UNION ALL

 SELECT 4251, 23, 'São Martinho' FROM dual
 UNION ALL

 SELECT 4252, 23, 'São Martinho da Serra' FROM dual
 UNION ALL

 SELECT 4253, 23, 'São Miguel das Missões' FROM dual
 UNION ALL

 SELECT 4254, 23, 'São Nicolau' FROM dual
 UNION ALL

 SELECT 4255, 23, 'São Paulo das Missões' FROM dual
 UNION ALL

 SELECT 4256, 23, 'São Pedro da Serra' FROM dual
 UNION ALL

 SELECT 4257, 23, 'São Pedro das Missões' FROM dual
 UNION ALL

 SELECT 4258, 23, 'São Pedro do Butiá' FROM dual
 UNION ALL

 SELECT 4259, 23, 'São Pedro do Sul' FROM dual
 UNION ALL

 SELECT 4260, 23, 'São Sebastião do Caí' FROM dual
 UNION ALL

 SELECT 4261, 23, 'São Sepé' FROM dual
 UNION ALL

 SELECT 4262, 23, 'São Valentim' FROM dual
 UNION ALL

 SELECT 4263, 23, 'São Valentim do Sul' FROM dual
 UNION ALL

 SELECT 4264, 23, 'São Valério do Sul' FROM dual
 UNION ALL

 SELECT 4265, 23, 'São Vendelino' FROM dual
 UNION ALL

 SELECT 4266, 23, 'São Vicente do Sul' FROM dual
 UNION ALL

 SELECT 4267, 23, 'Sapiranga' FROM dual
 UNION ALL

 SELECT 4268, 23, 'Sapucaia do Sul' FROM dual
 UNION ALL

 SELECT 4269, 23, 'Sarandi' FROM dual
 UNION ALL

 SELECT 4270, 23, 'Seberi' FROM dual
 UNION ALL

 SELECT 4271, 23, 'Sede Nova' FROM dual
 UNION ALL

 SELECT 4272, 23, 'Segredo' FROM dual
 UNION ALL

 SELECT 4273, 23, 'Selbach' FROM dual
 UNION ALL

 SELECT 4274, 23, 'Senador Salgado Filho' FROM dual
 UNION ALL

 SELECT 4275, 23, 'Sentinela do Sul' FROM dual
 UNION ALL

 SELECT 4276, 23, 'Serafina Corrêa' FROM dual
 UNION ALL

 SELECT 4277, 23, 'Sério' FROM dual
 UNION ALL

 SELECT 4278, 23, 'Sertão' FROM dual
 UNION ALL

 SELECT 4279, 23, 'Sertão Santana' FROM dual
 UNION ALL

 SELECT 4280, 23, 'Sete de Setembro' FROM dual
 UNION ALL

 SELECT 4281, 23, 'Severiano de Almeida' FROM dual
 UNION ALL

 SELECT 4282, 23, 'Silveira Martins' FROM dual
 UNION ALL

 SELECT 4283, 23, 'Sinimbu' FROM dual
 UNION ALL

 SELECT 4284, 23, 'Sobradinho' FROM dual
 UNION ALL

 SELECT 4285, 23, 'Soledade' FROM dual
 UNION ALL

 SELECT 4286, 23, 'Tabaí' FROM dual
 UNION ALL

 SELECT 4287, 23, 'Tapejara' FROM dual
 UNION ALL

 SELECT 4288, 23, 'Tapera' FROM dual
 UNION ALL

 SELECT 4289, 23, 'Tapes' FROM dual
 UNION ALL

 SELECT 4290, 23, 'Taquara' FROM dual
 UNION ALL

 SELECT 4291, 23, 'Taquari' FROM dual
 UNION ALL

 SELECT 4292, 23, 'Taquaruçu do Sul' FROM dual
 UNION ALL

 SELECT 4293, 23, 'Tavares' FROM dual
 UNION ALL

 SELECT 4294, 23, 'Tenente Portela' FROM dual
 UNION ALL

 SELECT 4295, 23, 'Terra de Areia' FROM dual
 UNION ALL

 SELECT 4296, 23, 'Teutônia' FROM dual
 UNION ALL

 SELECT 4297, 23, 'Tio Hugo' FROM dual
 UNION ALL

 SELECT 4298, 23, 'Tiradentes do Sul' FROM dual
 UNION ALL

 SELECT 4299, 23, 'Toropi' FROM dual
 UNION ALL

 SELECT 4300, 23, 'Torres' FROM dual
 UNION ALL

 SELECT 4301, 23, 'Tramandaí' FROM dual
 UNION ALL

 SELECT 4302, 23, 'Travesseiro' FROM dual
 UNION ALL

 SELECT 4303, 23, 'Três Arroios' FROM dual
 UNION ALL

 SELECT 4304, 23, 'Três Cachoeiras' FROM dual
 UNION ALL

 SELECT 4305, 23, 'Três Coroas' FROM dual
 UNION ALL

 SELECT 4306, 23, 'Três de Maio' FROM dual
 UNION ALL

 SELECT 4307, 23, 'Três Forquilhas' FROM dual
 UNION ALL

 SELECT 4308, 23, 'Três Palmeiras' FROM dual
 UNION ALL

 SELECT 4309, 23, 'Três Passos' FROM dual
 UNION ALL

 SELECT 4310, 23, 'Trindade do Sul' FROM dual
 UNION ALL

 SELECT 4311, 23, 'Triunfo' FROM dual
 UNION ALL

 SELECT 4312, 23, 'Tucunduva' FROM dual
 UNION ALL

 SELECT 4313, 23, 'Tunas' FROM dual
 UNION ALL

 SELECT 4314, 23, 'Tupanci do Sul' FROM dual
 UNION ALL

 SELECT 4315, 23, 'Tupanciretã' FROM dual
 UNION ALL

 SELECT 4316, 23, 'Tupandi' FROM dual
 UNION ALL

 SELECT 4317, 23, 'Tuparendi' FROM dual
 UNION ALL

 SELECT 4318, 23, 'Turuçu' FROM dual
 UNION ALL

 SELECT 4319, 23, 'Ubiretama' FROM dual
 UNION ALL

 SELECT 4320, 23, 'União da Serra' FROM dual
 UNION ALL

 SELECT 4321, 23, 'Unistalda' FROM dual
 UNION ALL

 SELECT 4322, 23, 'Uruguaiana' FROM dual
 UNION ALL

 SELECT 4323, 23, 'Vacaria' FROM dual
 UNION ALL

 SELECT 4324, 23, 'Vale do Sol' FROM dual
 UNION ALL

 SELECT 4325, 23, 'Vale Real' FROM dual
 UNION ALL

 SELECT 4326, 23, 'Vale Verde' FROM dual
 UNION ALL

 SELECT 4327, 23, 'Vanini' FROM dual
 UNION ALL

 SELECT 4328, 23, 'Venâncio Aires' FROM dual
 UNION ALL

 SELECT 4329, 23, 'Vera Cruz' FROM dual
 UNION ALL

 SELECT 4330, 23, 'Veranópolis' FROM dual
 UNION ALL

 SELECT 4331, 23, 'Vespasiano Correa' FROM dual
 UNION ALL

 SELECT 4332, 23, 'Viadutos' FROM dual
 UNION ALL

 SELECT 4333, 23, 'Viamão' FROM dual
 UNION ALL

 SELECT 4334, 23, 'Vicente Dutra' FROM dual
 UNION ALL

 SELECT 4335, 23, 'Victor Graeff' FROM dual
 UNION ALL

 SELECT 4336, 23, 'Vila Flores' FROM dual
 UNION ALL

 SELECT 4337, 23, 'Vila Lângaro' FROM dual
 UNION ALL

 SELECT 4338, 23, 'Vila Maria' FROM dual
 UNION ALL

 SELECT 4339, 23, 'Vila Nova do Sul' FROM dual
 UNION ALL

 SELECT 4340, 23, 'Vista Alegre' FROM dual
 UNION ALL

 SELECT 4341, 23, 'Vista Alegre do Prata' FROM dual
 UNION ALL

 SELECT 4342, 23, 'Vista Gaúcha' FROM dual
 UNION ALL

 SELECT 4343, 23, 'Vitória das Missões' FROM dual
 UNION ALL

 SELECT 4344, 23, 'Westfália' FROM dual
 UNION ALL

 SELECT 4345, 23, 'Xangri-lá' FROM dual
 UNION ALL

 SELECT 4346, 21, 'Alta Floresta d`Oeste' FROM dual
 UNION ALL

 SELECT 4347, 21, 'Alto Alegre dos Parecis' FROM dual
 UNION ALL

 SELECT 4348, 21, 'Alto Paraíso' FROM dual
 UNION ALL

 SELECT 4349, 21, 'Alvorada d`Oeste' FROM dual
 UNION ALL

 SELECT 4350, 21, 'Ariquemes' FROM dual
 UNION ALL

 SELECT 4351, 21, 'Buritis' FROM dual
 UNION ALL

 SELECT 4352, 21, 'Cabixi' FROM dual
 UNION ALL

 SELECT 4353, 21, 'Cacaulândia' FROM dual
 UNION ALL

 SELECT 4354, 21, 'Cacoal' FROM dual
 UNION ALL

 SELECT 4355, 21, 'Campo Novo de Rondônia' FROM dual
 UNION ALL

 SELECT 4356, 21, 'Candeias do Jamari' FROM dual
 UNION ALL

 SELECT 4357, 21, 'Castanheiras' FROM dual
 UNION ALL

 SELECT 4358, 21, 'Cerejeiras' FROM dual
 UNION ALL

 SELECT 4359, 21, 'Chupinguaia' FROM dual
 UNION ALL

 SELECT 4360, 21, 'Colorado do Oeste' FROM dual
 UNION ALL

 SELECT 4361, 21, 'Corumbiara' FROM dual
 UNION ALL

 SELECT 4362, 21, 'Costa Marques' FROM dual
 UNION ALL

 SELECT 4363, 21, 'Cujubim' FROM dual
 UNION ALL

 SELECT 4364, 21, 'Espigão d`Oeste' FROM dual
 UNION ALL

 SELECT 4365, 21, 'Governador Jorge Teixeira' FROM dual
 UNION ALL

 SELECT 4366, 21, 'Guajará-Mirim' FROM dual
 UNION ALL

 SELECT 4367, 21, 'Itapuã do Oeste' FROM dual
 UNION ALL

 SELECT 4368, 21, 'Jaru' FROM dual
 UNION ALL

 SELECT 4369, 21, 'Ji-Paraná' FROM dual
 UNION ALL

 SELECT 4370, 21, 'Machadinho d`Oeste' FROM dual
 UNION ALL

 SELECT 4371, 21, 'Ministro Andreazza' FROM dual
 UNION ALL

 SELECT 4372, 21, 'Mirante da Serra' FROM dual
 UNION ALL

 SELECT 4373, 21, 'Monte Negro' FROM dual
 UNION ALL

 SELECT 4374, 21, 'Nova Brasilândia d`Oeste' FROM dual
 UNION ALL

 SELECT 4375, 21, 'Nova Mamoré' FROM dual
 UNION ALL

 SELECT 4376, 21, 'Nova União' FROM dual
 UNION ALL

 SELECT 4377, 21, 'Novo Horizonte do Oeste' FROM dual
 UNION ALL

 SELECT 4378, 21, 'Ouro Preto do Oeste' FROM dual
 UNION ALL

 SELECT 4379, 21, 'Parecis' FROM dual
 UNION ALL

 SELECT 4380, 21, 'Pimenta Bueno' FROM dual
 UNION ALL

 SELECT 4381, 21, 'Pimenteiras do Oeste' FROM dual
 UNION ALL

 SELECT 4382, 21, 'Porto Velho' FROM dual
 UNION ALL

 SELECT 4383, 21, 'Presidente Médici' FROM dual
 UNION ALL

 SELECT 4384, 21, 'Primavera de Rondônia' FROM dual
 UNION ALL

 SELECT 4385, 21, 'Rio Crespo' FROM dual
 UNION ALL

 SELECT 4386, 21, 'Rolim de Moura' FROM dual
 UNION ALL

 SELECT 4387, 21, 'Santa Luzia d`Oeste' FROM dual
 UNION ALL

 SELECT 4388, 21, 'São Felipe d`Oeste' FROM dual
 UNION ALL

 SELECT 4389, 21, 'São Francisco do Guaporé' FROM dual
 UNION ALL

 SELECT 4390, 21, 'São Miguel do Guaporé' FROM dual
 UNION ALL

 SELECT 4391, 21, 'Seringueiras' FROM dual
 UNION ALL

 SELECT 4392, 21, 'Teixeirópolis' FROM dual
 UNION ALL

 SELECT 4393, 21, 'Theobroma' FROM dual
 UNION ALL

 SELECT 4394, 21, 'Urupá' FROM dual
 UNION ALL

 SELECT 4395, 21, 'Vale do Anari' FROM dual
 UNION ALL

 SELECT 4396, 21, 'Vale do Paraíso' FROM dual
 UNION ALL

 SELECT 4397, 21, 'Vilhena' FROM dual
 UNION ALL

 SELECT 4398, 22, 'Alto Alegre' FROM dual
 UNION ALL

 SELECT 4399, 22, 'Amajari' FROM dual
 UNION ALL

 SELECT 4400, 22, 'Boa Vista' FROM dual
 UNION ALL

 SELECT 4401, 22, 'Bonfim' FROM dual
 UNION ALL

 SELECT 4402, 22, 'Cantá' FROM dual
 UNION ALL

 SELECT 4403, 22, 'Caracaraí' FROM dual
 UNION ALL

 SELECT 4404, 22, 'Caroebe' FROM dual
 UNION ALL

 SELECT 4405, 22, 'Iracema' FROM dual
 UNION ALL

 SELECT 4406, 22, 'Mucajaí' FROM dual
 UNION ALL

 SELECT 4407, 22, 'Normandia' FROM dual
 UNION ALL

 SELECT 4408, 22, 'Pacaraima' FROM dual
 UNION ALL

 SELECT 4409, 22, 'Rorainópolis' FROM dual
 UNION ALL

 SELECT 4410, 22, 'São João da Baliza' FROM dual
 UNION ALL

 SELECT 4411, 22, 'São Luiz' FROM dual
 UNION ALL

 SELECT 4412, 22, 'Uiramutã' FROM dual
 UNION ALL

 SELECT 4413, 24, 'Abdon Batista' FROM dual
 UNION ALL

 SELECT 4414, 24, 'Abelardo Luz' FROM dual
 UNION ALL

 SELECT 4415, 24, 'Agrolândia' FROM dual
 UNION ALL

 SELECT 4416, 24, 'Agronômica' FROM dual
 UNION ALL

 SELECT 4417, 24, 'Água Doce' FROM dual
 UNION ALL

 SELECT 4418, 24, 'Águas de Chapecó' FROM dual
 UNION ALL

 SELECT 4419, 24, 'Águas Frias' FROM dual
 UNION ALL

 SELECT 4420, 24, 'Águas Mornas' FROM dual
 UNION ALL

 SELECT 4421, 24, 'Alfredo Wagner' FROM dual
 UNION ALL

 SELECT 4422, 24, 'Alto Bela Vista' FROM dual
 UNION ALL

 SELECT 4423, 24, 'Anchieta' FROM dual
 UNION ALL

 SELECT 4424, 24, 'Angelina' FROM dual
 UNION ALL

 SELECT 4425, 24, 'Anita Garibaldi' FROM dual
 UNION ALL

 SELECT 4426, 24, 'Anitápolis' FROM dual
 UNION ALL

 SELECT 4427, 24, 'Antônio Carlos' FROM dual
 UNION ALL

 SELECT 4428, 24, 'Apiúna' FROM dual
 UNION ALL

 SELECT 4429, 24, 'Arabutã' FROM dual
 UNION ALL

 SELECT 4430, 24, 'Araquari' FROM dual
 UNION ALL

 SELECT 4431, 24, 'Araranguá' FROM dual
 UNION ALL

 SELECT 4432, 24, 'Armazém' FROM dual
 UNION ALL

 SELECT 4433, 24, 'Arroio Trinta' FROM dual
 UNION ALL

 SELECT 4434, 24, 'Arvoredo' FROM dual
 UNION ALL

 SELECT 4435, 24, 'Ascurra' FROM dual
 UNION ALL

 SELECT 4436, 24, 'Atalanta' FROM dual
 UNION ALL

 SELECT 4437, 24, 'Aurora' FROM dual
 UNION ALL

 SELECT 4438, 24, 'Balneário Arroio do Silva' FROM dual
 UNION ALL

 SELECT 4439, 24, 'Balneário Barra do Sul' FROM dual
 UNION ALL

 SELECT 4440, 24, 'Balneário Camboriú' FROM dual
 UNION ALL

 SELECT 4441, 24, 'Balneário Gaivota' FROM dual
 UNION ALL

 SELECT 4442, 24, 'Bandeirante' FROM dual
 UNION ALL

 SELECT 4443, 24, 'Barra Bonita' FROM dual
 UNION ALL

 SELECT 4444, 24, 'Barra Velha' FROM dual
 UNION ALL

 SELECT 4445, 24, 'Bela Vista do Toldo' FROM dual
 UNION ALL

 SELECT 4446, 24, 'Belmonte' FROM dual
 UNION ALL

 SELECT 4447, 24, 'Benedito Novo' FROM dual
 UNION ALL

 SELECT 4448, 24, 'Biguaçu' FROM dual
 UNION ALL

 SELECT 4449, 24, 'Blumenau' FROM dual
 UNION ALL

 SELECT 4450, 24, 'Bocaina do Sul' FROM dual
 UNION ALL

 SELECT 4451, 24, 'Bom Jardim da Serra' FROM dual
 UNION ALL

 SELECT 4452, 24, 'Bom Jesus' FROM dual
 UNION ALL

 SELECT 4453, 24, 'Bom Jesus do Oeste' FROM dual
 UNION ALL

 SELECT 4454, 24, 'Bom Retiro' FROM dual
 UNION ALL

 SELECT 4455, 24, 'Bombinhas' FROM dual
 UNION ALL

 SELECT 4456, 24, 'Botuverá' FROM dual
 UNION ALL

 SELECT 4457, 24, 'Braço do Norte' FROM dual
 UNION ALL

 SELECT 4458, 24, 'Braço do Trombudo' FROM dual
 UNION ALL

 SELECT 4459, 24, 'Brunópolis' FROM dual
 UNION ALL

 SELECT 4460, 24, 'Brusque' FROM dual
 UNION ALL

 SELECT 4461, 24, 'Caçador' FROM dual
 UNION ALL

 SELECT 4462, 24, 'Caibi' FROM dual
 UNION ALL

 SELECT 4463, 24, 'Calmon' FROM dual
 UNION ALL

 SELECT 4464, 24, 'Camboriú' FROM dual
 UNION ALL

 SELECT 4465, 24, 'Campo Alegre' FROM dual
 UNION ALL

 SELECT 4466, 24, 'Campo Belo do Sul' FROM dual
 UNION ALL

 SELECT 4467, 24, 'Campo Erê' FROM dual
 UNION ALL

 SELECT 4468, 24, 'Campos Novos' FROM dual
 UNION ALL

 SELECT 4469, 24, 'Canelinha' FROM dual
 UNION ALL

 SELECT 4470, 24, 'Canoinhas' FROM dual
 UNION ALL

 SELECT 4471, 24, 'Capão Alto' FROM dual
 UNION ALL

 SELECT 4472, 24, 'Capinzal' FROM dual
 UNION ALL

 SELECT 4473, 24, 'Capivari de Baixo' FROM dual
 UNION ALL

 SELECT 4474, 24, 'Catanduvas' FROM dual
 UNION ALL

 SELECT 4475, 24, 'Caxambu do Sul' FROM dual
 UNION ALL

 SELECT 4476, 24, 'Celso Ramos' FROM dual
 UNION ALL

 SELECT 4477, 24, 'Cerro Negro' FROM dual
 UNION ALL

 SELECT 4478, 24, 'Chapadão do Lageado' FROM dual
 UNION ALL

 SELECT 4479, 24, 'Chapecó' FROM dual
 UNION ALL

 SELECT 4480, 24, 'Cocal do Sul' FROM dual
 UNION ALL

 SELECT 4481, 24, 'Concórdia' FROM dual
 UNION ALL

 SELECT 4482, 24, 'Cordilheira Alta' FROM dual
 UNION ALL

 SELECT 4483, 24, 'Coronel Freitas' FROM dual
 UNION ALL

 SELECT 4484, 24, 'Coronel Martins' FROM dual
 UNION ALL

 SELECT 4485, 24, 'Correia Pinto' FROM dual
 UNION ALL

 SELECT 4486, 24, 'Corupá' FROM dual
 UNION ALL

 SELECT 4487, 24, 'Criciúma' FROM dual
 UNION ALL

 SELECT 4488, 24, 'Cunha Porã' FROM dual
 UNION ALL

 SELECT 4489, 24, 'Cunhataí' FROM dual
 UNION ALL

 SELECT 4490, 24, 'Curitibanos' FROM dual
 UNION ALL

 SELECT 4491, 24, 'Descanso' FROM dual
 UNION ALL

 SELECT 4492, 24, 'Dionísio Cerqueira' FROM dual
 UNION ALL

 SELECT 4493, 24, 'Dona Emma' FROM dual
 UNION ALL

 SELECT 4494, 24, 'Doutor Pedrinho' FROM dual
 UNION ALL

 SELECT 4495, 24, 'Entre Rios' FROM dual
 UNION ALL

 SELECT 4496, 24, 'Ermo' FROM dual
 UNION ALL

 SELECT 4497, 24, 'Erval Velho' FROM dual
 UNION ALL

 SELECT 4498, 24, 'Faxinal dos Guedes' FROM dual
 UNION ALL

 SELECT 4499, 24, 'Flor do Sertão' FROM dual
 UNION ALL

 SELECT 4500, 24, 'Florianópolis' FROM dual
 UNION ALL

 SELECT 4501, 24, 'Formosa do Sul' FROM dual
 UNION ALL

 SELECT 4502, 24, 'Forquilhinha' FROM dual
 UNION ALL

 SELECT 4503, 24, 'Fraiburgo' FROM dual
 UNION ALL

 SELECT 4504, 24, 'Frei Rogério' FROM dual
 UNION ALL

 SELECT 4505, 24, 'Galvão' FROM dual
 UNION ALL

 SELECT 4506, 24, 'Garopaba' FROM dual
 UNION ALL

 SELECT 4507, 24, 'Garuva' FROM dual
 UNION ALL

 SELECT 4508, 24, 'Gaspar' FROM dual
 UNION ALL

 SELECT 4509, 24, 'Governador Celso Ramos' FROM dual
 UNION ALL

 SELECT 4510, 24, 'Grão Pará' FROM dual
 UNION ALL

 SELECT 4511, 24, 'Gravatal' FROM dual
 UNION ALL

 SELECT 4512, 24, 'Guabiruba' FROM dual
 UNION ALL

 SELECT 4513, 24, 'Guaraciaba' FROM dual
 UNION ALL

 SELECT 4514, 24, 'Guaramirim' FROM dual
 UNION ALL

 SELECT 4515, 24, 'Guarujá do Sul' FROM dual
 UNION ALL

 SELECT 4516, 24, 'Guatambú' FROM dual
 UNION ALL

 SELECT 4517, 24, 'Herval d`Oeste' FROM dual
 UNION ALL

 SELECT 4518, 24, 'Ibiam' FROM dual
 UNION ALL

 SELECT 4519, 24, 'Ibicaré' FROM dual
 UNION ALL

 SELECT 4520, 24, 'Ibirama' FROM dual
 UNION ALL

 SELECT 4521, 24, 'Içara' FROM dual
 UNION ALL

 SELECT 4522, 24, 'Ilhota' FROM dual
 UNION ALL

 SELECT 4523, 24, 'Imaruí' FROM dual
 UNION ALL

 SELECT 4524, 24, 'Imbituba' FROM dual
 UNION ALL

 SELECT 4525, 24, 'Imbuia' FROM dual
 UNION ALL

 SELECT 4526, 24, 'Indaial' FROM dual
 UNION ALL

 SELECT 4527, 24, 'Iomerê' FROM dual
 UNION ALL

 SELECT 4528, 24, 'Ipira' FROM dual
 UNION ALL

 SELECT 4529, 24, 'Iporã do Oeste' FROM dual
 UNION ALL

 SELECT 4530, 24, 'Ipuaçu' FROM dual
 UNION ALL

 SELECT 4531, 24, 'Ipumirim' FROM dual
 UNION ALL

 SELECT 4532, 24, 'Iraceminha' FROM dual
 UNION ALL

 SELECT 4533, 24, 'Irani' FROM dual
 UNION ALL

 SELECT 4534, 24, 'Irati' FROM dual
 UNION ALL

 SELECT 4535, 24, 'Irineópolis' FROM dual
 UNION ALL

 SELECT 4536, 24, 'Itá' FROM dual
 UNION ALL

 SELECT 4537, 24, 'Itaiópolis' FROM dual
 UNION ALL

 SELECT 4538, 24, 'Itajaí' FROM dual
 UNION ALL

 SELECT 4539, 24, 'Itapema' FROM dual
 UNION ALL

 SELECT 4540, 24, 'Itapiranga' FROM dual
 UNION ALL

 SELECT 4541, 24, 'Itapoá' FROM dual
 UNION ALL

 SELECT 4542, 24, 'Ituporanga' FROM dual
 UNION ALL

 SELECT 4543, 24, 'Jaborá' FROM dual
 UNION ALL

 SELECT 4544, 24, 'Jacinto Machado' FROM dual
 UNION ALL

 SELECT 4545, 24, 'Jaguaruna' FROM dual
 UNION ALL

 SELECT 4546, 24, 'Jaraguá do Sul' FROM dual
 UNION ALL

 SELECT 4547, 24, 'Jardinópolis' FROM dual
 UNION ALL

 SELECT 4548, 24, 'Joaçaba' FROM dual
 UNION ALL

 SELECT 4549, 24, 'Joinville' FROM dual
 UNION ALL

 SELECT 4550, 24, 'José Boiteux' FROM dual
 UNION ALL

 SELECT 4551, 24, 'Jupiá' FROM dual
 UNION ALL

 SELECT 4552, 24, 'Lacerdópolis' FROM dual
 UNION ALL

 SELECT 4553, 24, 'Lages' FROM dual
 UNION ALL

 SELECT 4554, 24, 'Laguna' FROM dual
 UNION ALL

 SELECT 4555, 24, 'Lajeado Grande' FROM dual
 UNION ALL

 SELECT 4556, 24, 'Laurentino' FROM dual
 UNION ALL

 SELECT 4557, 24, 'Lauro Muller' FROM dual
 UNION ALL

 SELECT 4558, 24, 'Lebon Régis' FROM dual
 UNION ALL

 SELECT 4559, 24, 'Leoberto Leal' FROM dual
 UNION ALL

 SELECT 4560, 24, 'Lindóia do Sul' FROM dual
 UNION ALL

 SELECT 4561, 24, 'Lontras' FROM dual
 UNION ALL

 SELECT 4562, 24, 'Luiz Alves' FROM dual
 UNION ALL

 SELECT 4563, 24, 'Luzerna' FROM dual
 UNION ALL

 SELECT 4564, 24, 'Macieira' FROM dual
 UNION ALL

 SELECT 4565, 24, 'Mafra' FROM dual
 UNION ALL

 SELECT 4566, 24, 'Major Gercino' FROM dual
 UNION ALL

 SELECT 4567, 24, 'Major Vieira' FROM dual
 UNION ALL

 SELECT 4568, 24, 'Maracajá' FROM dual
 UNION ALL

 SELECT 4569, 24, 'Maravilha' FROM dual
 UNION ALL

 SELECT 4570, 24, 'Marema' FROM dual
 UNION ALL

 SELECT 4571, 24, 'Massaranduba' FROM dual
 UNION ALL

 SELECT 4572, 24, 'Matos Costa' FROM dual
 UNION ALL

 SELECT 4573, 24, 'Meleiro' FROM dual
 UNION ALL

 SELECT 4574, 24, 'Mirim Doce' FROM dual
 UNION ALL

 SELECT 4575, 24, 'Modelo' FROM dual
 UNION ALL

 SELECT 4576, 24, 'Mondaí' FROM dual
 UNION ALL

 SELECT 4577, 24, 'Monte Carlo' FROM dual
 UNION ALL

 SELECT 4578, 24, 'Monte Castelo' FROM dual
 UNION ALL

 SELECT 4579, 24, 'Morro da Fumaça' FROM dual
 UNION ALL

 SELECT 4580, 24, 'Morro Grande' FROM dual
 UNION ALL

 SELECT 4581, 24, 'Navegantes' FROM dual
 UNION ALL

 SELECT 4582, 24, 'Nova Erechim' FROM dual
 UNION ALL

 SELECT 4583, 24, 'Nova Itaberaba' FROM dual
 UNION ALL

 SELECT 4584, 24, 'Nova Trento' FROM dual
 UNION ALL

 SELECT 4585, 24, 'Nova Veneza' FROM dual
 UNION ALL

 SELECT 4586, 24, 'Novo Horizonte' FROM dual
 UNION ALL

 SELECT 4587, 24, 'Orleans' FROM dual
 UNION ALL

 SELECT 4588, 24, 'Otacílio Costa' FROM dual
 UNION ALL

 SELECT 4589, 24, 'Ouro' FROM dual
 UNION ALL

 SELECT 4590, 24, 'Ouro Verde' FROM dual
 UNION ALL

 SELECT 4591, 24, 'Paial' FROM dual
 UNION ALL

 SELECT 4592, 24, 'Painel' FROM dual
 UNION ALL

 SELECT 4593, 24, 'Palhoça' FROM dual
 UNION ALL

 SELECT 4594, 24, 'Palma Sola' FROM dual
 UNION ALL

 SELECT 4595, 24, 'Palmeira' FROM dual
 UNION ALL

 SELECT 4596, 24, 'Palmitos' FROM dual
 UNION ALL

 SELECT 4597, 24, 'Papanduva' FROM dual
 UNION ALL

 SELECT 4598, 24, 'Paraíso' FROM dual
 UNION ALL

 SELECT 4599, 24, 'Passo de Torres' FROM dual
 UNION ALL

 SELECT 4600, 24, 'Passos Maia' FROM dual
 UNION ALL

 SELECT 4601, 24, 'Paulo Lopes' FROM dual
 UNION ALL

 SELECT 4602, 24, 'Pedras Grandes' FROM dual
 UNION ALL

 SELECT 4603, 24, 'Penha' FROM dual
 UNION ALL

 SELECT 4604, 24, 'Peritiba' FROM dual
 UNION ALL

 SELECT 4605, 24, 'Petrolândia' FROM dual
 UNION ALL

 SELECT 4606, 24, 'Piçarras' FROM dual
 UNION ALL

 SELECT 4607, 24, 'Pinhalzinho' FROM dual
 UNION ALL

 SELECT 4608, 24, 'Pinheiro Preto' FROM dual
 UNION ALL

 SELECT 4609, 24, 'Piratuba' FROM dual
 UNION ALL

 SELECT 4610, 24, 'Planalto Alegre' FROM dual
 UNION ALL

 SELECT 4611, 24, 'Pomerode' FROM dual
 UNION ALL

 SELECT 4612, 24, 'Ponte Alta' FROM dual
 UNION ALL

 SELECT 4613, 24, 'Ponte Alta do Norte' FROM dual
 UNION ALL

 SELECT 4614, 24, 'Ponte Serrada' FROM dual
 UNION ALL

 SELECT 4615, 24, 'Porto Belo' FROM dual
 UNION ALL

 SELECT 4616, 24, 'Porto União' FROM dual
 UNION ALL

 SELECT 4617, 24, 'Pouso Redondo' FROM dual
 UNION ALL

 SELECT 4618, 24, 'Praia Grande' FROM dual
 UNION ALL

 SELECT 4619, 24, 'Presidente Castelo Branco' FROM dual
 UNION ALL

 SELECT 4620, 24, 'Presidente Getúlio' FROM dual
 UNION ALL

 SELECT 4621, 24, 'Presidente Nereu' FROM dual
 UNION ALL

 SELECT 4622, 24, 'Princesa' FROM dual
 UNION ALL

 SELECT 4623, 24, 'Quilombo' FROM dual
 UNION ALL

 SELECT 4624, 24, 'Rancho Queimado' FROM dual
 UNION ALL

 SELECT 4625, 24, 'Rio das Antas' FROM dual
 UNION ALL

 SELECT 4626, 24, 'Rio do Campo' FROM dual
 UNION ALL

 SELECT 4627, 24, 'Rio do Oeste' FROM dual
 UNION ALL

 SELECT 4628, 24, 'Rio do Sul' FROM dual
 UNION ALL

 SELECT 4629, 24, 'Rio dos Cedros' FROM dual
 UNION ALL

 SELECT 4630, 24, 'Rio Fortuna' FROM dual
 UNION ALL

 SELECT 4631, 24, 'Rio Negrinho' FROM dual
 UNION ALL

 SELECT 4632, 24, 'Rio Rufino' FROM dual
 UNION ALL

 SELECT 4633, 24, 'Riqueza' FROM dual
 UNION ALL

 SELECT 4634, 24, 'Rodeio' FROM dual
 UNION ALL

 SELECT 4635, 24, 'Romelândia' FROM dual
 UNION ALL

 SELECT 4636, 24, 'Salete' FROM dual
 UNION ALL

 SELECT 4637, 24, 'Saltinho' FROM dual
 UNION ALL

 SELECT 4638, 24, 'Salto Veloso' FROM dual
 UNION ALL

 SELECT 4639, 24, 'Sangão' FROM dual
 UNION ALL

 SELECT 4640, 24, 'Santa Cecília' FROM dual
 UNION ALL

 SELECT 4641, 24, 'Santa Helena' FROM dual
 UNION ALL

 SELECT 4642, 24, 'Santa Rosa de Lima' FROM dual
 UNION ALL

 SELECT 4643, 24, 'Santa Rosa do Sul' FROM dual
 UNION ALL

 SELECT 4644, 24, 'Santa Terezinha' FROM dual
 UNION ALL

 SELECT 4645, 24, 'Santa Terezinha do Progresso' FROM dual
 UNION ALL

 SELECT 4646, 24, 'Santiago do Sul' FROM dual
 UNION ALL

 SELECT 4647, 24, 'Santo Amaro da Imperatriz' FROM dual
 UNION ALL

 SELECT 4648, 24, 'São Bento do Sul' FROM dual
 UNION ALL

 SELECT 4649, 24, 'São Bernardino' FROM dual
 UNION ALL

 SELECT 4650, 24, 'São Bonifácio' FROM dual
 UNION ALL

 SELECT 4651, 24, 'São Carlos' FROM dual
 UNION ALL

 SELECT 4652, 24, 'São Cristovão do Sul' FROM dual
 UNION ALL

 SELECT 4653, 24, 'São Domingos' FROM dual
 UNION ALL

 SELECT 4654, 24, 'São Francisco do Sul' FROM dual
 UNION ALL

 SELECT 4655, 24, 'São João Batista' FROM dual
 UNION ALL

 SELECT 4656, 24, 'São João do Itaperiú' FROM dual
 UNION ALL

 SELECT 4657, 24, 'São João do Oeste' FROM dual
 UNION ALL

 SELECT 4658, 24, 'São João do Sul' FROM dual
 UNION ALL

 SELECT 4659, 24, 'São Joaquim' FROM dual
 UNION ALL

 SELECT 4660, 24, 'São José' FROM dual
 UNION ALL

 SELECT 4661, 24, 'São José do Cedro' FROM dual
 UNION ALL

 SELECT 4662, 24, 'São José do Cerrito' FROM dual
 UNION ALL

 SELECT 4663, 24, 'São Lourenço do Oeste' FROM dual
 UNION ALL

 SELECT 4664, 24, 'São Ludgero' FROM dual
 UNION ALL

 SELECT 4665, 24, 'São Martinho' FROM dual
 UNION ALL

 SELECT 4666, 24, 'São Miguel da Boa Vista' FROM dual
 UNION ALL

 SELECT 4667, 24, 'São Miguel do Oeste' FROM dual
 UNION ALL

 SELECT 4668, 24, 'São Pedro de Alcântara' FROM dual
 UNION ALL

 SELECT 4669, 24, 'Saudades' FROM dual
 UNION ALL

 SELECT 4670, 24, 'Schroeder' FROM dual
 UNION ALL

 SELECT 4671, 24, 'Seara' FROM dual
 UNION ALL

 SELECT 4672, 24, 'Serra Alta' FROM dual
 UNION ALL

 SELECT 4673, 24, 'Siderópolis' FROM dual
 UNION ALL

 SELECT 4674, 24, 'Sombrio' FROM dual
 UNION ALL

 SELECT 4675, 24, 'Sul Brasil' FROM dual
 UNION ALL

 SELECT 4676, 24, 'Taió' FROM dual
 UNION ALL

 SELECT 4677, 24, 'Tangará' FROM dual
 UNION ALL

 SELECT 4678, 24, 'Tigrinhos' FROM dual
 UNION ALL

 SELECT 4679, 24, 'Tijucas' FROM dual
 UNION ALL

 SELECT 4680, 24, 'Timbé do Sul' FROM dual
 UNION ALL

 SELECT 4681, 24, 'Timbó' FROM dual
 UNION ALL

 SELECT 4682, 24, 'Timbó Grande' FROM dual
 UNION ALL

 SELECT 4683, 24, 'Três Barras' FROM dual
 UNION ALL

 SELECT 4684, 24, 'Treviso' FROM dual
 UNION ALL

 SELECT 4685, 24, 'Treze de Maio' FROM dual
 UNION ALL

 SELECT 4686, 24, 'Treze Tílias' FROM dual
 UNION ALL

 SELECT 4687, 24, 'Trombudo Central' FROM dual
 UNION ALL

 SELECT 4688, 24, 'Tubarão' FROM dual
 UNION ALL

 SELECT 4689, 24, 'Tunápolis' FROM dual
 UNION ALL

 SELECT 4690, 24, 'Turvo' FROM dual
 UNION ALL

 SELECT 4691, 24, 'União do Oeste' FROM dual
 UNION ALL

 SELECT 4692, 24, 'Urubici' FROM dual
 UNION ALL

 SELECT 4693, 24, 'Urupema' FROM dual
 UNION ALL

 SELECT 4694, 24, 'Urussanga' FROM dual
 UNION ALL

 SELECT 4695, 24, 'Vargeão' FROM dual
 UNION ALL

 SELECT 4696, 24, 'Vargem' FROM dual
 UNION ALL

 SELECT 4697, 24, 'Vargem Bonita' FROM dual
 UNION ALL

 SELECT 4698, 24, 'Vidal Ramos' FROM dual
 UNION ALL

 SELECT 4699, 24, 'Videira' FROM dual
 UNION ALL

 SELECT 4700, 24, 'Vitor Meireles' FROM dual
 UNION ALL

 SELECT 4701, 24, 'Witmarsum' FROM dual
 UNION ALL

 SELECT 4702, 24, 'Xanxerê' FROM dual
 UNION ALL

 SELECT 4703, 24, 'Xavantina' FROM dual
 UNION ALL

 SELECT 4704, 24, 'Xaxim' FROM dual
 UNION ALL

 SELECT 4705, 24, 'Zortéa' FROM dual
 UNION ALL

 SELECT 4706, 26, 'Adamantina' FROM dual
 UNION ALL

 SELECT 4707, 26, 'Adolfo' FROM dual
 UNION ALL

 SELECT 4708, 26, 'Aguaí' FROM dual
 UNION ALL

 SELECT 4709, 26, 'Águas da Prata' FROM dual
 UNION ALL

 SELECT 4710, 26, 'Águas de Lindóia' FROM dual
 UNION ALL

 SELECT 4711, 26, 'Águas de Santa Bárbara' FROM dual
 UNION ALL

 SELECT 4712, 26, 'Águas de São Pedro' FROM dual
 UNION ALL

 SELECT 4713, 26, 'Agudos' FROM dual
 UNION ALL

 SELECT 4714, 26, 'Alambari' FROM dual
 UNION ALL

 SELECT 4715, 26, 'Alfredo Marcondes' FROM dual
 UNION ALL

 SELECT 4716, 26, 'Altair' FROM dual
 UNION ALL

 SELECT 4717, 26, 'Altinópolis' FROM dual
 UNION ALL

 SELECT 4718, 26, 'Alto Alegre' FROM dual
 UNION ALL

 SELECT 4719, 26, 'Alumínio' FROM dual
 UNION ALL

 SELECT 4720, 26, 'Álvares Florence' FROM dual
 UNION ALL

 SELECT 4721, 26, 'Álvares Machado' FROM dual
 UNION ALL

 SELECT 4722, 26, 'Álvaro de Carvalho' FROM dual
 UNION ALL

 SELECT 4723, 26, 'Alvinlândia' FROM dual
 UNION ALL

 SELECT 4724, 26, 'Americana' FROM dual
 UNION ALL

 SELECT 4725, 26, 'Américo Brasiliense' FROM dual
 UNION ALL

 SELECT 4726, 26, 'Américo de Campos' FROM dual
 UNION ALL

 SELECT 4727, 26, 'Amparo' FROM dual
 UNION ALL

 SELECT 4728, 26, 'Analândia' FROM dual
 UNION ALL

 SELECT 4729, 26, 'Andradina' FROM dual
 UNION ALL

 SELECT 4730, 26, 'Angatuba' FROM dual
 UNION ALL

 SELECT 4731, 26, 'Anhembi' FROM dual
 UNION ALL

 SELECT 4732, 26, 'Anhumas' FROM dual
 UNION ALL

 SELECT 4733, 26, 'Aparecida' FROM dual
 UNION ALL

 SELECT 4734, 26, 'Aparecida d`Oeste' FROM dual
 UNION ALL

 SELECT 4735, 26, 'Apiaí' FROM dual
 UNION ALL

 SELECT 4736, 26, 'Araçariguama' FROM dual
 UNION ALL

 SELECT 4737, 26, 'Araçatuba' FROM dual
 UNION ALL

 SELECT 4738, 26, 'Araçoiaba da Serra' FROM dual
 UNION ALL

 SELECT 4739, 26, 'Aramina' FROM dual
 UNION ALL

 SELECT 4740, 26, 'Arandu' FROM dual
 UNION ALL

 SELECT 4741, 26, 'Arapeí' FROM dual
 UNION ALL

 SELECT 4742, 26, 'Araraquara' FROM dual
 UNION ALL

 SELECT 4743, 26, 'Araras' FROM dual
 UNION ALL

 SELECT 4744, 26, 'Arco-Íris' FROM dual
 UNION ALL

 SELECT 4745, 26, 'Arealva' FROM dual
 UNION ALL

 SELECT 4746, 26, 'Areias' FROM dual
 UNION ALL

 SELECT 4747, 26, 'Areiópolis' FROM dual
 UNION ALL

 SELECT 4748, 26, 'Ariranha' FROM dual
 UNION ALL

 SELECT 4749, 26, 'Artur Nogueira' FROM dual
 UNION ALL

 SELECT 4750, 26, 'Arujá' FROM dual
 UNION ALL

 SELECT 4751, 26, 'Aspásia' FROM dual
 UNION ALL

 SELECT 4752, 26, 'Assis' FROM dual
 UNION ALL

 SELECT 4753, 26, 'Atibaia' FROM dual
 UNION ALL

 SELECT 4754, 26, 'Auriflama' FROM dual
 UNION ALL

 SELECT 4755, 26, 'Avaí' FROM dual
 UNION ALL

 SELECT 4756, 26, 'Avanhandava' FROM dual
 UNION ALL

 SELECT 4757, 26, 'Avaré' FROM dual
 UNION ALL

 SELECT 4758, 26, 'Bady Bassitt' FROM dual
 UNION ALL

 SELECT 4759, 26, 'Balbinos' FROM dual
 UNION ALL

 SELECT 4760, 26, 'Bálsamo' FROM dual
 UNION ALL

 SELECT 4761, 26, 'Bananal' FROM dual
 UNION ALL

 SELECT 4762, 26, 'Barão de Antonina' FROM dual
 UNION ALL

 SELECT 4763, 26, 'Barbosa' FROM dual
 UNION ALL

 SELECT 4764, 26, 'Bariri' FROM dual
 UNION ALL

 SELECT 4765, 26, 'Barra Bonita' FROM dual
 UNION ALL

 SELECT 4766, 26, 'Barra do Chapéu' FROM dual
 UNION ALL

 SELECT 4767, 26, 'Barra do Turvo' FROM dual
 UNION ALL

 SELECT 4768, 26, 'Barretos' FROM dual
 UNION ALL

 SELECT 4769, 26, 'Barrinha' FROM dual
 UNION ALL

 SELECT 4770, 26, 'Barueri' FROM dual
 UNION ALL

 SELECT 4771, 26, 'Bastos' FROM dual
 UNION ALL

 SELECT 4772, 26, 'Batatais' FROM dual
 UNION ALL

 SELECT 4773, 26, 'Bauru' FROM dual
 UNION ALL

 SELECT 4774, 26, 'Bebedouro' FROM dual
 UNION ALL

 SELECT 4775, 26, 'Bento de Abreu' FROM dual
 UNION ALL

 SELECT 4776, 26, 'Bernardino de Campos' FROM dual
 UNION ALL

 SELECT 4777, 26, 'Bertioga' FROM dual
 UNION ALL

 SELECT 4778, 26, 'Bilac' FROM dual
 UNION ALL

 SELECT 4779, 26, 'Birigui' FROM dual
 UNION ALL

 SELECT 4780, 26, 'Biritiba-Mirim' FROM dual
 UNION ALL

 SELECT 4781, 26, 'Boa Esperança do Sul' FROM dual
 UNION ALL

 SELECT 4782, 26, 'Bocaina' FROM dual
 UNION ALL

 SELECT 4783, 26, 'Bofete' FROM dual
 UNION ALL

 SELECT 4784, 26, 'Boituva' FROM dual
 UNION ALL

 SELECT 4785, 26, 'Bom Jesus dos Perdões' FROM dual
 UNION ALL

 SELECT 4786, 26, 'Bom Sucesso de Itararé' FROM dual
 UNION ALL

 SELECT 4787, 26, 'Borá' FROM dual
 UNION ALL

 SELECT 4788, 26, 'Boracéia' FROM dual
 UNION ALL

 SELECT 4789, 26, 'Borborema' FROM dual
 UNION ALL

 SELECT 4790, 26, 'Borebi' FROM dual
 UNION ALL

 SELECT 4791, 26, 'Botucatu' FROM dual
 UNION ALL

 SELECT 4792, 26, 'Bragança Paulista' FROM dual
 UNION ALL

 SELECT 4793, 26, 'Braúna' FROM dual
 UNION ALL

 SELECT 4794, 26, 'Brejo Alegre' FROM dual
 UNION ALL

 SELECT 4795, 26, 'Brodowski' FROM dual
 UNION ALL

 SELECT 4796, 26, 'Brotas' FROM dual
 UNION ALL

 SELECT 4797, 26, 'Buri' FROM dual
 UNION ALL

 SELECT 4798, 26, 'Buritama' FROM dual
 UNION ALL

 SELECT 4799, 26, 'Buritizal' FROM dual
 UNION ALL

 SELECT 4800, 26, 'Cabrália Paulista' FROM dual
 UNION ALL

 SELECT 4801, 26, 'Cabreúva' FROM dual
 UNION ALL

 SELECT 4802, 26, 'Caçapava' FROM dual
 UNION ALL

 SELECT 4803, 26, 'Cachoeira Paulista' FROM dual
 UNION ALL

 SELECT 4804, 26, 'Caconde' FROM dual
 UNION ALL

 SELECT 4805, 26, 'Cafelândia' FROM dual
 UNION ALL

 SELECT 4806, 26, 'Caiabu' FROM dual
 UNION ALL

 SELECT 4807, 26, 'Caieiras' FROM dual
 UNION ALL

 SELECT 4808, 26, 'Caiuá' FROM dual
 UNION ALL

 SELECT 4809, 26, 'Cajamar' FROM dual
 UNION ALL

 SELECT 4810, 26, 'Cajati' FROM dual
 UNION ALL

 SELECT 4811, 26, 'Cajobi' FROM dual
 UNION ALL

 SELECT 4812, 26, 'Cajuru' FROM dual
 UNION ALL

 SELECT 4813, 26, 'Campina do Monte Alegre' FROM dual
 UNION ALL

 SELECT 4814, 26, 'Campinas' FROM dual
 UNION ALL

 SELECT 4815, 26, 'Campo Limpo Paulista' FROM dual
 UNION ALL

 SELECT 4816, 26, 'Campos do Jordão' FROM dual
 UNION ALL

 SELECT 4817, 26, 'Campos Novos Paulista' FROM dual
 UNION ALL

 SELECT 4818, 26, 'Cananéia' FROM dual
 UNION ALL

 SELECT 4819, 26, 'Canas' FROM dual
 UNION ALL

 SELECT 4820, 26, 'Cândido Mota' FROM dual
 UNION ALL

 SELECT 4821, 26, 'Cândido Rodrigues' FROM dual
 UNION ALL

 SELECT 4822, 26, 'Canitar' FROM dual
 UNION ALL

 SELECT 4823, 26, 'Capão Bonito' FROM dual
 UNION ALL

 SELECT 4824, 26, 'Capela do Alto' FROM dual
 UNION ALL

 SELECT 4825, 26, 'Capivari' FROM dual
 UNION ALL

 SELECT 4826, 26, 'Caraguatatuba' FROM dual
 UNION ALL

 SELECT 4827, 26, 'Carapicuíba' FROM dual
 UNION ALL

 SELECT 4828, 26, 'Cardoso' FROM dual
 UNION ALL

 SELECT 4829, 26, 'Casa Branca' FROM dual
 UNION ALL

 SELECT 4830, 26, 'Cássia dos Coqueiros' FROM dual
 UNION ALL

 SELECT 4831, 26, 'Castilho' FROM dual
 UNION ALL

 SELECT 4832, 26, 'Catanduva' FROM dual
 UNION ALL

 SELECT 4833, 26, 'Catiguá' FROM dual
 UNION ALL

 SELECT 4834, 26, 'Cedral' FROM dual
 UNION ALL

 SELECT 4835, 26, 'Cerqueira César' FROM dual
 UNION ALL

 SELECT 4836, 26, 'Cerquilho' FROM dual
 UNION ALL

 SELECT 4837, 26, 'Cesário Lange' FROM dual
 UNION ALL

 SELECT 4838, 26, 'Charqueada' FROM dual
 UNION ALL

 SELECT 4839, 26, 'Chavantes' FROM dual
 UNION ALL

 SELECT 4840, 26, 'Clementina' FROM dual
 UNION ALL

 SELECT 4841, 26, 'Colina' FROM dual
 UNION ALL

 SELECT 4842, 26, 'Colômbia' FROM dual
 UNION ALL

 SELECT 4843, 26, 'Conchal' FROM dual
 UNION ALL

 SELECT 4844, 26, 'Conchas' FROM dual
 UNION ALL

 SELECT 4845, 26, 'Cordeirópolis' FROM dual
 UNION ALL

 SELECT 4846, 26, 'Coroados' FROM dual
 UNION ALL

 SELECT 4847, 26, 'Coronel Macedo' FROM dual
 UNION ALL

 SELECT 4848, 26, 'Corumbataí' FROM dual
 UNION ALL

 SELECT 4849, 26, 'Cosmópolis' FROM dual
 UNION ALL

 SELECT 4850, 26, 'Cosmorama' FROM dual
 UNION ALL

 SELECT 4851, 26, 'Cotia' FROM dual
 UNION ALL

 SELECT 4852, 26, 'Cravinhos' FROM dual
 UNION ALL

 SELECT 4853, 26, 'Cristais Paulista' FROM dual
 UNION ALL

 SELECT 4854, 26, 'Cruzália' FROM dual
 UNION ALL

 SELECT 4855, 26, 'Cruzeiro' FROM dual
 UNION ALL

 SELECT 4856, 26, 'Cubatão' FROM dual
 UNION ALL

 SELECT 4857, 26, 'Cunha' FROM dual
 UNION ALL

 SELECT 4858, 26, 'Descalvado' FROM dual
 UNION ALL

 SELECT 4859, 26, 'Diadema' FROM dual
 UNION ALL

 SELECT 4860, 26, 'Dirce Reis' FROM dual
 UNION ALL

 SELECT 4861, 26, 'Divinolândia' FROM dual
 UNION ALL

 SELECT 4862, 26, 'Dobrada' FROM dual
 UNION ALL

 SELECT 4863, 26, 'Dois Córregos' FROM dual
 UNION ALL

 SELECT 4864, 26, 'Dolcinópolis' FROM dual
 UNION ALL

 SELECT 4865, 26, 'Dourado' FROM dual
 UNION ALL

 SELECT 4866, 26, 'Dracena' FROM dual
 UNION ALL

 SELECT 4867, 26, 'Duartina' FROM dual
 UNION ALL

 SELECT 4868, 26, 'Dumont' FROM dual
 UNION ALL

 SELECT 4869, 26, 'Echaporã' FROM dual
 UNION ALL

 SELECT 4870, 26, 'Eldorado' FROM dual
 UNION ALL

 SELECT 4871, 26, 'Elias Fausto' FROM dual
 UNION ALL

 SELECT 4872, 26, 'Elisiário' FROM dual
 UNION ALL

 SELECT 4873, 26, 'Embaúba' FROM dual
 UNION ALL

 SELECT 4874, 26, 'Embu' FROM dual
 UNION ALL

 SELECT 4875, 26, 'Embu-Guaçu' FROM dual
 UNION ALL

 SELECT 4876, 26, 'Emilianópolis' FROM dual
 UNION ALL

 SELECT 4877, 26, 'Engenheiro Coelho' FROM dual
 UNION ALL

 SELECT 4878, 26, 'Espírito Santo do Pinhal' FROM dual
 UNION ALL

 SELECT 4879, 26, 'Espírito Santo do Turvo' FROM dual
 UNION ALL

 SELECT 4880, 26, 'Estiva Gerbi' FROM dual
 UNION ALL

 SELECT 4881, 26, 'Estrela d`Oeste' FROM dual
 UNION ALL

 SELECT 4882, 26, 'Estrela do Norte' FROM dual
 UNION ALL

 SELECT 4883, 26, 'Euclides da Cunha Paulista' FROM dual
 UNION ALL

 SELECT 4884, 26, 'Fartura' FROM dual
 UNION ALL

 SELECT 4885, 26, 'Fernando Prestes' FROM dual
 UNION ALL

 SELECT 4886, 26, 'Fernandópolis' FROM dual
 UNION ALL

 SELECT 4887, 26, 'Fernão' FROM dual
 UNION ALL

 SELECT 4888, 26, 'Ferraz de Vasconcelos' FROM dual
 UNION ALL

 SELECT 4889, 26, 'Flora Rica' FROM dual
 UNION ALL

 SELECT 4890, 26, 'Floreal' FROM dual
 UNION ALL

 SELECT 4891, 26, 'Flórida Paulista' FROM dual
 UNION ALL

 SELECT 4892, 26, 'Florínia' FROM dual
 UNION ALL

 SELECT 4893, 26, 'Franca' FROM dual
 UNION ALL

 SELECT 4894, 26, 'Francisco Morato' FROM dual
 UNION ALL

 SELECT 4895, 26, 'Franco da Rocha' FROM dual
 UNION ALL

 SELECT 4896, 26, 'Gabriel Monteiro' FROM dual
 UNION ALL

 SELECT 4897, 26, 'Gália' FROM dual
 UNION ALL

 SELECT 4898, 26, 'Garça' FROM dual
 UNION ALL

 SELECT 4899, 26, 'Gastão Vidigal' FROM dual
 UNION ALL

 SELECT 4900, 26, 'Gavião Peixoto' FROM dual
 UNION ALL

 SELECT 4901, 26, 'General Salgado' FROM dual
 UNION ALL

 SELECT 4902, 26, 'Getulina' FROM dual
 UNION ALL

 SELECT 4903, 26, 'Glicério' FROM dual
 UNION ALL

 SELECT 4904, 26, 'Guaiçara' FROM dual
 UNION ALL

 SELECT 4905, 26, 'Guaimbê' FROM dual
 UNION ALL

 SELECT 4906, 26, 'Guaíra' FROM dual
 UNION ALL

 SELECT 4907, 26, 'Guapiaçu' FROM dual
 UNION ALL

 SELECT 4908, 26, 'Guapiara' FROM dual
 UNION ALL

 SELECT 4909, 26, 'Guará' FROM dual
 UNION ALL

 SELECT 4910, 26, 'Guaraçaí' FROM dual
 UNION ALL

 SELECT 4911, 26, 'Guaraci' FROM dual
 UNION ALL

 SELECT 4912, 26, 'Guarani d`Oeste' FROM dual
 UNION ALL

 SELECT 4913, 26, 'Guarantã' FROM dual
 UNION ALL

 SELECT 4914, 26, 'Guararapes' FROM dual
 UNION ALL

 SELECT 4915, 26, 'Guararema' FROM dual
 UNION ALL

 SELECT 4916, 26, 'Guaratinguetá' FROM dual
 UNION ALL

 SELECT 4917, 26, 'Guareí' FROM dual
 UNION ALL

 SELECT 4918, 26, 'Guariba' FROM dual
 UNION ALL

 SELECT 4919, 26, 'Guarujá' FROM dual
 UNION ALL

 SELECT 4920, 26, 'Guarulhos' FROM dual
 UNION ALL

 SELECT 4921, 26, 'Guatapará' FROM dual
 UNION ALL

 SELECT 4922, 26, 'Guzolândia' FROM dual
 UNION ALL

 SELECT 4923, 26, 'Herculândia' FROM dual
 UNION ALL

 SELECT 4924, 26, 'Holambra' FROM dual
 UNION ALL

 SELECT 4925, 26, 'Hortolândia' FROM dual
 UNION ALL

 SELECT 4926, 26, 'Iacanga' FROM dual
 UNION ALL

 SELECT 4927, 26, 'Iacri' FROM dual
 UNION ALL

 SELECT 4928, 26, 'Iaras' FROM dual
 UNION ALL

 SELECT 4929, 26, 'Ibaté' FROM dual
 UNION ALL

 SELECT 4930, 26, 'Ibirá' FROM dual
 UNION ALL

 SELECT 4931, 26, 'Ibirarema' FROM dual
 UNION ALL

 SELECT 4932, 26, 'Ibitinga' FROM dual
 UNION ALL

 SELECT 4933, 26, 'Ibiúna' FROM dual
 UNION ALL

 SELECT 4934, 26, 'Icém' FROM dual
 UNION ALL

 SELECT 4935, 26, 'Iepê' FROM dual
 UNION ALL

 SELECT 4936, 26, 'Igaraçu do Tietê' FROM dual
 UNION ALL

 SELECT 4937, 26, 'Igarapava' FROM dual
 UNION ALL

 SELECT 4938, 26, 'Igaratá' FROM dual
 UNION ALL

 SELECT 4939, 26, 'Iguape' FROM dual
 UNION ALL

 SELECT 4940, 26, 'Ilha Comprida' FROM dual
 UNION ALL

 SELECT 4941, 26, 'Ilha Solteira' FROM dual
 UNION ALL

 SELECT 4942, 26, 'Ilhabela' FROM dual
 UNION ALL

 SELECT 4943, 26, 'Indaiatuba' FROM dual
 UNION ALL

 SELECT 4944, 26, 'Indiana' FROM dual
 UNION ALL

 SELECT 4945, 26, 'Indiaporã' FROM dual
 UNION ALL

 SELECT 4946, 26, 'Inúbia Paulista' FROM dual
 UNION ALL

 SELECT 4947, 26, 'Ipaussu' FROM dual
 UNION ALL

 SELECT 4948, 26, 'Iperó' FROM dual
 UNION ALL

 SELECT 4949, 26, 'Ipeúna' FROM dual
 UNION ALL

 SELECT 4950, 26, 'Ipiguá' FROM dual
 UNION ALL

 SELECT 4951, 26, 'Iporanga' FROM dual
 UNION ALL

 SELECT 4952, 26, 'Ipuã' FROM dual
 UNION ALL

 SELECT 4953, 26, 'Iracemápolis' FROM dual
 UNION ALL

 SELECT 4954, 26, 'Irapuã' FROM dual
 UNION ALL

 SELECT 4955, 26, 'Irapuru' FROM dual
 UNION ALL

 SELECT 4956, 26, 'Itaberá' FROM dual
 UNION ALL

 SELECT 4957, 26, 'Itaí' FROM dual
 UNION ALL

 SELECT 4958, 26, 'Itajobi' FROM dual
 UNION ALL

 SELECT 4959, 26, 'Itaju' FROM dual
 UNION ALL

 SELECT 4960, 26, 'Itanhaém' FROM dual
 UNION ALL

 SELECT 4961, 26, 'Itaóca' FROM dual
 UNION ALL

 SELECT 4962, 26, 'Itapecerica da Serra' FROM dual
 UNION ALL

 SELECT 4963, 26, 'Itapetininga' FROM dual
 UNION ALL

 SELECT 4964, 26, 'Itapeva' FROM dual
 UNION ALL

 SELECT 4965, 26, 'Itapevi' FROM dual
 UNION ALL

 SELECT 4966, 26, 'Itapira' FROM dual
 UNION ALL

 SELECT 4967, 26, 'Itapirapuã Paulista' FROM dual
 UNION ALL

 SELECT 4968, 26, 'Itápolis' FROM dual
 UNION ALL

 SELECT 4969, 26, 'Itaporanga' FROM dual
 UNION ALL

 SELECT 4970, 26, 'Itapuí' FROM dual
 UNION ALL

 SELECT 4971, 26, 'Itapura' FROM dual
 UNION ALL

 SELECT 4972, 26, 'Itaquaquecetuba' FROM dual
 UNION ALL

 SELECT 4973, 26, 'Itararé' FROM dual
 UNION ALL

 SELECT 4974, 26, 'Itariri' FROM dual
 UNION ALL

 SELECT 4975, 26, 'Itatiba' FROM dual
 UNION ALL

 SELECT 4976, 26, 'Itatinga' FROM dual
 UNION ALL

 SELECT 4977, 26, 'Itirapina' FROM dual
 UNION ALL

 SELECT 4978, 26, 'Itirapuã' FROM dual
 UNION ALL

 SELECT 4979, 26, 'Itobi' FROM dual
 UNION ALL

 SELECT 4980, 26, 'Itu' FROM dual
 UNION ALL

 SELECT 4981, 26, 'Itupeva' FROM dual
 UNION ALL

 SELECT 4982, 26, 'Ituverava' FROM dual
 UNION ALL

 SELECT 4983, 26, 'Jaborandi' FROM dual
 UNION ALL

 SELECT 4984, 26, 'Jaboticabal' FROM dual
 UNION ALL

 SELECT 4985, 26, 'Jacareí' FROM dual
 UNION ALL

 SELECT 4986, 26, 'Jaci' FROM dual
 UNION ALL

 SELECT 4987, 26, 'Jacupiranga' FROM dual
 UNION ALL

 SELECT 4988, 26, 'Jaguariúna' FROM dual
 UNION ALL

 SELECT 4989, 26, 'Jales' FROM dual
 UNION ALL

 SELECT 4990, 26, 'Jambeiro' FROM dual
 UNION ALL

 SELECT 4991, 26, 'Jandira' FROM dual
 UNION ALL

 SELECT 4992, 26, 'Jardinópolis' FROM dual
 UNION ALL

 SELECT 4993, 26, 'Jarinu' FROM dual
 UNION ALL

 SELECT 4994, 26, 'Jaú' FROM dual
 UNION ALL

 SELECT 4995, 26, 'Jeriquara' FROM dual
 UNION ALL

 SELECT 4996, 26, 'Joanópolis' FROM dual
 UNION ALL

 SELECT 4997, 26, 'João Ramalho' FROM dual
 UNION ALL

 SELECT 4998, 26, 'José Bonifácio' FROM dual
 UNION ALL

 SELECT 4999, 26, 'Júlio Mesquita' FROM dual
 UNION ALL

 SELECT 5000, 26, 'Jumirim' FROM dual
 UNION ALL

 SELECT 5001, 26, 'Jundiaí' FROM dual
 UNION ALL

 SELECT 5002, 26, 'Junqueirópolis' FROM dual
 UNION ALL

 SELECT 5003, 26, 'Juquiá' FROM dual
 UNION ALL

 SELECT 5004, 26, 'Juquitiba' FROM dual
 UNION ALL

 SELECT 5005, 26, 'Lagoinha' FROM dual
 UNION ALL

 SELECT 5006, 26, 'Laranjal Paulista' FROM dual
 UNION ALL

 SELECT 5007, 26, 'Lavínia' FROM dual
 UNION ALL

 SELECT 5008, 26, 'Lavrinhas' FROM dual
 UNION ALL

 SELECT 5009, 26, 'Leme' FROM dual
 UNION ALL

 SELECT 5010, 26, 'Lençóis Paulista' FROM dual
 UNION ALL

 SELECT 5011, 26, 'Limeira' FROM dual
 UNION ALL

 SELECT 5012, 26, 'Lindóia' FROM dual
 UNION ALL

 SELECT 5013, 26, 'Lins' FROM dual
 UNION ALL

 SELECT 5014, 26, 'Lorena' FROM dual
 UNION ALL

 SELECT 5015, 26, 'Lourdes' FROM dual
 UNION ALL

 SELECT 5016, 26, 'Louveira' FROM dual
 UNION ALL

 SELECT 5017, 26, 'Lucélia' FROM dual
 UNION ALL

 SELECT 5018, 26, 'Lucianópolis' FROM dual
 UNION ALL

 SELECT 5019, 26, 'Luís Antônio' FROM dual
 UNION ALL

 SELECT 5020, 26, 'Luiziânia' FROM dual
 UNION ALL

 SELECT 5021, 26, 'Lupércio' FROM dual
 UNION ALL

 SELECT 5022, 26, 'Lutécia' FROM dual
 UNION ALL

 SELECT 5023, 26, 'Macatuba' FROM dual
 UNION ALL

 SELECT 5024, 26, 'Macaubal' FROM dual
 UNION ALL

 SELECT 5025, 26, 'Macedônia' FROM dual
 UNION ALL

 SELECT 5026, 26, 'Magda' FROM dual
 UNION ALL

 SELECT 5027, 26, 'Mairinque' FROM dual
 UNION ALL

 SELECT 5028, 26, 'Mairiporã' FROM dual
 UNION ALL

 SELECT 5029, 26, 'Manduri' FROM dual
 UNION ALL

 SELECT 5030, 26, 'Marabá Paulista' FROM dual
 UNION ALL

 SELECT 5031, 26, 'Maracaí' FROM dual
 UNION ALL

 SELECT 5032, 26, 'Marapoama' FROM dual
 UNION ALL

 SELECT 5033, 26, 'Mariápolis' FROM dual
 UNION ALL

 SELECT 5034, 26, 'Marília' FROM dual
 UNION ALL

 SELECT 5035, 26, 'Marinópolis' FROM dual
 UNION ALL

 SELECT 5036, 26, 'Martinópolis' FROM dual
 UNION ALL

 SELECT 5037, 26, 'Matão' FROM dual
 UNION ALL

 SELECT 5038, 26, 'Mauá' FROM dual
 UNION ALL

 SELECT 5039, 26, 'Mendonça' FROM dual
 UNION ALL

 SELECT 5040, 26, 'Meridiano' FROM dual
 UNION ALL

 SELECT 5041, 26, 'Mesópolis' FROM dual
 UNION ALL

 SELECT 5042, 26, 'Miguelópolis' FROM dual
 UNION ALL

 SELECT 5043, 26, 'Mineiros do Tietê' FROM dual
 UNION ALL

 SELECT 5044, 26, 'Mira Estrela' FROM dual
 UNION ALL

 SELECT 5045, 26, 'Miracatu' FROM dual
 UNION ALL

 SELECT 5046, 26, 'Mirandópolis' FROM dual
 UNION ALL

 SELECT 5047, 26, 'Mirante do Paranapanema' FROM dual
 UNION ALL

 SELECT 5048, 26, 'Mirassol' FROM dual
 UNION ALL

 SELECT 5049, 26, 'Mirassolândia' FROM dual
 UNION ALL

 SELECT 5050, 26, 'Mococa' FROM dual
 UNION ALL

 SELECT 5051, 26, 'Mogi das Cruzes' FROM dual
 UNION ALL

 SELECT 5052, 26, 'Mogi Guaçu' FROM dual
 UNION ALL

 SELECT 5053, 26, 'Moji Mirim' FROM dual
 UNION ALL

 SELECT 5054, 26, 'Mombuca' FROM dual
 UNION ALL

 SELECT 5055, 26, 'Monções' FROM dual
 UNION ALL

 SELECT 5056, 26, 'Mongaguá' FROM dual
 UNION ALL

 SELECT 5057, 26, 'Monte Alegre do Sul' FROM dual
 UNION ALL

 SELECT 5058, 26, 'Monte Alto' FROM dual
 UNION ALL

 SELECT 5059, 26, 'Monte Aprazível' FROM dual
 UNION ALL

 SELECT 5060, 26, 'Monte Azul Paulista' FROM dual
 UNION ALL

 SELECT 5061, 26, 'Monte Castelo' FROM dual
 UNION ALL

 SELECT 5062, 26, 'Monte Mor' FROM dual
 UNION ALL

 SELECT 5063, 26, 'Monteiro Lobato' FROM dual
 UNION ALL

 SELECT 5064, 26, 'Morro Agudo' FROM dual
 UNION ALL

 SELECT 5065, 26, 'Morungaba' FROM dual
 UNION ALL

 SELECT 5066, 26, 'Motuca' FROM dual
 UNION ALL

 SELECT 5067, 26, 'Murutinga do Sul' FROM dual
 UNION ALL

 SELECT 5068, 26, 'Nantes' FROM dual
 UNION ALL

 SELECT 5069, 26, 'Narandiba' FROM dual
 UNION ALL

 SELECT 5070, 26, 'Natividade da Serra' FROM dual
 UNION ALL

 SELECT 5071, 26, 'Nazaré Paulista' FROM dual
 UNION ALL

 SELECT 5072, 26, 'Neves Paulista' FROM dual
 UNION ALL

 SELECT 5073, 26, 'Nhandeara' FROM dual
 UNION ALL

 SELECT 5074, 26, 'Nipoã' FROM dual
 UNION ALL

 SELECT 5075, 26, 'Nova Aliança' FROM dual
 UNION ALL

 SELECT 5076, 26, 'Nova Campina' FROM dual
 UNION ALL

 SELECT 5077, 26, 'Nova Canaã Paulista' FROM dual
 UNION ALL

 SELECT 5078, 26, 'Nova Castilho' FROM dual
 UNION ALL

 SELECT 5079, 26, 'Nova Europa' FROM dual
 UNION ALL

 SELECT 5080, 26, 'Nova Granada' FROM dual
 UNION ALL

 SELECT 5081, 26, 'Nova Guataporanga' FROM dual
 UNION ALL

 SELECT 5082, 26, 'Nova Independência' FROM dual
 UNION ALL

 SELECT 5083, 26, 'Nova Luzitânia' FROM dual
 UNION ALL

 SELECT 5084, 26, 'Nova Odessa' FROM dual
 UNION ALL

 SELECT 5085, 26, 'Novais' FROM dual
 UNION ALL

 SELECT 5086, 26, 'Novo Horizonte' FROM dual
 UNION ALL

 SELECT 5087, 26, 'Nuporanga' FROM dual
 UNION ALL

 SELECT 5088, 26, 'Ocauçu' FROM dual
 UNION ALL

 SELECT 5089, 26, 'Óleo' FROM dual
 UNION ALL

 SELECT 5090, 26, 'Olímpia' FROM dual
 UNION ALL

 SELECT 5091, 26, 'Onda Verde' FROM dual
 UNION ALL

 SELECT 5092, 26, 'Oriente' FROM dual
 UNION ALL

 SELECT 5093, 26, 'Orindiúva' FROM dual
 UNION ALL

 SELECT 5094, 26, 'Orlândia' FROM dual
 UNION ALL

 SELECT 5095, 26, 'Osasco' FROM dual
 UNION ALL

 SELECT 5096, 26, 'Oscar Bressane' FROM dual
 UNION ALL

 SELECT 5097, 26, 'Osvaldo Cruz' FROM dual
 UNION ALL

 SELECT 5098, 26, 'Ourinhos' FROM dual
 UNION ALL

 SELECT 5099, 26, 'Ouro Verde' FROM dual
 UNION ALL

 SELECT 5100, 26, 'Ouroeste' FROM dual
 UNION ALL

 SELECT 5101, 26, 'Pacaembu' FROM dual
 UNION ALL

 SELECT 5102, 26, 'Palestina' FROM dual
 UNION ALL

 SELECT 5103, 26, 'Palmares Paulista' FROM dual
 UNION ALL

 SELECT 5104, 26, 'Palmeira d`Oeste' FROM dual
 UNION ALL

 SELECT 5105, 26, 'Palmital' FROM dual
 UNION ALL

 SELECT 5106, 26, 'Panorama' FROM dual
 UNION ALL

 SELECT 5107, 26, 'Paraguaçu Paulista' FROM dual
 UNION ALL

 SELECT 5108, 26, 'Paraibuna' FROM dual
 UNION ALL

 SELECT 5109, 26, 'Paraíso' FROM dual
 UNION ALL

 SELECT 5110, 26, 'Paranapanema' FROM dual
 UNION ALL

 SELECT 5111, 26, 'Paranapuã' FROM dual
 UNION ALL

 SELECT 5112, 26, 'Parapuã' FROM dual
 UNION ALL

 SELECT 5113, 26, 'Pardinho' FROM dual
 UNION ALL

 SELECT 5114, 26, 'Pariquera-Açu' FROM dual
 UNION ALL

 SELECT 5115, 26, 'Parisi' FROM dual
 UNION ALL

 SELECT 5116, 26, 'Patrocínio Paulista' FROM dual
 UNION ALL

 SELECT 5117, 26, 'Paulicéia' FROM dual
 UNION ALL

 SELECT 5118, 26, 'Paulínia' FROM dual
 UNION ALL

 SELECT 5119, 26, 'Paulistânia' FROM dual
 UNION ALL

 SELECT 5120, 26, 'Paulo de Faria' FROM dual
 UNION ALL

 SELECT 5121, 26, 'Pederneiras' FROM dual
 UNION ALL

 SELECT 5122, 26, 'Pedra Bela' FROM dual
 UNION ALL

 SELECT 5123, 26, 'Pedranópolis' FROM dual
 UNION ALL

 SELECT 5124, 26, 'Pedregulho' FROM dual
 UNION ALL

 SELECT 5125, 26, 'Pedreira' FROM dual
 UNION ALL

 SELECT 5126, 26, 'Pedrinhas Paulista' FROM dual
 UNION ALL

 SELECT 5127, 26, 'Pedro de Toledo' FROM dual
 UNION ALL

 SELECT 5128, 26, 'Penápolis' FROM dual
 UNION ALL

 SELECT 5129, 26, 'Pereira Barreto' FROM dual
 UNION ALL

 SELECT 5130, 26, 'Pereiras' FROM dual
 UNION ALL

 SELECT 5131, 26, 'Peruíbe' FROM dual
 UNION ALL

 SELECT 5132, 26, 'Piacatu' FROM dual
 UNION ALL

 SELECT 5133, 26, 'Piedade' FROM dual
 UNION ALL

 SELECT 5134, 26, 'Pilar do Sul' FROM dual
 UNION ALL

 SELECT 5135, 26, 'Pindamonhangaba' FROM dual
 UNION ALL

 SELECT 5136, 26, 'Pindorama' FROM dual
 UNION ALL

 SELECT 5137, 26, 'Pinhalzinho' FROM dual
 UNION ALL

 SELECT 5138, 26, 'Piquerobi' FROM dual
 UNION ALL

 SELECT 5139, 26, 'Piquete' FROM dual
 UNION ALL

 SELECT 5140, 26, 'Piracaia' FROM dual
 UNION ALL

 SELECT 5141, 26, 'Piracicaba' FROM dual
 UNION ALL

 SELECT 5142, 26, 'Piraju' FROM dual
 UNION ALL

 SELECT 5143, 26, 'Pirajuí' FROM dual
 UNION ALL

 SELECT 5144, 26, 'Pirangi' FROM dual
 UNION ALL

 SELECT 5145, 26, 'Pirapora do Bom Jesus' FROM dual
 UNION ALL

 SELECT 5146, 26, 'Pirapozinho' FROM dual
 UNION ALL

 SELECT 5147, 26, 'Pirassununga' FROM dual
 UNION ALL

 SELECT 5148, 26, 'Piratininga' FROM dual
 UNION ALL

 SELECT 5149, 26, 'Pitangueiras' FROM dual
 UNION ALL

 SELECT 5150, 26, 'Planalto' FROM dual
 UNION ALL

 SELECT 5151, 26, 'Platina' FROM dual
 UNION ALL

 SELECT 5152, 26, 'Poá' FROM dual
 UNION ALL

 SELECT 5153, 26, 'Poloni' FROM dual
 UNION ALL

 SELECT 5154, 26, 'Pompéia' FROM dual
 UNION ALL

 SELECT 5155, 26, 'Pongaí' FROM dual
 UNION ALL

 SELECT 5156, 26, 'Pontal' FROM dual
 UNION ALL

 SELECT 5157, 26, 'Pontalinda' FROM dual
 UNION ALL

 SELECT 5158, 26, 'Pontes Gestal' FROM dual
 UNION ALL

 SELECT 5159, 26, 'Populina' FROM dual
 UNION ALL

 SELECT 5160, 26, 'Porangaba' FROM dual
 UNION ALL

 SELECT 5161, 26, 'Porto Feliz' FROM dual
 UNION ALL

 SELECT 5162, 26, 'Porto Ferreira' FROM dual
 UNION ALL

 SELECT 5163, 26, 'Potim' FROM dual
 UNION ALL

 SELECT 5164, 26, 'Potirendaba' FROM dual
 UNION ALL

 SELECT 5165, 26, 'Pracinha' FROM dual
 UNION ALL

 SELECT 5166, 26, 'Pradópolis' FROM dual
 UNION ALL

 SELECT 5167, 26, 'Praia Grande' FROM dual
 UNION ALL

 SELECT 5168, 26, 'Pratânia' FROM dual
 UNION ALL

 SELECT 5169, 26, 'Presidente Alves' FROM dual
 UNION ALL

 SELECT 5170, 26, 'Presidente Bernardes' FROM dual
 UNION ALL

 SELECT 5171, 26, 'Presidente Epitácio' FROM dual
 UNION ALL

 SELECT 5172, 26, 'Presidente Prudente' FROM dual
 UNION ALL

 SELECT 5173, 26, 'Presidente Venceslau' FROM dual
 UNION ALL

 SELECT 5174, 26, 'Promissão' FROM dual
 UNION ALL

 SELECT 5175, 26, 'Quadra' FROM dual
 UNION ALL

 SELECT 5176, 26, 'Quatá' FROM dual
 UNION ALL

 SELECT 5177, 26, 'Queiroz' FROM dual
 UNION ALL

 SELECT 5178, 26, 'Queluz' FROM dual
 UNION ALL

 SELECT 5179, 26, 'Quintana' FROM dual
 UNION ALL

 SELECT 5180, 26, 'Rafard' FROM dual
 UNION ALL

 SELECT 5181, 26, 'Rancharia' FROM dual
 UNION ALL

 SELECT 5182, 26, 'Redenção da Serra' FROM dual
 UNION ALL

 SELECT 5183, 26, 'Regente Feijó' FROM dual
 UNION ALL

 SELECT 5184, 26, 'Reginópolis' FROM dual
 UNION ALL

 SELECT 5185, 26, 'Registro' FROM dual
 UNION ALL

 SELECT 5186, 26, 'Restinga' FROM dual
 UNION ALL

 SELECT 5187, 26, 'Ribeira' FROM dual
 UNION ALL

 SELECT 5188, 26, 'Ribeirão Bonito' FROM dual
 UNION ALL

 SELECT 5189, 26, 'Ribeirão Branco' FROM dual
 UNION ALL

 SELECT 5190, 26, 'Ribeirão Corrente' FROM dual
 UNION ALL

 SELECT 5191, 26, 'Ribeirão do Sul' FROM dual
 UNION ALL

 SELECT 5192, 26, 'Ribeirão dos Índios' FROM dual
 UNION ALL

 SELECT 5193, 26, 'Ribeirão Grande' FROM dual
 UNION ALL

 SELECT 5194, 26, 'Ribeirão Pires' FROM dual
 UNION ALL

 SELECT 5195, 26, 'Ribeirão Preto' FROM dual
 UNION ALL

 SELECT 5196, 26, 'Rifaina' FROM dual
 UNION ALL

 SELECT 5197, 26, 'Rincão' FROM dual
 UNION ALL

 SELECT 5198, 26, 'Rinópolis' FROM dual
 UNION ALL

 SELECT 5199, 26, 'Rio Claro' FROM dual
 UNION ALL

 SELECT 5200, 26, 'Rio das Pedras' FROM dual
 UNION ALL

 SELECT 5201, 26, 'Rio Grande da Serra' FROM dual
 UNION ALL

 SELECT 5202, 26, 'Riolândia' FROM dual
 UNION ALL

 SELECT 5203, 26, 'Riversul' FROM dual
 UNION ALL

 SELECT 5204, 26, 'Rosana' FROM dual
 UNION ALL

 SELECT 5205, 26, 'Roseira' FROM dual
 UNION ALL

 SELECT 5206, 26, 'Rubiácea' FROM dual
 UNION ALL

 SELECT 5207, 26, 'Rubinéia' FROM dual
 UNION ALL

 SELECT 5208, 26, 'Sabino' FROM dual
 UNION ALL

 SELECT 5209, 26, 'Sagres' FROM dual
 UNION ALL

 SELECT 5210, 26, 'Sales' FROM dual
 UNION ALL

 SELECT 5211, 26, 'Sales Oliveira' FROM dual
 UNION ALL

 SELECT 5212, 26, 'Salesópolis' FROM dual
 UNION ALL

 SELECT 5213, 26, 'Salmourão' FROM dual
 UNION ALL

 SELECT 5214, 26, 'Saltinho' FROM dual
 UNION ALL

 SELECT 5215, 26, 'Salto' FROM dual
 UNION ALL

 SELECT 5216, 26, 'Salto de Pirapora' FROM dual
 UNION ALL

 SELECT 5217, 26, 'Salto Grande' FROM dual
 UNION ALL

 SELECT 5218, 26, 'Sandovalina' FROM dual
 UNION ALL

 SELECT 5219, 26, 'Santa Adélia' FROM dual
 UNION ALL

 SELECT 5220, 26, 'Santa Albertina' FROM dual
 UNION ALL

 SELECT 5221, 26, 'Santa Bárbara d`Oeste' FROM dual
 UNION ALL

 SELECT 5222, 26, 'Santa Branca' FROM dual
 UNION ALL

 SELECT 5223, 26, 'Santa Clara d`Oeste' FROM dual
 UNION ALL

 SELECT 5224, 26, 'Santa Cruz da Conceição' FROM dual
 UNION ALL

 SELECT 5225, 26, 'Santa Cruz da Esperança' FROM dual
 UNION ALL

 SELECT 5226, 26, 'Santa Cruz das Palmeiras' FROM dual
 UNION ALL

 SELECT 5227, 26, 'Santa Cruz do Rio Pardo' FROM dual
 UNION ALL

 SELECT 5228, 26, 'Santa Ernestina' FROM dual
 UNION ALL

 SELECT 5229, 26, 'Santa Fé do Sul' FROM dual
 UNION ALL

 SELECT 5230, 26, 'Santa Gertrudes' FROM dual
 UNION ALL

 SELECT 5231, 26, 'Santa Isabel' FROM dual
 UNION ALL

 SELECT 5232, 26, 'Santa Lúcia' FROM dual
 UNION ALL

 SELECT 5233, 26, 'Santa Maria da Serra' FROM dual
 UNION ALL

 SELECT 5234, 26, 'Santa Mercedes' FROM dual
 UNION ALL

 SELECT 5235, 26, 'Santa Rita d`Oeste' FROM dual
 UNION ALL

 SELECT 5236, 26, 'Santa Rita do Passa Quatro' FROM dual
 UNION ALL

 SELECT 5237, 26, 'Santa Rosa de Viterbo' FROM dual
 UNION ALL

 SELECT 5238, 26, 'Santa Salete' FROM dual
 UNION ALL

 SELECT 5239, 26, 'Santana da Ponte Pensa' FROM dual
 UNION ALL

 SELECT 5240, 26, 'Santana de Parnaíba' FROM dual
 UNION ALL

 SELECT 5241, 26, 'Santo Anastácio' FROM dual
 UNION ALL

 SELECT 5242, 26, 'Santo André' FROM dual
 UNION ALL

 SELECT 5243, 26, 'Santo Antônio da Alegria' FROM dual
 UNION ALL

 SELECT 5244, 26, 'Santo Antônio de Posse' FROM dual
 UNION ALL

 SELECT 5245, 26, 'Santo Antônio do Aracanguá' FROM dual
 UNION ALL

 SELECT 5246, 26, 'Santo Antônio do Jardim' FROM dual
 UNION ALL

 SELECT 5247, 26, 'Santo Antônio do Pinhal' FROM dual
 UNION ALL

 SELECT 5248, 26, 'Santo Expedito' FROM dual
 UNION ALL

 SELECT 5249, 26, 'Santópolis do Aguapeí' FROM dual
 UNION ALL

 SELECT 5250, 26, 'Santos' FROM dual
 UNION ALL

 SELECT 5251, 26, 'São Bento do Sapucaí' FROM dual
 UNION ALL

 SELECT 5252, 26, 'São Bernardo do Campo' FROM dual
 UNION ALL

 SELECT 5253, 26, 'São Caetano do Sul' FROM dual
 UNION ALL

 SELECT 5254, 26, 'São Carlos' FROM dual
 UNION ALL

 SELECT 5255, 26, 'São Francisco' FROM dual
 UNION ALL

 SELECT 5256, 26, 'São João da Boa Vista' FROM dual
 UNION ALL

 SELECT 5257, 26, 'São João das Duas Pontes' FROM dual
 UNION ALL

 SELECT 5258, 26, 'São João de Iracema' FROM dual
 UNION ALL

 SELECT 5259, 26, 'São João do Pau d`Alho' FROM dual
 UNION ALL

 SELECT 5260, 26, 'São Joaquim da Barra' FROM dual
 UNION ALL

 SELECT 5261, 26, 'São José da Bela Vista' FROM dual
 UNION ALL

 SELECT 5262, 26, 'São José do Barreiro' FROM dual
 UNION ALL

 SELECT 5263, 26, 'São José do Rio Pardo' FROM dual
 UNION ALL

 SELECT 5264, 26, 'São José do Rio Preto' FROM dual
 UNION ALL

 SELECT 5265, 26, 'São José dos Campos' FROM dual
 UNION ALL

 SELECT 5266, 26, 'São Lourenço da Serra' FROM dual
 UNION ALL

 SELECT 5267, 26, 'São Luís do Paraitinga' FROM dual
 UNION ALL

 SELECT 5268, 26, 'São Manuel' FROM dual
 UNION ALL

 SELECT 5269, 26, 'São Miguel Arcanjo' FROM dual
 UNION ALL

 SELECT 5270, 26, 'São Paulo' FROM dual
 UNION ALL

 SELECT 5271, 26, 'São Pedro' FROM dual
 UNION ALL

 SELECT 5272, 26, 'São Pedro do Turvo' FROM dual
 UNION ALL

 SELECT 5273, 26, 'São Roque' FROM dual
 UNION ALL

 SELECT 5274, 26, 'São Sebastião' FROM dual
 UNION ALL

 SELECT 5275, 26, 'São Sebastião da Grama' FROM dual
 UNION ALL

 SELECT 5276, 26, 'São Simão' FROM dual
 UNION ALL

 SELECT 5277, 26, 'São Vicente' FROM dual
 UNION ALL

 SELECT 5278, 26, 'Sarapuí' FROM dual
 UNION ALL

 SELECT 5279, 26, 'Sarutaiá' FROM dual
 UNION ALL

 SELECT 5280, 26, 'Sebastianópolis do Sul' FROM dual
 UNION ALL

 SELECT 5281, 26, 'Serra Azul' FROM dual
 UNION ALL

 SELECT 5282, 26, 'Serra Negra' FROM dual
 UNION ALL

 SELECT 5283, 26, 'Serrana' FROM dual
 UNION ALL

 SELECT 5284, 26, 'Sertãozinho' FROM dual
 UNION ALL

 SELECT 5285, 26, 'Sete Barras' FROM dual
 UNION ALL

 SELECT 5286, 26, 'Severínia' FROM dual
 UNION ALL

 SELECT 5287, 26, 'Silveiras' FROM dual
 UNION ALL

 SELECT 5288, 26, 'Socorro' FROM dual
 UNION ALL

 SELECT 5289, 26, 'Sorocaba' FROM dual
 UNION ALL

 SELECT 5290, 26, 'Sud Mennucci' FROM dual
 UNION ALL

 SELECT 5291, 26, 'Sumaré' FROM dual
 UNION ALL

 SELECT 5292, 26, 'Suzanápolis' FROM dual
 UNION ALL

 SELECT 5293, 26, 'Suzano' FROM dual
 UNION ALL

 SELECT 5294, 26, 'Tabapuã' FROM dual
 UNION ALL

 SELECT 5295, 26, 'Tabatinga' FROM dual
 UNION ALL

 SELECT 5296, 26, 'Taboão da Serra' FROM dual
 UNION ALL

 SELECT 5297, 26, 'Taciba' FROM dual
 UNION ALL

 SELECT 5298, 26, 'Taguaí' FROM dual
 UNION ALL

 SELECT 5299, 26, 'Taiaçu' FROM dual
 UNION ALL

 SELECT 5300, 26, 'Taiúva' FROM dual
 UNION ALL

 SELECT 5301, 26, 'Tambaú' FROM dual
 UNION ALL

 SELECT 5302, 26, 'Tanabi' FROM dual
 UNION ALL

 SELECT 5303, 26, 'Tapiraí' FROM dual
 UNION ALL

 SELECT 5304, 26, 'Tapiratiba' FROM dual
 UNION ALL

 SELECT 5305, 26, 'Taquaral' FROM dual
 UNION ALL

 SELECT 5306, 26, 'Taquaritinga' FROM dual
 UNION ALL

 SELECT 5307, 26, 'Taquarituba' FROM dual
 UNION ALL

 SELECT 5308, 26, 'Taquarivaí' FROM dual
 UNION ALL

 SELECT 5309, 26, 'Tarabai' FROM dual
 UNION ALL

 SELECT 5310, 26, 'Tarumã' FROM dual
 UNION ALL

 SELECT 5311, 26, 'Tatuí' FROM dual
 UNION ALL

 SELECT 5312, 26, 'Taubaté' FROM dual
 UNION ALL

 SELECT 5313, 26, 'Tejupá' FROM dual
 UNION ALL

 SELECT 5314, 26, 'Teodoro Sampaio' FROM dual
 UNION ALL

 SELECT 5315, 26, 'Terra Roxa' FROM dual
 UNION ALL

 SELECT 5316, 26, 'Tietê' FROM dual
 UNION ALL

 SELECT 5317, 26, 'Timburi' FROM dual
 UNION ALL

 SELECT 5318, 26, 'Torre de Pedra' FROM dual
 UNION ALL

 SELECT 5319, 26, 'Torrinha' FROM dual
 UNION ALL

 SELECT 5320, 26, 'Trabiju' FROM dual
 UNION ALL

 SELECT 5321, 26, 'Tremembé' FROM dual
 UNION ALL

 SELECT 5322, 26, 'Três Fronteiras' FROM dual
 UNION ALL

 SELECT 5323, 26, 'Tuiuti' FROM dual
 UNION ALL

 SELECT 5324, 26, 'Tupã' FROM dual
 UNION ALL

 SELECT 5325, 26, 'Tupi Paulista' FROM dual
 UNION ALL

 SELECT 5326, 26, 'Turiúba' FROM dual
 UNION ALL

 SELECT 5327, 26, 'Turmalina' FROM dual
 UNION ALL

 SELECT 5328, 26, 'Ubarana' FROM dual
 UNION ALL

 SELECT 5329, 26, 'Ubatuba' FROM dual
 UNION ALL

 SELECT 5330, 26, 'Ubirajara' FROM dual
 UNION ALL

 SELECT 5331, 26, 'Uchoa' FROM dual
 UNION ALL

 SELECT 5332, 26, 'União Paulista' FROM dual
 UNION ALL

 SELECT 5333, 26, 'Urânia' FROM dual
 UNION ALL

 SELECT 5334, 26, 'Uru' FROM dual
 UNION ALL

 SELECT 5335, 26, 'Urupês' FROM dual
 UNION ALL

 SELECT 5336, 26, 'Valentim Gentil' FROM dual
 UNION ALL

 SELECT 5337, 26, 'Valinhos' FROM dual
 UNION ALL

 SELECT 5338, 26, 'Valparaíso' FROM dual
 UNION ALL

 SELECT 5339, 26, 'Vargem' FROM dual
 UNION ALL

 SELECT 5340, 26, 'Vargem Grande do Sul' FROM dual
 UNION ALL

 SELECT 5341, 26, 'Vargem Grande Paulista' FROM dual
 UNION ALL

 SELECT 5342, 26, 'Várzea Paulista' FROM dual
 UNION ALL

 SELECT 5343, 26, 'Vera Cruz' FROM dual
 UNION ALL

 SELECT 5344, 26, 'Vinhedo' FROM dual
 UNION ALL

 SELECT 5345, 26, 'Viradouro' FROM dual
 UNION ALL

 SELECT 5346, 26, 'Vista Alegre do Alto' FROM dual
 UNION ALL

 SELECT 5347, 26, 'Vitória Brasil' FROM dual
 UNION ALL

 SELECT 5348, 26, 'Votorantim' FROM dual
 UNION ALL

 SELECT 5349, 26, 'Votuporanga' FROM dual
 UNION ALL

 SELECT 5350, 26, 'Zacarias' FROM dual
 UNION ALL

 SELECT 5351, 25, 'Amparo de São Francisco' FROM dual
 UNION ALL

 SELECT 5352, 25, 'Aquidabã' FROM dual
 UNION ALL

 SELECT 5353, 25, 'Aracaju' FROM dual
 UNION ALL

 SELECT 5354, 25, 'Arauá' FROM dual
 UNION ALL

 SELECT 5355, 25, 'Areia Branca' FROM dual
 UNION ALL

 SELECT 5356, 25, 'Barra dos Coqueiros' FROM dual
 UNION ALL

 SELECT 5357, 25, 'Boquim' FROM dual
 UNION ALL

 SELECT 5358, 25, 'Brejo Grande' FROM dual
 UNION ALL

 SELECT 5359, 25, 'Campo do Brito' FROM dual
 UNION ALL

 SELECT 5360, 25, 'Canhoba' FROM dual
 UNION ALL

 SELECT 5361, 25, 'Canindé de São Francisco' FROM dual
 UNION ALL

 SELECT 5362, 25, 'Capela' FROM dual
 UNION ALL

 SELECT 5363, 25, 'Carira' FROM dual
 UNION ALL

 SELECT 5364, 25, 'Carmópolis' FROM dual
 UNION ALL

 SELECT 5365, 25, 'Cedro de São João' FROM dual
 UNION ALL

 SELECT 5366, 25, 'Cristinápolis' FROM dual
 UNION ALL

 SELECT 5367, 25, 'Cumbe' FROM dual
 UNION ALL

 SELECT 5368, 25, 'Divina Pastora' FROM dual
 UNION ALL

 SELECT 5369, 25, 'Estância' FROM dual
 UNION ALL

 SELECT 5370, 25, 'Feira Nova' FROM dual
 UNION ALL

 SELECT 5371, 25, 'Frei Paulo' FROM dual
 UNION ALL

 SELECT 5372, 25, 'Gararu' FROM dual
 UNION ALL

 SELECT 5373, 25, 'General Maynard' FROM dual
 UNION ALL

 SELECT 5374, 25, 'Gracho Cardoso' FROM dual
 UNION ALL

 SELECT 5375, 25, 'Ilha das Flores' FROM dual
 UNION ALL

 SELECT 5376, 25, 'Indiaroba' FROM dual
 UNION ALL

 SELECT 5377, 25, 'Itabaiana' FROM dual
 UNION ALL

 SELECT 5378, 25, 'Itabaianinha' FROM dual
 UNION ALL

 SELECT 5379, 25, 'Itabi' FROM dual
 UNION ALL

 SELECT 5380, 25, 'Itaporanga d`Ajuda' FROM dual
 UNION ALL

 SELECT 5381, 25, 'Japaratuba' FROM dual
 UNION ALL

 SELECT 5382, 25, 'Japoatã' FROM dual
 UNION ALL

 SELECT 5383, 25, 'Lagarto' FROM dual
 UNION ALL

 SELECT 5384, 25, 'Laranjeiras' FROM dual
 UNION ALL

 SELECT 5385, 25, 'Macambira' FROM dual
 UNION ALL

 SELECT 5386, 25, 'Malhada dos Bois' FROM dual
 UNION ALL

 SELECT 5387, 25, 'Malhador' FROM dual
 UNION ALL

 SELECT 5388, 25, 'Maruim' FROM dual
 UNION ALL

 SELECT 5389, 25, 'Moita Bonita' FROM dual
 UNION ALL

 SELECT 5390, 25, 'Monte Alegre de Sergipe' FROM dual
 UNION ALL

 SELECT 5391, 25, 'Muribeca' FROM dual
 UNION ALL

 SELECT 5392, 25, 'Neópolis' FROM dual
 UNION ALL

 SELECT 5393, 25, 'Nossa Senhora Aparecida' FROM dual
 UNION ALL

 SELECT 5394, 25, 'Nossa Senhora da Glória' FROM dual
 UNION ALL

 SELECT 5395, 25, 'Nossa Senhora das Dores' FROM dual
 UNION ALL

 SELECT 5396, 25, 'Nossa Senhora de Lourdes' FROM dual
 UNION ALL

 SELECT 5397, 25, 'Nossa Senhora do Socorro' FROM dual
 UNION ALL

 SELECT 5398, 25, 'Pacatuba' FROM dual
 UNION ALL

 SELECT 5399, 25, 'Pedra Mole' FROM dual
 UNION ALL

 SELECT 5400, 25, 'Pedrinhas' FROM dual
 UNION ALL

 SELECT 5401, 25, 'Pinhão' FROM dual
 UNION ALL

 SELECT 5402, 25, 'Pirambu' FROM dual
 UNION ALL

 SELECT 5403, 25, 'Poço Redondo' FROM dual
 UNION ALL

 SELECT 5404, 25, 'Poço Verde' FROM dual
 UNION ALL

 SELECT 5405, 25, 'Porto da Folha' FROM dual
 UNION ALL

 SELECT 5406, 25, 'Propriá' FROM dual
 UNION ALL

 SELECT 5407, 25, 'Riachão do Dantas' FROM dual
 UNION ALL

 SELECT 5408, 25, 'Riachuelo' FROM dual
 UNION ALL

 SELECT 5409, 25, 'Ribeirópolis' FROM dual
 UNION ALL

 SELECT 5410, 25, 'Rosário do Catete' FROM dual
 UNION ALL

 SELECT 5411, 25, 'Salgado' FROM dual
 UNION ALL

 SELECT 5412, 25, 'Santa Luzia do Itanhy' FROM dual
 UNION ALL

 SELECT 5413, 25, 'Santa Rosa de Lima' FROM dual
 UNION ALL

 SELECT 5414, 25, 'Santana do São Francisco' FROM dual
 UNION ALL

 SELECT 5415, 25, 'Santo Amaro das Brotas' FROM dual
 UNION ALL

 SELECT 5416, 25, 'São Cristóvão' FROM dual
 UNION ALL

 SELECT 5417, 25, 'São Domingos' FROM dual
 UNION ALL

 SELECT 5418, 25, 'São Francisco' FROM dual
 UNION ALL

 SELECT 5419, 25, 'São Miguel do Aleixo' FROM dual
 UNION ALL

 SELECT 5420, 25, 'Simão Dias' FROM dual
 UNION ALL

 SELECT 5421, 25, 'Siriri' FROM dual
 UNION ALL

 SELECT 5422, 25, 'Telha' FROM dual
 UNION ALL

 SELECT 5423, 25, 'Tobias Barreto' FROM dual
 UNION ALL

 SELECT 5424, 25, 'Tomar do Geru' FROM dual
 UNION ALL

 SELECT 5425, 25, 'Umbaúba' FROM dual
 UNION ALL

 SELECT 5426, 27, 'Abreulândia' FROM dual
 UNION ALL

 SELECT 5427, 27, 'Aguiarnópolis' FROM dual
 UNION ALL

 SELECT 5428, 27, 'Aliança do Tocantins' FROM dual
 UNION ALL

 SELECT 5429, 27, 'Almas' FROM dual
 UNION ALL

 SELECT 5430, 27, 'Alvorada' FROM dual
 UNION ALL

 SELECT 5431, 27, 'Ananás' FROM dual
 UNION ALL

 SELECT 5432, 27, 'Angico' FROM dual
 UNION ALL

 SELECT 5433, 27, 'Aparecida do Rio Negro' FROM dual
 UNION ALL

 SELECT 5434, 27, 'Aragominas' FROM dual
 UNION ALL

 SELECT 5435, 27, 'Araguacema' FROM dual
 UNION ALL

 SELECT 5436, 27, 'Araguaçu' FROM dual
 UNION ALL

 SELECT 5437, 27, 'Araguaína' FROM dual
 UNION ALL

 SELECT 5438, 27, 'Araguanã' FROM dual
 UNION ALL

 SELECT 5439, 27, 'Araguatins' FROM dual
 UNION ALL

 SELECT 5440, 27, 'Arapoema' FROM dual
 UNION ALL

 SELECT 5441, 27, 'Arraias' FROM dual
 UNION ALL

 SELECT 5442, 27, 'Augustinópolis' FROM dual
 UNION ALL

 SELECT 5443, 27, 'Aurora do Tocantins' FROM dual
 UNION ALL

 SELECT 5444, 27, 'Axixá do Tocantins' FROM dual
 UNION ALL

 SELECT 5445, 27, 'Babaçulândia' FROM dual
 UNION ALL

 SELECT 5446, 27, 'Bandeirantes do Tocantins' FROM dual
 UNION ALL

 SELECT 5447, 27, 'Barra do Ouro' FROM dual
 UNION ALL

 SELECT 5448, 27, 'Barrolândia' FROM dual
 UNION ALL

 SELECT 5449, 27, 'Bernardo Sayão' FROM dual
 UNION ALL

 SELECT 5450, 27, 'Bom Jesus do Tocantins' FROM dual
 UNION ALL

 SELECT 5451, 27, 'Brasilândia do Tocantins' FROM dual
 UNION ALL

 SELECT 5452, 27, 'Brejinho de Nazaré' FROM dual
 UNION ALL

 SELECT 5453, 27, 'Buriti do Tocantins' FROM dual
 UNION ALL

 SELECT 5454, 27, 'Cachoeirinha' FROM dual
 UNION ALL

 SELECT 5455, 27, 'Campos Lindos' FROM dual
 UNION ALL

 SELECT 5456, 27, 'Cariri do Tocantins' FROM dual
 UNION ALL

 SELECT 5457, 27, 'Carmolândia' FROM dual
 UNION ALL

 SELECT 5458, 27, 'Carrasco Bonito' FROM dual
 UNION ALL

 SELECT 5459, 27, 'Caseara' FROM dual
 UNION ALL

 SELECT 5460, 27, 'Centenário' FROM dual
 UNION ALL

 SELECT 5461, 27, 'Chapada da Natividade' FROM dual
 UNION ALL

 SELECT 5462, 27, 'Chapada de Areia' FROM dual
 UNION ALL

 SELECT 5463, 27, 'Colinas do Tocantins' FROM dual
 UNION ALL

 SELECT 5464, 27, 'Colméia' FROM dual
 UNION ALL

 SELECT 5465, 27, 'Combinado' FROM dual
 UNION ALL

 SELECT 5466, 27, 'Conceição do Tocantins' FROM dual
 UNION ALL

 SELECT 5467, 27, 'Couto de Magalhães' FROM dual
 UNION ALL

 SELECT 5468, 27, 'Cristalândia' FROM dual
 UNION ALL

 SELECT 5469, 27, 'Crixás do Tocantins' FROM dual
 UNION ALL

 SELECT 5470, 27, 'Darcinópolis' FROM dual
 UNION ALL

 SELECT 5471, 27, 'Dianópolis' FROM dual
 UNION ALL

 SELECT 5472, 27, 'Divinópolis do Tocantins' FROM dual
 UNION ALL

 SELECT 5473, 27, 'Dois Irmãos do Tocantins' FROM dual
 UNION ALL

 SELECT 5474, 27, 'Dueré' FROM dual
 UNION ALL

 SELECT 5475, 27, 'Esperantina' FROM dual
 UNION ALL

 SELECT 5476, 27, 'Fátima' FROM dual
 UNION ALL

 SELECT 5477, 27, 'Figueirópolis' FROM dual
 UNION ALL

 SELECT 5478, 27, 'Filadélfia' FROM dual
 UNION ALL

 SELECT 5479, 27, 'Formoso do Araguaia' FROM dual
 UNION ALL

 SELECT 5480, 27, 'Fortaleza do Tabocão' FROM dual
 UNION ALL

 SELECT 5481, 27, 'Goianorte' FROM dual
 UNION ALL

 SELECT 5482, 27, 'Goiatins' FROM dual
 UNION ALL

 SELECT 5483, 27, 'Guaraí' FROM dual
 UNION ALL

 SELECT 5484, 27, 'Gurupi' FROM dual
 UNION ALL

 SELECT 5485, 27, 'Ipueiras' FROM dual
 UNION ALL

 SELECT 5486, 27, 'Itacajá' FROM dual
 UNION ALL

 SELECT 5487, 27, 'Itaguatins' FROM dual
 UNION ALL

 SELECT 5488, 27, 'Itapiratins' FROM dual
 UNION ALL

 SELECT 5489, 27, 'Itaporã do Tocantins' FROM dual
 UNION ALL

 SELECT 5490, 27, 'Jaú do Tocantins' FROM dual
 UNION ALL

 SELECT 5491, 27, 'Juarina' FROM dual
 UNION ALL

 SELECT 5492, 27, 'Lagoa da Confusão' FROM dual
 UNION ALL

 SELECT 5493, 27, 'Lagoa do Tocantins' FROM dual
 UNION ALL

 SELECT 5494, 27, 'Lajeado' FROM dual
 UNION ALL

 SELECT 5495, 27, 'Lavandeira' FROM dual
 UNION ALL

 SELECT 5496, 27, 'Lizarda' FROM dual
 UNION ALL

 SELECT 5497, 27, 'Luzinópolis' FROM dual
 UNION ALL

 SELECT 5498, 27, 'Marianópolis do Tocantins' FROM dual
 UNION ALL

 SELECT 5499, 27, 'Mateiros' FROM dual
 UNION ALL

 SELECT 5500, 27, 'Maurilândia do Tocantins' FROM dual
 UNION ALL

 SELECT 5501, 27, 'Miracema do Tocantins' FROM dual
 UNION ALL

 SELECT 5502, 27, 'Miranorte' FROM dual
 UNION ALL

 SELECT 5503, 27, 'Monte do Carmo' FROM dual
 UNION ALL

 SELECT 5504, 27, 'Monte Santo do Tocantins' FROM dual
 UNION ALL

 SELECT 5505, 27, 'Muricilândia' FROM dual
 UNION ALL

 SELECT 5506, 27, 'Natividade' FROM dual
 UNION ALL

 SELECT 5507, 27, 'Nazaré' FROM dual
 UNION ALL

 SELECT 5508, 27, 'Nova Olinda' FROM dual
 UNION ALL

 SELECT 5509, 27, 'Nova Rosalândia' FROM dual
 UNION ALL

 SELECT 5510, 27, 'Novo Acordo' FROM dual
 UNION ALL

 SELECT 5511, 27, 'Novo Alegre' FROM dual
 UNION ALL

 SELECT 5512, 27, 'Novo Jardim' FROM dual
 UNION ALL

 SELECT 5513, 27, 'Oliveira de Fátima' FROM dual
 UNION ALL

 SELECT 5514, 27, 'Palmas' FROM dual
 UNION ALL

 SELECT 5515, 27, 'Palmeirante' FROM dual
 UNION ALL

 SELECT 5516, 27, 'Palmeiras do Tocantins' FROM dual
 UNION ALL

 SELECT 5517, 27, 'Palmeirópolis' FROM dual
 UNION ALL

 SELECT 5518, 27, 'Paraíso do Tocantins' FROM dual
 UNION ALL

 SELECT 5519, 27, 'Paranã' FROM dual
 UNION ALL

 SELECT 5520, 27, 'Pau d`Arco' FROM dual
 UNION ALL

 SELECT 5521, 27, 'Pedro Afonso' FROM dual
 UNION ALL

 SELECT 5522, 27, 'Peixe' FROM dual
 UNION ALL

 SELECT 5523, 27, 'Pequizeiro' FROM dual
 UNION ALL

 SELECT 5524, 27, 'Pindorama do Tocantins' FROM dual
 UNION ALL

 SELECT 5525, 27, 'Piraquê' FROM dual
 UNION ALL

 SELECT 5526, 27, 'Pium' FROM dual
 UNION ALL

 SELECT 5527, 27, 'Ponte Alta do Bom Jesus' FROM dual
 UNION ALL

 SELECT 5528, 27, 'Ponte Alta do Tocantins' FROM dual
 UNION ALL

 SELECT 5529, 27, 'Porto Alegre do Tocantins' FROM dual
 UNION ALL

 SELECT 5530, 27, 'Porto Nacional' FROM dual
 UNION ALL

 SELECT 5531, 27, 'Praia Norte' FROM dual
 UNION ALL

 SELECT 5532, 27, 'Presidente Kennedy' FROM dual
 UNION ALL

 SELECT 5533, 27, 'Pugmil' FROM dual
 UNION ALL

 SELECT 5534, 27, 'Recursolândia' FROM dual
 UNION ALL

 SELECT 5535, 27, 'Riachinho' FROM dual
 UNION ALL

 SELECT 5536, 27, 'Rio da Conceição' FROM dual
 UNION ALL

 SELECT 5537, 27, 'Rio dos Bois' FROM dual
 UNION ALL

 SELECT 5538, 27, 'Rio Sono' FROM dual
 UNION ALL

 SELECT 5539, 27, 'Sampaio' FROM dual
 UNION ALL

 SELECT 5540, 27, 'Sandolândia' FROM dual
 UNION ALL

 SELECT 5541, 27, 'Santa Fé do Araguaia' FROM dual
 UNION ALL

 SELECT 5542, 27, 'Santa Maria do Tocantins' FROM dual
 UNION ALL

 SELECT 5543, 27, 'Santa Rita do Tocantins' FROM dual
 UNION ALL

 SELECT 5544, 27, 'Santa Rosa do Tocantins' FROM dual
 UNION ALL

 SELECT 5545, 27, 'Santa Tereza do Tocantins' FROM dual
 UNION ALL

 SELECT 5546, 27, 'Santa Terezinha do Tocantins' FROM dual
 UNION ALL

 SELECT 5547, 27, 'São Bento do Tocantins' FROM dual
 UNION ALL

 SELECT 5548, 27, 'São Félix do Tocantins' FROM dual
 UNION ALL

 SELECT 5549, 27, 'São Miguel do Tocantins' FROM dual
 UNION ALL

 SELECT 5550, 27, 'São Salvador do Tocantins' FROM dual
 UNION ALL

 SELECT 5551, 27, 'São Sebastião do Tocantins' FROM dual
 UNION ALL

 SELECT 5552, 27, 'São Valério da Natividade' FROM dual
 UNION ALL

 SELECT 5553, 27, 'Silvanópolis' FROM dual
 UNION ALL

 SELECT 5554, 27, 'Sítio Novo do Tocantins' FROM dual
 UNION ALL

 SELECT 5555, 27, 'Sucupira' FROM dual
 UNION ALL

 SELECT 5556, 27, 'Taguatinga' FROM dual
 UNION ALL

 SELECT 5557, 27, 'Taipas do Tocantins' FROM dual
 UNION ALL

 SELECT 5558, 27, 'Talismã' FROM dual
 UNION ALL

 SELECT 5559, 27, 'Tocantínia' FROM dual
 UNION ALL

 SELECT 5560, 27, 'Tocantinópolis' FROM dual
 UNION ALL

 SELECT 5561, 27, 'Tupirama' FROM dual
 UNION ALL

 SELECT 5562, 27, 'Tupiratins' FROM dual
 UNION ALL

 SELECT 5563, 27, 'Wanderlândia' FROM dual
 UNION ALL

 SELECT 5564, 27, 'Xambioá' FROM dual;